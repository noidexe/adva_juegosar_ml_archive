/*-------------------------------------------------------------------------
 FILE: CDXLCL_Sprite.CPP
 DESC: clases para algo similar a los LCL_Sprites del K&P,TGF,etc.

  Anarkimedes 2004
-------------------------------------------------------------------------*/

#include "CDXLCL_Sprite.h"


/*
//--------------------------------------------------------------------------//
CDXSprite* CreateSprite(CDXScreen* screen,char* filename,XSPRITEINFO* xspriteinfo)
//--------------------------------------------------------------------------//
{
	CDXSprite* cdxsprite=new CDXSprite();

	if( FAILED(cdxsprite->Create(screen,filename, xspriteinfo->cel_width,
									   xspriteinfo->cel_height,
									   xspriteinfo->n_frames,
									   CDXMEM_VIDTHENSYS)))
		return 0;	

	cdxsprite->SetColorKey();	

	return cdxsprite;
};
//--------------------------------------------------------------------------//
*/




/*
//---------------------------------------------------------------------//

void LCL_SpritePack::LoadSpriteSheet(CDXScreen* screen,void* buffer)

//---------------------------------------------------------------------//
{
	//DEBUG
	char debugtext[256];

	//END DEBUG


	BYTE* pos=(BYTE*)buffer;


	//HEADER
	SSFILEHEADER ssfileheader;
	memcpy(&ssfileheader,pos,sizeof(SSFILEHEADER));
	pos+=sizeof(SSFILEHEADER);

	/*sprintf(debugtext,"Version:%d\nN_Templates:%d",
					  ssfileheader.version,
					  ssfileheader.n_templates);
	MessageBox(0,debugtext,"Debug info",0);*/
/*
	//SPRITE TEMPLATES
	n_xspriteinfos=ssfileheader.n_templates;
	xspriteinfos=new XSPRITEINFO*[n_xspriteinfos];

	n_sprites=ssfileheader.n_aoclasses;
	sprites=new CDXSprite*[n_sprites];

	ao_classes=new AOCLASS[n_sprites];

	for(int i=0;i<n_xspriteinfos;i++)
	{
		TEMPLATE spritetemp;
		memcpy(&spritetemp,pos,sizeof(TEMPLATE));
		pos+=sizeof(TEMPLATE);

		xspriteinfos[i]=new XSPRITEINFO;

		xspriteinfos[i]->cel_width=spritetemp.width;
		xspriteinfos[i]->cel_height=spritetemp.height;
		xspriteinfos[i]->xc=spritetemp.xc;
		xspriteinfos[i]->yc=spritetemp.yc;
		xspriteinfos[i]->n_frames=spritetemp.n_cels;
		xspriteinfos[i]->n_sequences=spritetemp.n_sequences;

		//SEQUENCES
		xspriteinfos[i]->sequences=new SEQUENCE[xspriteinfos[i]->n_sequences];

		for(int j=0;j<xspriteinfos[i]->n_sequences;j++)
		{
			SEQUENCEHEADER seqheader;
			memcpy(&seqheader,pos,sizeof(SEQUENCEHEADER));
			pos+=sizeof(SEQUENCEHEADER);

			xspriteinfos[i]->sequences[j].n_frames=seqheader.n_frames;
			xspriteinfos[i]->sequences[j].speed=seqheader.speed;
			xspriteinfos[i]->sequences[j].loop=seqheader.flags;

			xspriteinfos[i]->sequences[j].framebuffer=new int[xspriteinfos[i]->sequences[j].n_frames];

			for(int k=0;k<xspriteinfos[i]->sequences[j].n_frames;k++)
				xspriteinfos[i]->sequences[j].framebuffer[k]=*pos++;			
		}
	}

	//IMAGES
	char** imagefiles=new char*[ssfileheader.n_images];
	for(i=0;i<ssfileheader.n_images;i++)
	{
		int len=*pos++;
		imagefiles[i]=new char[len+1];
		memcpy(imagefiles[i],pos,len);
		imagefiles[i][len]=0;
		pos+=len;
	}

	//AO CLASSES
	for(i=0;i<n_sprites;i++)
	{
		ao_classes[i].i_spritetemplate=*pos++;
		ao_classes[i].i_image=*pos++;
		
		sprites[i]=CreateSprite(screen,imagefiles[ao_classes[i].i_image],
								       xspriteinfos[ao_classes[i].i_spritetemplate]);
	}

}
//---------------------------------------------------------------------//
*/

//---------------------------------------------------------------------//

bool PtInAO(LCL_Sprite* ao,int x0,int y0)

//---------------------------------------------------------------------//
{	
	RECT bounding_rect;
	bounding_rect.left=ao->x-ao->xspriteinfo->xc;
	bounding_rect.right=bounding_rect.left+ao->xspriteinfo->cel_width;
	
	if(x0<bounding_rect.left || x0>bounding_rect.right)
		return 0;

	bounding_rect.top=ao->y-ao->xspriteinfo->yc;
	bounding_rect.bottom=bounding_rect.top+ao->xspriteinfo->cel_height;

	if(y0<bounding_rect.top || y0>bounding_rect.bottom)
		return 0;

	return 1;
}
//---------------------------------------------------------------------//



////////////////////////////////////////////////////////////////////////

int Fast_Distance_2D(int x, int y)

////////////////////////////////////////////////////////////////////////
{
// this function computes the distance from 0,0 to x,y with 3.5% error

// first compute the absolute value of x,y
x = abs(x);
y = abs(y);

// compute the minimum of x,y
int mn = MIN(x,y);

// return the distance
return(x+y-(mn>>1)-(mn>>2)+(mn>>4));

} // end Fast_Distance_2D
////////////////////////////////////////////////////////////////////////