/*-------------------------------------------------------------------------
 FILE: CDXActiveObject.h
 DESC: clases para algo similar a los ActiveObjects del K&P,TGF,etc.

  Anarkimedes 2004
-------------------------------------------------------------------------*/


#ifndef __CDX_LCLAOBJ__
#define __CDX_LCLAOBJ__

#define CDXINCLUDEALL
#include <cdx.h>

#include "utils.h"
/*otros defines*/



//MACROS
//--------------------------------------------------------------------------//

// m�ximo y m�nimo
#define MIN(a, b)  (((a) < (b)) ? (a) : (b)) 
#define MAX(a, b)  (((a) > (b)) ? (b) : (a)) 



//TYPES
//--------------------------------------------------------------------------//

//FILE IO
//version 0.00
#ifndef BYTE
#define BYTE unsigned char
#endif

typedef struct _SSFILEHEADER{
	int version;
	BYTE n_templates;
	BYTE n_images;
	BYTE n_aoclasses; //clases de active objects
}SSFILEHEADER;

typedef struct _SEQUENCEHEADER{	
	BYTE n_frames;	
	int speed;
	BYTE flags;		//0=nada, 1=loop
} SEQUENCEHEADER;

//sprite template
typedef struct _TEMPLATE{
	int width;
	int height;
	int xc;          //anchor x e
	int yc;          //y
	BYTE n_cels;
	BYTE n_sequences;
} TEMPLATE;

typedef struct _SSFILE{
	SSFILEHEADER ssfileheader;
	TEMPLATE * templates;
} SSFILE;

typedef struct _AOCLASS{
	BYTE i_spritetemplate;	//index al sprite template
	BYTE i_image;			//index al bmp con los gr�ficos	
}AOCLASS;

typedef struct _AODATA{
	int clase;
	int id;
	int x0;
	int y0;
} AODATA;


//ACTIVE OBJECT BASICS

typedef struct _SEQUENCE{
	int n_frames;
	int speed;
	int* framebuffer;	
	bool loop;	
} SEQUENCE;

typedef struct _XSPRITEINFO{
	int cel_width;
	int cel_height;
	int xc;
	int yc;
	int n_frames;
	int n_sequences;
	SEQUENCE* sequences;
} XSPRITEINFO;


//--------------------------------------------------------------------------//




//CLASSES
//--------------------------------------------------------------------------//

class ActiveObject{
protected:
	CDXSprite* sprite;	
	int curr_sequence;
	int curr_frame;
	int counter;
	int m_id;
	int m_clase;
	ActiveObject* m_Next;		
	ActiveObject* m_Prev;		
public:	
	XSPRITEINFO* xspriteinfo;	
	int direction;
	int state;
	int x,y;
	ActiveObject(CDXSprite* p_sprite,XSPRITEINFO* p_xspriteinfo)
	{
		xspriteinfo=p_xspriteinfo;
		sprite=p_sprite;
		Reset();
	}	
	void Reset();
	void SetAnimation(int anim_id){curr_sequence=anim_id;}	
	void ResetAnimation(){counter=0;curr_frame=0;}	
	int Animate();
	void Draw(int camera_x,int camera_y,CDXSurface * surf);	
	void SetDirection();
	void SetNext(ActiveObject* lpAO) { m_Next = lpAO; }
    void SetPrev(ActiveObject* lpAO) { m_Prev = lpAO; }
    ActiveObject* GetNext(void) { return m_Next; }
    ActiveObject* GetPrev(void) { return m_Prev; }
	void SetId(int type) { m_id = type; }
    int  GetId(void) {return m_id;}
	void SetClase(int clase) { m_clase = clase; }
    int  GetClase(void) {return m_clase;}
	virtual void Control(){};
};

class ActiveObjectList
{
public:
	virtual ~ActiveObjectList(void){m_objectList.Clear(TRUE);}
    void AddObject(ActiveObject* p_object) { m_objectList.Add(p_object); }
    void DelActiveObject(ActiveObject* p_object,bool delete_me) { m_objectList.Remove(p_object, delete_me); }
    LONG GetCount(void) { return m_objectList.GetCount(); }
    ActiveObject* GetFirst(void) { return m_objectList.GetFirst(); }
    ActiveObject* GetNext(ActiveObject* p_object) { return m_objectList.Next(p_object); }
	ActiveObject* ActiveObjectList::GetNearest(int x0,int y0,int *distance);
	void Clear(bool b_remove){m_objectList.Clear(b_remove);}
private:
	CDXCList<ActiveObject> m_objectList;  // Linked List template
};

class ActiveObjectPack
{
	//resources
	int n_xspriteinfos;				
public:	
	XSPRITEINFO** xspriteinfos;
	CDXSprite** sprites;	
	AOCLASS* ao_classes;
	int n_sprites; //ie: n ao_classes
	~ActiveObjectPack(){
		for(int i=0;i<n_sprites;i++)
			SAFEDELETE(sprites[i]);
	}
	void LoadSpriteSheet(CDXScreen* screen,void* buffer);
};



//PROTOTIPOS
//--------------------------------------------------------------------------//

CDXSprite* CreateSprite(CDXScreen* screen,char* filename,XSPRITEINFO* xspriteinfo);
bool PtInAO(ActiveObject* ao,int x0,int y0);

//La Mothe�s fast distance 2D
int Fast_Distance_2D(int x, int y);

#endif