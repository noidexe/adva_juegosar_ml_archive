// Project Name:    [ CDX BitmapFont ]
// Original Author: [ Ioannis Karagiorgos - karagior@pluto.fernuni-hagen.de ]
// Author:          [ Jimb Esser - wasteland@writeme.com ]
// Date:            [ 7.4.1999 ]
// Revision:        [ 2.00 ]
//  Updated to work with CDX 3.0 and other bug fixes by Jimb Esser
//////////////////////////////////////////////////////////////////////////////////

#include "CDXBitmapFont.h"
extern void MakeColor(CDXScreen* Screen, DWORD &c, long r, long g, long b);
extern void GetRGB(CDXScreen* Screen, DWORD c, long &r, long &g, long &b);

// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
CDXBitmapFont::CDXBitmapFont()
{
    TextSurface = NULL;
}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
HRESULT CDXBitmapFont::Create( CDXScreen * Scr )
{
    TextSurface = NULL;
    return Create( Scr , "Courier" , 12 , RGB( 255 , 255 , 255 ) , RGB(0,0,0) , RGB(0,0,0) , 
            FW_NORMAL , CDXMEM_VIDTHENSYS);
}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
CDXBitmapFont::~CDXBitmapFont( )
{
    if( TextSurface != NULL ) delete TextSurface;    
}

// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
HRESULT CDXBitmapFont::Create( CDXScreen * pScreen, char * FontNam , int Height , int Color, int ColKey, 
								int BackColor, int Attributes ,DWORD bItalic, BYTE memoryType)
{
	m_iFirstChar = 0;

    int             X , Y , i;
    char            TextBuffer[ 2 ];
    SIZE            size;
    CDXSurface *    TempSurface;
	HRESULT rval;

    FontName            = FontNam;
    FontColor           = Color;
    FontBackgroundColor = BackColor;
    FontColorKey        = ColKey;
    FontHeight          = Height;
    FontAttributes      = Attributes;
	FontItalic			= bItalic;
    TextSurfaceType     = memoryType;
    Screen              = pScreen;

    if( TextSurface != NULL ) delete TextSurface;

    // create temporary surface in order to get the character widths
    // surface can be created in system memory because it is only needed one time
    TempSurface = new CDXSurface();
	rval = TempSurface->Create( Screen , 100 , 100 , CDXMEM_SYSTEMONLY );
	if (FAILED(rval)) {
		return rval;
	}

    // the font surface will be width=320 and height as needed
    // i chose width=320 because some video cards dont support surfaces wider
    // than the actual resolution in video memory, so if you choose 
    // videomode 320x200 or 320x240 the surface would be allocated in system memory
    // which would slow down output of fonts.
    TempSurface->ChangeFont( FontName , 0 , FontHeight , FontAttributes,bItalic);

    // loop through all 256 characters and calculate position and size of every character
 
    X = Y = 0;

    for( i=0; i<256; i++ )
    {
        TextBuffer[ 0 ] = i;
        TextBuffer[ 1 ] = '\0';

        HDC dc = TempSurface->GetDC( );
        TempSurface->SetFont( );
        SetBkMode( dc , OPAQUE );
        SetTextColor( dc, RGB( 255 , 255 , 255 ) );
        SetBkColor( dc, RGB( 0 , 0 , 0 ) );
        GetTextExtentPoint32( dc , TextBuffer , 1 , &size );
        TempSurface->ReleaseDC( );

        // if x + character width exceed 310 then begin new line
        if( X+size.cx >= 310 )
        {
            X = 0;
            Y += size.cy;
        }

        CDXBitmapFontArray[ i ].Height = size.cy;
        CDXBitmapFontArray[ i ].Width  = size.cx;

        CDXBitmapFontArray[ i ].Rectangle.left      = X;
        CDXBitmapFontArray[ i ].Rectangle.top       = Y;
        CDXBitmapFontArray[ i ].Rectangle.right     = X + size.cx;
        CDXBitmapFontArray[ i ].Rectangle.bottom    = Y + size.cy;
        X += size.cx;
    }


    delete TempSurface;

    if( TextSurface != NULL )
        delete TextSurface;

    TextSurface = new CDXSurface();
	rval = TextSurface->Create( Screen , 320 , Y+Height+5 , TextSurfaceType );
	if (FAILED(rval)) {
		return rval;
	}
    PaintCharactersInSurface( );
	return 0; // Success!
}



void CDXBitmapFont::PaintCharactersInSurface( void )
{
    char    TextBuffer[ 2 ];
    int     i;

    TextSurface->ChangeFont( FontName , 0 , FontHeight , FontAttributes);//,FontItalic );

	// Convert the font color to what it should be for the
	// bitdepth of the screen.  If we're in 8-bit, nothing
	// will be done with it, assume a palette color index
	// is passed in.  If MakeColor() in cdxscreen (or here)
	// is implemented to handle 8-bit, we could process
	// 8-bit like the others (taking an RGB() parameter).
	int r, g, b;
		r = FontColorKey & 0xFF;
		g = (FontColorKey >> 8) & 0xFF;
		b = (FontColorKey >> 16) & 0xFF;
	DWORD c;
	MakeColor(Screen, c, r, g, b);
    TextSurface->SetColorKey( c );

    // print all characters on surface
    HDC dc = TextSurface->GetDC( );
    TextSurface->SetFont( );
    SetBkMode( dc , OPAQUE );
    SetTextColor( dc,  FontColor );
    SetBkColor( dc, FontBackgroundColor );

    HRGN Region;

    for( i=0; i<256; i++ )
    {
        TextBuffer[ 0 ] = i;
        TextBuffer[ 1 ] = '\0';

        // select clip region because some characters like 'j' exceed the drawing rectangle
        // and reach into other characters bitmaps
        Region = CreateRectRgn( CDXBitmapFontArray[i].Rectangle.left ,
                                CDXBitmapFontArray[i].Rectangle.top ,
                                CDXBitmapFontArray[i].Rectangle.right ,
                                CDXBitmapFontArray[i].Rectangle.bottom );
        SelectClipRgn( dc, Region );
    
		TextOut( dc, CDXBitmapFontArray[i].Rectangle.left , 
                                     CDXBitmapFontArray[i].Rectangle.top , TextBuffer , 1 );		

		//LCL MODIFICADO BEGIN
		//hace el outline
		COLORREF OutlineColor=RGB(10,10,10);
		for(int iy=CDXBitmapFontArray[i].Rectangle.top;
		        iy<CDXBitmapFontArray[i].Rectangle.bottom;iy++)
			for(int ix=CDXBitmapFontArray[i].Rectangle.left;
			        ix<CDXBitmapFontArray[i].Rectangle.right;ix++)
			{		
					if(GetPixel(dc,ix,iy)==FontBackgroundColor)
					{
						if((GetPixel(dc,ix-1,iy)==FontColor)||(GetPixel(dc,ix+1,iy)==FontColor))
							SetPixel(dc,ix,iy,OutlineColor);

						if((GetPixel(dc,ix,iy-1)==FontColor)||(GetPixel(dc,ix,iy+1)==FontColor))
							SetPixel(dc,ix,iy,OutlineColor);

					}
				
			}

		//LCL MODIFICADO END
        DeleteObject( Region );
    }


    TextSurface->ReleaseDC( );
}

// --------------------------------------------------------------------------------------
// Length = -1 means draw the complete string, else length characters
// --------------------------------------------------------------------------------------
HRESULT CDXBitmapFont::Draw(int X, int Y, char * Text , CDXSurface* lpDDest , int Length )
{
	if (!TextSurface) { // Makesure Create has been called and we have a valid surface
		return 1;
	}

	HRESULT rval;
	char    ch;

	while(  ( (ch = *Text++) != '\0' ) &&
			(  Length--      != 0    )    )
	{
		if (ch >= m_iFirstChar) {
			rval = lpDDest->GetDDS()->BltFast(X, Y, TextSurface->GetDDS(), &CDXBitmapFontArray[ ch ].Rectangle, 
					DDBLTFAST_WAIT);

			if(rval == DDERR_SURFACELOST) 
			{
				Restore( );
				rval = lpDDest->GetDDS()->BltFast(X, Y, TextSurface->GetDDS(), &CDXBitmapFontArray[ ch ].Rectangle, 
						DDBLTFAST_WAIT);
				if (rval == DDERR_SURFACELOST)
					return rval;
			}
		}
		X += CDXBitmapFontArray[ ch ].Width;
	}

	return rval;
}


// --------------------------------------------------------------------------------------
// Length = -1 means draw the complete string, else length characters
// --------------------------------------------------------------------------------------
HRESULT CDXBitmapFont::DrawTrans(int X, int Y, char * Text , CDXSurface* lpDDest , int Length )
{
	if (!TextSurface) { // Makesure Create has been called and we have a valid surface
		return 1;
	}

    HRESULT rval;
    unsigned char    ch;//LCL modificado para poder usar 256 chars.

	int X0=X;

	X=X0+(180-GetTextWidth(Text)/2);

    while(  ( (ch = *Text++) != '\0' ))

    {
		if(ch=='\n')
		{
			X=X0+(180-GetTextWidth(Text)/2);
			Y+=FontHeight;
		}
		else
		{
			if (ch >= m_iFirstChar)
				lpDDest->GetDDS()->BltFast(X, Y, TextSurface->GetDDS(), &CDXBitmapFontArray[ ch ].Rectangle, 
				DDBLTFAST_WAIT| DDBLTFAST_SRCCOLORKEY);
				X += CDXBitmapFontArray[ ch ].Width;		
		}
		
    }

    return rval;
}


// --------------------------------------------------------------------------------------
// Length = -1 means draw the complete string, else length characters
// --------------------------------------------------------------------------------------
int CDXBitmapFont::DrawTransEx(RECT* rect, char * Text , CDXSurface* lpDDest , int flags )
{
	if (!TextSurface) { // Makesure Create has been called and we have a valid surface
		return 1;
	}

	int height=FontHeight;
    unsigned char    ch;//LCL modificado para poder usar 256 chars.

	int width=rect->right-rect->left;
	int X=rect->left;
	int Y=rect->top;
   

	//
	char curr_txt[256];
	if(flags&WORD_BREAK)
	{		
		int l=strlen(Text);
		memcpy(curr_txt,Text,l);
		curr_txt[l]='\0';

		int ll=0;
		int rl=0;

		char* p=curr_txt;
		char* lspace=0;
		while(*p!='\0')
		{
			if(*p==' ')	
			{
				rl=0;
				lspace=p;
			}

			ll+=GetCharacterWidth(*p);

			if(ll>width)
			{				
				*lspace='\n';			
				ll=0;
				p=lspace;
			}		
			p++;
		}
		
		Text=curr_txt;
	}
	//


	if(flags&CENTRADO)
		X+=(width-GetTextWidth(Text))/2;
	
    while(  ( (ch = *Text++) != '\0' ))

    {
		if(ch=='\n')
		{
			if(flags&CENTRADO)
				X=rect->left+(width-GetTextWidth(Text))/2;
			else
				X=rect->left;
			Y+=FontHeight;
			height+=FontHeight;
		}
		else
		{
			if (ch >= m_iFirstChar)
				lpDDest->GetDDS()->BltFast(X, Y, TextSurface->GetDDS(), &CDXBitmapFontArray[ ch ].Rectangle, 
				DDBLTFAST_WAIT| DDBLTFAST_SRCCOLORKEY);
				X += CDXBitmapFontArray[ ch ].Width;		
		}
		
    }

    return height;
}




// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
void CDXBitmapFont::SetFont( char * FontNam , int Height , int Color , int Attributes,DWORD bItalic )
{
    Create( Screen , FontNam , Height , Color , FontColorKey , FontBackgroundColor , Attributes,bItalic );
}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
void CDXBitmapFont::SetColor( int Color )
{
    FontColor      = Color;

    PaintCharactersInSurface( );
}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
void CDXBitmapFont::SetColorKey( int ColorKey )
{
    FontColorKey = ColorKey;

    TextSurface->SetColorKey( FontColorKey );
}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
void CDXBitmapFont::SetBackgroundColor( int Color )
{
    FontBackgroundColor = Color;

    PaintCharactersInSurface( );
}




// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
int CDXBitmapFont::GetCharacterHeight( char ch )
{
	if (!TextSurface) { // Makesure Create has been called and we have a valid surface
		return -1;
	}

    return CDXBitmapFontArray[ ch ].Height;
}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
int CDXBitmapFont::GetTextWidth( char * Text )
{
	if (!TextSurface) { // Makesure Create has been called and we have a valid surface
		return -1;
	}

    int  Result;
    BYTE ch;

    Result = 0;

    while( ((ch = *Text++) != '\0') && (ch!= '\n') )
    {
        Result += CDXBitmapFontArray[ ch ].Width;
    }

    return Result;
}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
void CDXBitmapFont::Restore( void )
{
    //TextSurface->Restore();
    PaintCharactersInSurface( );
}
