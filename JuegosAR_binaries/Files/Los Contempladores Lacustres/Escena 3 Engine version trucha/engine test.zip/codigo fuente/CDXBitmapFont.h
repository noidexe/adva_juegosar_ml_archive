//////////////////////////////////////////////////////////////////////////////////
// Project Name:    [ CDX BitmapFont ]
// Original Author: [ Ioannis Karagiorgos - karagior@pluto.fernuni-hagen.de ]
// Author:          [ Jimb Esser - wasteland@writeme.com ]
// Date:            [ 7.4.1999 ]
// Revision:        [ 2.00 ]
//  Updated to work with CDX 3.0 and other bug fixes by Jimb Esser
//  Note: the draw clipped functions have not yet been updated
//////////////////////////////////////////////////////////////////////////////////

//MODIFICADO POR LCL(2005)


// Note on CreateFromFile:
// A good source of graphical fonts is: http://cgi.algonet.se/htbin/cgiwrap?user=guld1&script=fonts.pl
//   but, these all need to be massaged into a readable format, specifically
//   8-bit BMP (Photoshop may try to save as 4-bit, but CDX doesn't
//   do 4-bit files).


#ifndef __CDX_BITMAPFONT__
#define __CDX_BITMAPFONT__

#include "cdx.h"
#include "cdxsurface.h"
#include "cdxscreen.h"


//LCL MODIFICADO
#define CENTRADO	0x0001
#define WORD_BREAK	0x0002

class CDXBitmapFont
{
public:

	typedef struct 
	{
		RECT    Rectangle;
		int		Width , Height;
	} CDXBITMAPFONT;

	CDXBITMAPFONT	CDXBitmapFontArray[ 256 ];

	int				FontColor;
	int				FontBackgroundColor;
	int				FontColorKey;
	int				FontHeight;
    int             FontAttributes;
	DWORD			FontItalic;
	char			* FontName;
    int             TextSurfaceType;
	int				m_iFirstChar; // The lowest character that can be displayed

	CDXSurface *	TextSurface;
   	CDXScreen  *	Screen;

    CDXBitmapFont();
	~CDXBitmapFont();

	HRESULT Create( CDXScreen * pScreen);
	// Note on ColorKey:
	//		if your screen is in 8bit mode, then this parameter must be
	//		the index of the color (dependant on palette), for any other
	//		bitdepth, pass in an RGB(r,g,b) macro parameter
	HRESULT Create( CDXScreen * pScreen, char * FontNam , int Height , int Color = RGB( 255 , 255 , 255 ), int ColKey = RGB(0,0,0), 
			int BackColor = RGB(0,0,0), int Attributes = FW_NORMAL ,DWORD bItalic=FALSE, BYTE memoryType= CDXMEM_VIDTHENSYS );

    void PaintCharactersInSurface( void );    

	HRESULT Draw(int X, int Y, char * Text , CDXSurface* lpDDest , int Length = -1 );
//    HRESULT DrawClipped(int X, int Y, char * Text , CDXSurface* lpDDest, LPRECT ClipRect , int Length = -1);
    HRESULT DrawTrans(int X, int Y, char * Text , CDXSurface* lpDDest , int Length = -1);
    //HRESULT DrawTransClipped(int X, int Y, char * Text , CDXSurface* lpDDest, LPRECT ClipRect , int Length = -1);
	int DrawTransEx(RECT* rect, char * Text , CDXSurface* lpDDest , int flags ); //LCL MODIFICADO

	// iWidth is the width of the box in which the text should be aligned
    HRESULT DrawAligned( int X , int Y , int Width , char * Text , CDXSurface * lpDDest , int Align );
    HRESULT DrawAlignedTrans( int X , int Y , int Width , char * Text , CDXSurface * lpDDest , int Align );
	
    void SetFont( char * FontNam , int Height , int Color , int Attributes = FW_NORMAL,DWORD bItalic=FALSE );
    void SetColor( int Color );
    void SetColorKey( int ColorKey );
    void SetBackgroundColor( int Color );

    int GetCharacterWidth( unsigned char ch ){return CDXBitmapFontArray[ ch ].Width;}
    int GetCharacterHeight( char ch );
    int GetTextWidth( char * Text );

    void Restore( );
};

#endif