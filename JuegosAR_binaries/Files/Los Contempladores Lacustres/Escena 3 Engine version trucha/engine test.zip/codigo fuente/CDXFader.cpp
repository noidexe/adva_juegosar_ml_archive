//----------------------------------------------------------------------------
// Class Name		: CDXFade
// Code Object		: CDX-adapted fading for 16-bit surfaces [ Implementation ]
// Authour			: Fading method -> Matt Reiferson 
//						The Game Programming MegaSite - http://www.perplexed.com/GPMega/
//						"DirectDraw Fading Mania" - Demo Source
//					  CDX compatible object adaptation -> Scott Zuyderduyn (szuyderduyn@geocities.com)
//					  Support for variable sized surfaces and resolutions -> Scott Zuyderduyn
// Revision			: 1.00 (9 July 1999)
//					: 1.01 (23 July 1999)
//					: 1.02 [3/2/2001]
//							Converted to CDX 3.0 by Jacek Ringwelski (Jacek@extrementity.com)
//----------------------------------------------------------------------------

// Note: 
//	I've tried my best to document exactly what changes were made from
//	Matt Reiferson's original source.
//												- Scott
// 
// Note:
//	I've did not document what changes I made to the source while converting
//	it to work with CDX 3.0
//												- Jacek (Jacek@extrementity.com)

#include "cdx.h"
#include "CDXScreen.h"
#include "CDXSurface.h"
#include "CDXFader.h"
//#include <ddraw.h>	// sz - not needed, using CDX

#define RED(p)		(p >> pRed)					// Extracts Red Component
#define GREEN(p)	((p & mGreen) >> pGreen)	// Extracts Green Component
#define BLUE(p)		(p & mBlue)					// Extracts Blue Component
#define RGB16(r, g, b)	((r << pRed) | (g << pGreen) | b)	// Creates RGB Pixel Value

// Object constructor
// - Scott Zuyderduyn
CDXFader::CDXFader(CDXScreen *destScreen)
{
	Screen = destScreen;
	Screen->GetFront()->Fill(0);
	Screen->GetBack()->Fill(0);

	DDGetRGB16();
	InitPixelShade();
}

/*
 * DDGetRGB16:
 *    Must run this function to fill the RGB16 struct with the information needed to plot a pixel
 *		To call this, you must have rgb16 defined as a global (unless you want to modify this) variable
 *		RGB16 rgb16;
 */
// - Matt Reiferson
// - adapted to CDX (Scott Zuyderduyn)
void CDXFader::DDGetRGB16(void)
{
	DDSURFACEDESC2  ddsd;       // DirectDraw Surface Description
	BYTE            shiftcount; // Shift Counter

	// get a surface despriction
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_PIXELFORMAT;
	Screen->GetFront()->GetDDS()->GetSurfaceDesc(&ddsd);
	// Fill in the masking values for extracting colors
	rgb16.mask.rgbRed = ddsd.ddpfPixelFormat.dwRBitMask;
	rgb16.mask.rgbGreen = ddsd.ddpfPixelFormat.dwGBitMask;
	rgb16.mask.rgbBlue = ddsd.ddpfPixelFormat.dwBBitMask;
	
	// get red surface information
	shiftcount = 0;    
	while(!(ddsd.ddpfPixelFormat.dwRBitMask & 1))
	{
		ddsd.ddpfPixelFormat.dwRBitMask >>= 1;
		shiftcount++;
	}
	rgb16.depth.rgbRed = (BYTE)ddsd.ddpfPixelFormat.dwRBitMask;
	rgb16.position.rgbRed = shiftcount;
	rgb16.amount.rgbRed = (ddsd.ddpfPixelFormat.dwRBitMask == 0x1f) ? 3 : 2;

	// get green surface information
	shiftcount = 0;
	while(!(ddsd.ddpfPixelFormat.dwGBitMask & 1))
	{
		ddsd.ddpfPixelFormat.dwGBitMask >>= 1;
		shiftcount++;
	}
	rgb16.depth.rgbGreen =(BYTE)ddsd.ddpfPixelFormat.dwGBitMask;
	rgb16.position.rgbGreen = shiftcount;
	rgb16.amount.rgbGreen = (ddsd.ddpfPixelFormat.dwGBitMask == 0x1f) ? 3 : 2;

	// get Blue surface information
	shiftcount = 0;
		while(!(ddsd.ddpfPixelFormat.dwBBitMask & 1)) 
	{
	ddsd.ddpfPixelFormat.dwBBitMask >>= 1;
	shiftcount++; 
	}
	rgb16.depth.rgbBlue =(BYTE)ddsd.ddpfPixelFormat.dwBBitMask;
	rgb16.position.rgbBlue = shiftcount;
	rgb16.amount.rgbBlue = (ddsd.ddpfPixelFormat.dwBBitMask == 0x1f) ? 3 : 2;
		// fill in variables so we dont' have to access the structure anymore
	mRed = rgb16.mask.rgbRed;         // Red Mask
	mGreen = rgb16.mask.rgbGreen;     // Green Mask
	mBlue = rgb16.mask.rgbBlue;       // Blue Mask
	pRed = rgb16.position.rgbRed;     // Red Position
	pGreen = rgb16.position.rgbGreen; // Green Position
	pBlue = rgb16.position.rgbBlue;   // Blue Position
}

/*
 * DDLockSurface:
 *		Locks a specified surface
 */
// - Matt Reiferson
// - adapted to CDX (Scott Zuyderduyn)
//		used this instead of CDXSurface->Lock because we need to return a pointer
WORD* CDXFader::DDLockSurface(CDXSurface *srcSurface, int *lpitch)
{
	// lock the surface
	srcSurface->Lock();

	// set the memory pitch
	*lpitch = srcSurface->GetPitch() >> 1;
		
	// return pointer to surface
	return((WORD *)srcSurface->GetSurfacePointer());
}

/*
 * DDUnlockSurface:
 *		Unlocks a specified surface
 */
// - Scott Zuyderduyn
//	    might as well use CDXSurface->Lock, but kept this to keep
//		Reiferson's code intact
HRESULT CDXFader::DDUnlockSurface(CDXSurface *srcSurface)
{
   // unlock the surface memory
	return srcSurface->UnLock();
}


/*
 * InitPixelShade:
 *    Fills the PixelShade array with precomputed shades of every possible pixel (32 shades)
 */
// - Matt Reiferson
void CDXFader::InitPixelShade(void)
{
	int i, j;
	int r,g,b;
	int dr,dg,db;
	const double alpha[32] = { 0.0, 0.03, 0.06, 0.09,
										0.13, 0.17, 0.21, 0.24,
										0.27, 0.31, 0.34, 0.37,
										0.41, 0.44, 0.47, 0.49,
										0.51, 0.53, 0.56, 0.59,
										0.63, 0.66, 0.69, 0.73,
										0.76, 0.79, 0.83, 0.87,
										0.91, 0.94, 0.97, 1.0 };
	
	for(i=0;i<32;i++)
	{
		for(j=0;j<65536;j++)
		{
			r = RED(j);
			g = GREEN(j);
			b = BLUE(j);
			dr = (int)(r*alpha[i]);
			dg = (int)(g*alpha[i]);
			db = (int)(b*alpha[i]);
			PixelShade[i][j] = RGB16(dr,dg,db);
		}
	}
}

//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

/*
 * AlphaTransition:
 *    Does an alpha transition from Src -> Des
 */
// - Matt Reiferson
// - Adapted to CDX (Scott Zuyderduyn)
// - currently only does full screen surface to surface fades (not too hard to implement
//	 yourself though!)
// - basically right now, your best bet is to use 
//	 faderobject->AlphaTransition(Screen->GetFront(),Screen->GetBack());
//   to fade from the screen to the backbuffer
void CDXFader::AlphaTransition(CDXSurface *srcSurface, CDXSurface *desSurface)
{	
	long i;							 // index into surfaces
	int alpha;                  // Holds current alpha value
	int dpitch, spitch, tpitch, ppitch; // surface pitch for destination, source, temp surfaces
	WORD *AlphaPTR;              // pointer to the current AlphaMap level (Source)
	WORD *InvAlphaPTR;           // the inverted pointer to the current AlphaMap level (Destination)
	WORD *src, *des, *tmp, *prm;
	WORD *fastsrc, *fastdes, *fasttmp;      // Surface memory pointer for source, destination, and temporary surfaces
	//RECT SrcRect, DesRect;      // Source and destination rectangles
	
	// Set source and destination rectangles to the screen size
	int sizeX = Screen->GetWidth();
	int sizeY = Screen->GetHeight();

	RECT src_dest_Rect;
	src_dest_Rect.left = 0;
	src_dest_Rect.top = 0;
	src_dest_Rect.right = sizeX;
	src_dest_Rect.bottom = sizeY;

	// Create the three surface we are going to use
	CDXSurface* lpDDSTmp;
	CDXSurface* lpDDSSrc;
	CDXSurface* lpDDSDes;
	lpDDSTmp = new CDXSurface();
	lpDDSSrc = new CDXSurface();
	lpDDSDes = new CDXSurface();
	lpDDSTmp->Create(Screen, sizeX, sizeY, CDXMEM_SYSTEMONLY);
	lpDDSSrc->Create(Screen, sizeX, sizeY, CDXMEM_SYSTEMONLY);
	lpDDSDes->Create(Screen, sizeX, sizeY, CDXMEM_SYSTEMONLY);

	// Blit the transition surfaces into out newly created source/destination surfaces
	srcSurface->DrawBlk(lpDDSSrc,0,0,&src_dest_Rect);
	desSurface->DrawBlk(lpDDSDes,0,0,&src_dest_Rect);
		
	// for each alpha level
	for(alpha=31;alpha>=0;alpha--)
	{
		// lock all three surfaces temporary, source, and destination
		des = DDLockSurface(lpDDSDes, &dpitch);
		src = DDLockSurface(lpDDSSrc, &spitch);
		tmp = DDLockSurface(lpDDSTmp, &tpitch);
		prm = DDLockSurface(Screen->GetFront(), &ppitch);
		// set AlphaMap pointers to appropriate levels
		AlphaPTR = PixelShade[alpha];
		InvAlphaPTR = PixelShade[31-alpha];
		
		// "reset" the *fast* pointers to the locked surfaces
		fastsrc = src;
		fastdes = des;
		fasttmp = tmp;
		
		// loop through every pixel
		for(i=0;i<(sizeX*sizeY);i++,fasttmp++,fastsrc++,fastdes++)
		{
			// Set the new pixel value in temporary surface
			*fasttmp = AlphaPTR[*fastsrc] + InvAlphaPTR[*fastdes];
		}
		
		// Unlock our temporary, source, and destination surfaces
		DDUnlockSurface(Screen->GetFront());
		DDUnlockSurface(lpDDSTmp);
		DDUnlockSurface(lpDDSDes);
		DDUnlockSurface(lpDDSSrc);
/*
		// copy the temp surface to the primary surface
		// (640*480) = 307200 (words) * 2 = 614400 (bytes)
		memcpy(prm, tmp, (sizeX*sizeY*2));
*/
		lpDDSTmp->DrawBlk(Screen->GetFront(),0,0);
	}
	
	
	// Release our temporary, source, and destination surfaces
	delete lpDDSTmp;
	delete lpDDSSrc;
	delete lpDDSDes;
}


/*
 * FadeToSurface:
 *    Fades into a surface from black
 */
// - Matt Reiferson
// - adapted to use CDX objects (Scott Zuyderduyn)
// - adapted to allow for fades of only parts of a screen
void CDXFader::FadeToSurface(CDXSurface *srcSurface, int screenPosX, int screenPosY)
{
	int c;                 // counter variable
	int x,y;
	RECT bitmapposition;
	WORD *tmp, *ref, *prm;
	WORD *fasttmp, *fastref;       // temporary and destination surface mem pointers
	int tpitch, rpitch, ppitch;    // temporary and destination surface pitch
	WORD *shade;
	
	int sizeX = srcSurface->GetWidth();
	int sizeY = srcSurface->GetHeight();

	bitmapposition.left = screenPosX;
	bitmapposition.right = srcSurface->GetWidth() + screenPosX;
	bitmapposition.top = screenPosY;
	bitmapposition.bottom = srcSurface->GetHeight() + screenPosY;

	// Set the source rectangles
	RECT srcSurfaceRect;
	srcSurfaceRect.top = 0;
	srcSurfaceRect.left = 0;
	srcSurfaceRect.right = sizeX;
	srcSurfaceRect.bottom = sizeY;
	
	// Create the surfaces
	CDXSurface *lpDDSTmp;
	CDXSurface *lpDDSRef;
	lpDDSTmp = new CDXSurface();
	lpDDSRef = new CDXSurface();
	lpDDSTmp->Create(Screen, Screen->GetWidth(), Screen->GetHeight(), CDXMEM_SYSTEMONLY);
	lpDDSRef->Create(Screen, Screen->GetWidth(), Screen->GetHeight(), CDXMEM_SYSTEMONLY);

	Screen->GetFront()->DrawBlk(lpDDSTmp,0,0);
	srcSurface->DrawBlk(lpDDSRef,screenPosX,screenPosY);


	// This can be changed, but it worx out nice to do 10 iterations
	for(c=1;c<=30;c++)
	{
		// Lock our surfaces temporary, and destination
		tmp = DDLockSurface(lpDDSTmp, &tpitch);
		prm = DDLockSurface(Screen->GetFront(), &ppitch);
		ref = DDLockSurface(lpDDSRef, &rpitch);
		// get pointer indexed to the start of the current shade level
		shade = PixelShade[c];
		
		// "reset" our *fast* surface pointers
		fasttmp = tmp;
		fastref = ref;

		for (y=0; y < (signed)Screen->GetHeight(); y++)
			for (x=0; x < (signed)Screen->GetWidth(); x++, fasttmp++, fastref++)
			{
				if ((x>=bitmapposition.left)&(x<=bitmapposition.right))
					if ((y>=bitmapposition.top)&(y<=bitmapposition.bottom))
						*fasttmp=shade[*fastref];
			}

		// unlock the temporary surface and destination surface
		DDUnlockSurface(lpDDSTmp);
		DDUnlockSurface(Screen->GetFront());
		DDUnlockSurface(lpDDSRef);
/*
		// copy the temp surface to the primary surface
		// (800*600) = 480000 (words) * 2 = 960000 (bytes)
	    memcpy(prm, tmp, (Screen->GetWidth()*Screen->GetHeight()*2));
		// NOTE:	this command will copy the entire screen from the temp surface
		//			to the primary surface, even if we're only manipulating a small
		//			portion of the screen... I kept this approach because I figured
		//			it probably keeps the speed of the fade fairly constant no matter
		//			the size of the surface being faded
*/
		lpDDSTmp->DrawBlk(Screen->GetFront(),0,0);
	}


	// blit the actual destination surface to the primary surface so we're sure
	// the screen is where it should be
	srcSurface->DrawBlk(Screen->GetFront(),screenPosX,screenPosY,&srcSurfaceRect);
	// release the temporary and destination surfaces
	delete lpDDSTmp;
	delete lpDDSRef;
}

/*
 * FadeToBlack:
 *		Fades a screen to black
 */
// - Matt Reiferson
// - adapted to use CDX classes (Scott Zuyderduyn)
void CDXFader::FadeToBlack(void)
{
	RECT fadeArea;
	fadeArea.top = 0;
	fadeArea.left = 0;
	fadeArea.right = Screen->GetWidth();
	fadeArea.bottom = Screen->GetHeight();

	FadeToBlack(&fadeArea);
}

void CDXFader::FadeToBlack(RECT *fadeArea)
{
	int x, y;
	WORD *tmp;             // temporary surface memory pointer
	WORD *ref;
	WORD *prm;
	WORD *fastref, *fasttmp;
	int c, tpitch, rpitch, ppitch;         // incrementing variable, temporary surface pitch
	WORD *shade;

	// Create our temporary surface
	CDXSurface *lpDDSTmp;
	CDXSurface *lpDDSRef;
	lpDDSTmp = new CDXSurface();
	lpDDSRef = new CDXSurface();
	lpDDSTmp->Create(Screen, Screen->GetWidth(), Screen->GetHeight(), CDXMEM_SYSTEMONLY);
	lpDDSRef->Create(Screen, Screen->GetWidth(), Screen->GetHeight(), CDXMEM_SYSTEMONLY);
	
	// Blit our primary surface into our temporary SYSTEM MEMORY surface
	int sizeX = Screen->GetFront()->GetWidth();
	int sizeY = Screen->GetFront()->GetHeight();

	RECT frontrect;
	frontrect.left = 0;
	frontrect.top = 0;
	frontrect.right = sizeX;
	frontrect.bottom = sizeY;
	Screen->GetFront()->DrawBlk(lpDDSRef,0,0,&frontrect);
	lpDDSRef->DrawBlk(lpDDSTmp,0,0);

	
	for(c=30;c>=1;c--)
	{
		// Lock our temporary surface
		tmp = DDLockSurface(lpDDSTmp, &tpitch);
		ref = DDLockSurface(lpDDSRef, &rpitch);
		prm = DDLockSurface(Screen->GetFront(), &ppitch);
		
		// get a pointer indexed to the start of the current shade level
		shade = PixelShade[c];

		// "reset" our *fast* surface pointers
		fastref = ref;
		fasttmp = tmp;

		for (y=0; y < (signed)Screen->GetHeight(); y++)
			for (x=0; x < (signed)Screen->GetWidth(); x++, fasttmp++, fastref++)
			{
				if ((x>=fadeArea->left)&(x<=fadeArea->right))
					if ((y>=fadeArea->top)&(y<=fadeArea->bottom))
						*fasttmp=shade[*fastref];
			}

			// unlock our temporary surface
			DDUnlockSurface(lpDDSTmp);
			DDUnlockSurface(lpDDSRef);
			DDUnlockSurface(Screen->GetFront());
			
		//What was he thinking here? That might be faster....but you just can't do it.
			//you can't memcpy into video memory - Jacek

		// copy the temp surface to the primary surface
		// (640*480) = 307200 (words) * 2 = 614400 (bytes)
	    //memcpy(prm, tmp, (Screen->GetHeight()*Screen->GetWidth()*2));

		//FastDraw it instead, it's just as fast (sometimes faster) - Jacek
		lpDDSTmp->DrawBlk(Screen->GetFront(),0,0);
	}
	

	// just to make sure the screen is black when this routine is over, fill it with 0
	Screen->GetFront()->FillRect(fadeArea->left,fadeArea->top,fadeArea->right,fadeArea->bottom,0);
	//Screen->GetFront()->Fill(0);

	// release our temporary surface
	delete lpDDSTmp;
	delete lpDDSRef;
}
