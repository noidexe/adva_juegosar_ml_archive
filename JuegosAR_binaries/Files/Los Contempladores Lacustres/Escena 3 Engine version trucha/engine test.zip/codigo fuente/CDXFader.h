//#define WIN32_LEAN_AND_MEAN
#ifndef CDXFADER_H
#define CDXFADER_H

#include <windows.h>
#include <stdlib.h>
#include <malloc.h>
//#define CDXINCLUDEALL
#include "CDX.h"
#include "CDXScreen.h"
#include "CDXSurface.h"

// the structure which holds pixel RGB masks
typedef struct _RGBMASK
{
	unsigned long rgbRed; // red component
	unsigned long rgbGreen; // green component
	unsigned long rgbBlue; // blue component
} RGBMASK;

// the structure which holds screen format info (5,6,5 or 5,5,5 and masking)
typedef struct _RGB16
{
	RGBQUAD depth;
	RGBQUAD amount;
	RGBQUAD position;
	RGBMASK mask;
} RGB16;

class CDXFader
{
private:
	CDXScreen *Screen;

	RGB16	rgb16;			// Video Card RGB Information Structure
	int	mRed, mGreen,		// Faster values of above structure
		mBlue, pRed,		// Faster values of above structure
		pGreen, pBlue;		// Faster values of above structure

	WORD PixelShade[32][65536];

private:
	WORD* DDLockSurface(CDXSurface* srcSurface, int *lpitch);
	HRESULT DDUnlockSurface(CDXSurface* srcSurface);
	void DDGetRGB16();
	void InitPixelShade(void);

public:
	CDXFader(CDXScreen *destScreen);	// constructor
	~CDXFader() {}					// destructor
	void AlphaTransition(CDXSurface *srcSurface, CDXSurface *desSurface);
	void FadeToSurface(CDXSurface *srcSurface, int screenPosX, int screenPosY);
	void FadeToBlack(void);				// fade out entire screen
	void FadeToBlack(RECT *fadeArea);	// fade out specified part of screen
};
#endif