// ------------------------------------------------------------------------------------------
// FILE: CDX-LITE SKINNED FRAMEWORK.CPP
//
// Anarkimedes::Los Contempladores Lacustres (2004)
// ------------------------------------------------------------------------------------------

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <math.h>

//CDX LITE
#include "CDX.h"
#include "cdxinput.h"
#include "cdxscreen.h"
#include "cdxsurface.h"

#include "LCL_Sprite.h"
#include "LCL_Tile.h"
#include "LCL_Mapa.h"


//utils
#include "utils.h"

//CDX add-ons
#include "CDXBitmapFont.h"
#include "CDXFader.h"

#include "resource.h"

//AG
#include "parsing.h"
#include "agscript.h"
#include "agscriptx.h"
#include "roomfile.h"

//sonido con softsynth
#include "LCL_Softsynth.h"


//para el logo del dialog
#include "cargarjpg.h"


//APP DEFINES
//----------------------------------------------------------------------------------------
#define NAME		"LCL-CDX"
#define TITLE		"LCL Windowed/FS Framework"


#define PREGUNTARCONFIG //pregunta si correr en fullscreen, bpp, etc.


//DISPLAY

#define SCREEN_WIDTH	640
#define SCREEN_HEIGHT	480
#define MIN_FPS			30

#define FULLSCREEN		0
#define DEF_BPP			16

//INPUT
#define MOUSE			1
#define KEYBOARD		1



//SYSTEM GLOBALS
//----------------------------------------------------------------------------------------

HWND		hWnd=NULL;
HWND		hwndSkinnedMain=NULL;
                        // remember to set all CDX objects to 0 when you declare them!
RECT        Window      = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};   // clip rectangle
BOOL        bActive		= TRUE; // Is the program running?

bool		fullscreen=	FULLSCREEN;
int			bpp=		DEF_BPP;
CDXInput	* Input		= 0;

CDXScreen   * Screen    = 0;

char textbuffer[256];

//sonido
LCL_SoftSynth Sonido;

//GAME CLASSES
//----------------------------------------------------------------------------------------
typedef struct _OBJETO{
	CDXSurface* img;
	char* desc;
	int id;
	int combinable;
	int def_action;
	SCRIPT* scripts[4];
} OBJETO;

#define MAX_OBJ_SLOTS 32
class LCL_Inventorio{	
public:
	//layout
	CDXSurface* flechasimg;	
	//RECT view_rect;
	int x0,y0; //coordenadas desde donde dibujar las flechas
	int x1; //offset para empezar a dibujar los objetos (relativo a roomview.left)
	int n_obj_to_draw; //nro de objetos a dibujar por p�gina
	int item_space; //espacio entre items	
	int item_width;
	int item_height;
	
	int f_width;
	int f_height;

	//pag
	int scrolling_up;
	int scrolling_down;
	int curr_page;
	int n_pages;

	//objetos
	int carried_objs;
	int inventorio[MAX_OBJ_SLOTS];
	int n_objetos;
	OBJETO* objetos;
	
	
	void Reset();
	int PointOverObject(int x,int y);
	void Cargar_ASCII(CDXScreen* screen,char* filename,ScriptData &scriptdata);
	void Draw(CDXSurface* surf);
	void AddObject(int object_id);
	void RemoveObject(int object_id);
};

int LCL_Inventorio::PointOverObject(int x,int y)
{
	POINT pos;
	pos.x=x;
	pos.y=y;
	RECT rc;
	rc.top=y0;
	rc.bottom=y0+item_height;

	int first_obj=curr_page*n_obj_to_draw;
	int last_obj=min(carried_objs-first_obj,n_obj_to_draw);

	for(int i=0;i<n_obj_to_draw;i++)
	{
		rc.left=x1+i*(item_width+item_space);
		rc.right=rc.left+item_width;
		if(PtInRect(&rc,pos))
			return first_obj+i;
	}
	return -1;
}

void LCL_Inventorio::Reset()
{
	carried_objs=0;
	for(int i=0;i<MAX_OBJ_SLOTS;i++)
		inventorio[i]=-1;
}

void LCL_Inventorio::AddObject(int object_id)
{
	int i=0;
	while(inventorio[i]!=-1)i++;
	inventorio[i]=object_id;
	carried_objs++;
	n_pages=carried_objs/n_obj_to_draw;
	curr_page=n_pages-1;
}

void LCL_Inventorio::RemoveObject(int object_id)
{
	int i=0;
	while(i<MAX_OBJ_SLOTS && (inventorio[i]!=object_id))i++;
	inventorio[i]=-1;
	if(carried_objs)carried_objs--;
	n_pages=carried_objs/n_obj_to_draw;
}

void LCL_Inventorio::Draw(CDXSurface* surf)
{
	RECT src_rect;
	
	//surf->FillRect(view_rct,416,640,480,0);

	if(!carried_objs)
		return;
	
	//flecha de arriba
	if(curr_page>0)
	{
		src_rect.left=scrolling_up*f_width;
		src_rect.right=src_rect.left+f_height;
		src_rect.top=0;
		src_rect.bottom=f_height;
		flechasimg->DrawBlk(surf,x0,y0,&src_rect);
	}
	if(curr_page<n_pages-1)
	{	
		//flecha de abajo
		src_rect.left=scrolling_down*f_width;
		src_rect.right=src_rect.left+f_height;
		src_rect.top=f_height;
		src_rect.bottom=src_rect.top+f_height;	
		flechasimg->DrawBlk(surf,x0,y0+f_height,&src_rect);
	}	

	int first_obj=curr_page*n_obj_to_draw;
	int last_obj=min(carried_objs,first_obj+n_obj_to_draw);
	for(int i=first_obj,j=0;i<last_obj;i++,j++)
		objetos[inventorio[i]].img->DrawBlk(surf,x1+j*(item_width+item_space),y0,0);
	
}

void LCL_Inventorio::Cargar_ASCII(CDXScreen* screen,char* filename,ScriptData &scriptdata)
{
	int i=0,j;
	char seps[]=" ,\n\t\r<;()";
	DWORD size;
	char* buffer=(char*)DumpFileToMem(filename,&size);
	void* imgbuffer;
	char* token=0;

	//primero elimina los comentarios
	SacarComentarios(buffer);

	//lee el archivo

	//nro de objetos
	char* p=buffer;
	n_objetos=GetNextNumberParam(p);

	objetos=new OBJETO[n_objetos];


	/*
	sprintf(textbuffer,"NObjs:%d",n_objetos);
	MessageBox(0,textbuffer,0,0);
	*/
	
		
	for(i=0;i<n_objetos;i++)
	{
		objetos[i].id=i;

		//carga la imagen
		token=GetNextToken(p,seps);	

		imgbuffer=DumpFileToMem(token,&size);
		objetos[i].img=new CDXSurface();
		objetos[i].img->LCL_CrearDesdeImagen(screen,imgbuffer,size,INVERTIR_COLOR);
		delete imgbuffer;
		

		objetos[i].desc=StringFromArg(p,'\"','\"');
		objetos[i].combinable=GetNextNumberParam(p);
		objetos[i].def_action=GetNextNumberParam(p);

		//debug info
		//sprintf(textbuffer,"%d] %s\ %d",i,token,objetos[i].combinable);
		//MessageBox(0,objetos[i].desc,textbuffer,0);
		//end debug info


		objetos[i].scripts[0]=0;
		objetos[i].scripts[1]=0;
		objetos[i].scripts[2]=0;
		objetos[i].scripts[3]=0;

		delete token;
		token=GetNextToken(p,seps);
		while(stricmp(token,"END"))
		{
			int evento=atoi(token);

			/*
			sprintf(textbuffer,"Obj:%d - Evento:%d",i,evento);
			MessageBox(0,textbuffer,0,0);
			*/

			objetos[i].scripts[evento]=new SCRIPT;
			
			p+=CompilarScript(p,objetos[i].scripts[evento],scriptdata);			

			if(token)
				delete token;
			token=GetNextToken(p,seps);
		}
	}
	delete buffer;

	//MessageBox(0,"Esto lo pasa",0,0);
	Reset();

}


typedef struct _DIALOG{
	int n_options;
	char** labels;
	int* flags;
	SCRIPT* scripts;
} DIALOG;

class LCL_DialogPack{	
public:
	DIALOG* dialogos;
	int n_dialogos;
	void CargarDialogos_ASCII(char* filename,ScriptData &scriptdata);
};

//opciones del di�logo
#define REPETIR 1
#define MOSTRAR 2

class LCL_Dialog{
	RECT option_rects[8];
	RECT dialog_rect;
	DIALOG* curr_dialog;
	CDXBitmapFont* normal;
	CDXBitmapFont* selected;
	CDXSurface* auxsurf;
	int width,d_height;
	DWORD bgcolor;
public:
	void Create(CDXScreen* pScreen,int p_width,int p_height);
	void SetDialog(DIALOG* dialog);
	DIALOG* GetDialog(){return curr_dialog;}	
	RECT* GetRect();
	//int GetOption(int x,int y);
	//void TagOption(int option);
	int Show(CDXSurface* surf,POINT cursor);
};

#define DIALOGFONT "Verdana"
#define DIALOGFONTHEIGHT 20
void LCL_Dialog::Create(CDXScreen* pScreen,int p_width,int p_height)
{

	MakeColor(pScreen,bgcolor,0,0,100);
	width=p_width;

	//auxsurf
	auxsurf=new CDXSurface();
	auxsurf->Create(pScreen,p_width,p_height);

	//fonts
	normal=new CDXBitmapFont();
	selected=new CDXBitmapFont();
	normal->Create(pScreen,DIALOGFONT,DIALOGFONTHEIGHT,RGB(255,255,255),0,0,FW_NORMAL,0);
	selected->Create(pScreen,DIALOGFONT,DIALOGFONTHEIGHT,RGB(255,255,0),0,0,FW_NORMAL,0);	

	//dialog_rect
	dialog_rect.left=0;
	dialog_rect.right=width;
	dialog_rect.bottom=480;
}

void LCL_Dialog::SetDialog(DIALOG* dialog)
{
	int i;

	curr_dialog=dialog;
	dialog_rect.top=0;

	d_height=0;

	auxsurf->Fill(bgcolor);
	for(i=0;i<dialog->n_options;i++)
	{
		if(curr_dialog->flags[i]&2)
		{
			option_rects[i]=dialog_rect;
			dialog_rect.top+=normal->DrawTransEx(&dialog_rect,dialog->labels[i],auxsurf,WORD_BREAK);
			option_rects[i].bottom=dialog_rect.top;
		}
	}	
	d_height=dialog_rect.top;

	dialog_rect.top=480-d_height;	
}

int LCL_Dialog::Show(CDXSurface* surf,POINT cursor)
{
	int selected_option=-1;

	RECT rc=dialog_rect;
	rc.top=0;
	rc.bottom=d_height;
	auxsurf->DrawBlk(surf,0,dialog_rect.top,&rc);

	if(PtInRect(&dialog_rect,cursor))
	{
		cursor.y-=dialog_rect.top;
		for(int i=0;i<curr_dialog->n_options;i++)
		{			
			if((curr_dialog->flags[i]&2) &&PtInRect(&option_rects[i],cursor))
			{
				selected_option=i;
				option_rects[i].top+=dialog_rect.top;
				selected->DrawTransEx(&option_rects[i],curr_dialog->labels[i],surf,WORD_BREAK);
				option_rects[i].top-=dialog_rect.top;
			}
			
		}	
	}

	return selected_option;
}


void LCL_DialogPack::CargarDialogos_ASCII(char* filename,ScriptData &scriptdata)
{
	int i=0,j;
	char seps[]=" ,\n\t\r<;()";
	DWORD size;
	char* buffer=(char*)DumpFileToMem(filename,&size);

	//primero elimina los comentarios
	SacarComentarios(buffer);

	//lee el archivo

	//nro de dialogos
	
	//n_dialogos=atoi(strtok(buffer,seps));
	char* p=buffer;
	n_dialogos=GetNextNumberParam(p);

	dialogos=new DIALOG[n_dialogos];
/*
	sprintf(textbuffer,"ND:%d",n_dialogos);
	MessageBox(0,textbuffer,0,0);
*/		
	for(i=0;i<n_dialogos;i++)
	{
		//nro de opciones
		dialogos[i].n_options=GetNextNumberParam(p);
		
		dialogos[i].labels=new char*[dialogos[i].n_options];
		dialogos[i].flags=new int[dialogos[i].n_options];
		dialogos[i].scripts=new SCRIPT[dialogos[i].n_options];
		

		for(j=0;j<dialogos[i].n_options;j++)
		{
			dialogos[i].labels[j]=StringFromArg(p,'<','>');
		
			dialogos[i].flags[j]=GetNextNumberParam(p);	

			/*
			sprintf(textbuffer,"Compilando script %d de dialogo:%d",j,i);
			MessageBox(0,textbuffer,0,0);
			*/
			p+=CompilarScript(p,&dialogos[i].scripts[j],scriptdata);			
			
		}
		
	}

	
	delete buffer;
}

//ESTADOS
#define AGS_MOSTRANDODIALOGO 01
#define AGS_EXPLORANDO		 02
#define AGS_MOSTRANDOTEXTO	 03

//estados del script
#define	RUNNING		 1
#define	PAUSA		 2

typedef struct _VMSTATE{
	int state;
	SCRIPT* script;
	int script_ip;
}VMSTATE;


class sStack
{
	VMSTATE states[32];	
public:
	int sp;
	sStack(){sp=0;}
	void Reset(VMSTATE def_state){sp=0;states[sp]=def_state;}
	void SaveState(VMSTATE state)
	{
		sp++;
		states[sp]=state;
	}
	VMSTATE GetPrevState(){				
		VMSTATE r=states[sp];
		if(sp>0)sp--;
		return r;
	}	
};


typedef struct _HOTSPOTEVENT{
	int event_type;
	int param;
	SCRIPT* script;
}HOTSPOTEVENT;

typedef struct _HOTSPOTXDATA{
	int def_action;
	int n_events;
	HOTSPOTEVENT* events;
}HOTSPOTXDATA;


class LCL_Room{		
public:
	//fondo
	CDXSurface* room_bkgrd;
	int width;
	int height;

	//musica
	int music;
	int volumen;

	//salidas
	int salidas[4];
	char* salida_txts[4];
	
	//hotspot data
	int n_hotspots;
	HRGN* hotspot_rgns;
	char** hotspot_texts;

	//eventos de los hotspots
	HOTSPOTXDATA* xdata;

	//informaci�n del juego
	int visited; //nro de veces visitado

	//funciones
	void Cargar(CDXScreen* screen,void* buffer);
	void Reset(){
		visited=0;
	}
};

void LCL_Room::Cargar(CDXScreen* screen,void* buffer)
{
	int i;
	char*pos=(char*)buffer;

	ROOMFILE roomfile;

	mread(&roomfile,pos,sizeof(ROOMFILE),1);

	music=roomfile.music_code;
	volumen=roomfile.volumen;

	width=roomfile.img_width;
	height=roomfile.img_height;

	//lee los textos de las salidas
	for(i=0;i<4;i++)
	{
		salidas[i]=roomfile.salidas[i];
		salida_txts[i]=new char[roomfile.salida_txt_lens[i]+1];
		salida_txts[i][roomfile.salida_txt_lens[i]]='\0';
		/*
		memcpy(salida_txts[i],pos,roomfile.salida_txt_lens[i]);
		pos+=roomfile.salida_txt_lens[i];
		*/
		mread(salida_txts[i],pos,1,roomfile.salida_txt_lens[i]);
	}

	//lee el jpg
	room_bkgrd=new CDXSurface();
	room_bkgrd->LCL_CrearDesdeImagen(screen,pos,roomfile.img_size,INVERTIR_COLOR);
	
	pos+=roomfile.img_size;
	
	//lee los hotspots
	n_hotspots=roomfile.n_hotspots;			

	//sprintf(textbuffer,"n_hotspots:%d",roomfile.n_hotspots);
	//MessageBox(0,textbuffer,0,0);

	hotspot_rgns=new HRGN[n_hotspots];
	hotspot_texts=new char*[n_hotspots];
	xdata=new HOTSPOTXDATA[n_hotspots];

	for(int j=0;j<n_hotspots;j++)
	{
		HOTSPOT hotspot;

		mread(&hotspot,pos,sizeof(HOTSPOT),1);

		int nv=hotspot.n_vertices;
		int tl=hotspot.text_len;

		//copia el texto del mouseover
		hotspot_texts[j]=new char[hotspot.text_len+1];

		mread(hotspot_texts[j],pos,1,hotspot.text_len);

		hotspot_texts[j][hotspot.text_len]='\0';
	
		hotspot_rgns[j]=CreatePolygonRgn((POINT*)pos,hotspot.n_vertices,WINDING);
		
		pos+=sizeof(POINT)*hotspot.n_vertices;
	

		xdata[j].def_action=hotspot.def_action;

		//scripts/eventos
		//-----------------------------------------------------//
		char eventcode;
		mread(&eventcode,pos,1,1);

		xdata[j].n_events=0;
		xdata[j].events=(HOTSPOTEVENT*)malloc(sizeof(HOTSPOTEVENT)*16);//max provisorio

		while(eventcode!=-1)
		{	
				/*
				sprintf(textbuffer,"Leyendo Hotspot %d,evento %d",j,(int)eventcode);
				MessageBox(0,textbuffer,0,0);
				*/


				xdata[j].events[xdata[j].n_events].event_type=eventcode;
				mread(&xdata[j].events[xdata[j].n_events].param,pos,sizeof(int),1);
				xdata[j].events[xdata[j].n_events].script=new SCRIPT;
				
				//lee el nro de instrucciones
				unsigned char n_insts;
				mread(&n_insts,pos,1,1);

				xdata[j].events[xdata[j].n_events].script->n_insts=n_insts;
				xdata[j].events[xdata[j].n_events].script->insts=new DINSTRUCTION[n_insts];

				//escribe todo
				for(i=0;i<n_insts;i++)
				{
					DINSTRUCTIONFILE fileinstr;
					mread(&fileinstr,pos,sizeof(DINSTRUCTIONFILE),1);
					
					xdata[j].events[xdata[j].n_events].script->insts[i].opcode=fileinstr.opcode;
					
					switch(fileinstr.opcode)
					{
						//DisplayMessage
						case 0:
						{		
							xdata[j].events[xdata[j].n_events].script->insts[i].txt=new char[fileinstr.paramsize+1];
							mread(xdata[j].events[xdata[j].n_events].script->insts[i].txt,pos,1,fileinstr.paramsize);
							xdata[j].events[xdata[j].n_events].script->insts[i].txt[fileinstr.paramsize]='\0';							
							
						//	MessageBox(0,xdata[j].events[xdata[j].n_events].script->insts[i].txt,"EGO:",0);
						}break;

						//DoDialog
						case 1:
						{
							xdata[j].events[xdata[j].n_events].script->insts[i].param1=fileinstr.paramsize;
						/*	
							sprintf(textbuffer,"Dialog %d",j,xdata[j].events[xdata[j].n_events].script->insts[i].param1);
							MessageBox(0,textbuffer,0,0);
							*/
						}break;
					}//end switch opcode
				}//end for
			
				xdata[j].n_events++;

			mread(&eventcode,pos,1,1);

		/*	sprintf(textbuffer,"eventcode: %d",(int)eventcode);
			MessageBox(0,textbuffer,0,0);
			*/
		}//end while
		
		xdata[j].events=(HOTSPOTEVENT*)realloc(xdata[j].events,sizeof(HOTSPOTEVENT)*xdata[j].n_events);
		//-----------------------------------------------------//
	}
}

class LCL_Roompack{	
public:
	LCL_Room* rooms;
	int		  n_rooms;
	void Cargar_ASCII(CDXScreen* pScreen,char* filename);
};

void LCL_Roompack::Cargar_ASCII(CDXScreen* pScreen,char* filename)
	{
		int i=0,j;
		char seps[]=" ,\n\t\r<";
		
		DWORD size;
		char* buffer=(char*)DumpFileToMem(filename,&size);

		//primero elimina los comentarios
		while(buffer[i]!='\0')
		{
			if(buffer[i]!=';') 
				i++;
			else
			{
				j=0;
				buffer[i]=',';	
				i++;
				while(buffer[i]!='\n' && buffer[i]!='\0')
				{
					buffer[i]=' ';
					i++;
				}
			}
		}
		//end eliminar comentarios

		//lee el archivo
		n_rooms=atoi(strtok(buffer,seps));
		rooms=new LCL_Room[n_rooms+1];

		for(i=1;i<n_rooms+1;i++)
		{
			//Carga los rooms
			void* roombuffer=DumpFileToMem(strtok(0,seps),&size);
			rooms[i].Cargar(pScreen,roombuffer);
			delete roombuffer;			
		}

		delete buffer;
}

class GUI_Panel
{	
public:
	//botones
	int*		button_states;
	RECT*		ide_cmd_rects_src;
	RECT*		ide_cmd_rects_dest;	
	//panel
	CDXSurface* ideimg;
	int			s_width,s_height;
	int			n_ide_cmds;
	RECT		panel_rct;
	int         ide_x0,ide_y0;
	//m�todos
	void SetPos(int x,int y);
	void Draw(CDXSurface* surf);
	int IsOverButton(int x,int y);
	void SetButtonState(int button,int state);
	void ResetPanel();
	//void Cargar_ASCII(CDXScreen* screen, char* filename);
};

void GUI_Panel::ResetPanel()
{
	for(int i=0;i<n_ide_cmds;i++)
		button_states[i]=0;
}

void GUI_Panel::SetPos(int x,int y)
{
	ide_x0=x;
	ide_y0=y;
	for(int i=0;i<n_ide_cmds;i++)
	{
		ide_cmd_rects_dest[i].left=ide_cmd_rects_src[i].left+ide_x0;
		ide_cmd_rects_dest[i].top=ide_cmd_rects_src[i].top+ide_y0;
		ide_cmd_rects_dest[i].right=ide_cmd_rects_src[i].right+ide_x0;
		ide_cmd_rects_dest[i].bottom=ide_cmd_rects_src[i].bottom+ide_y0;
	}
}

void GUI_Panel::Draw(CDXSurface* surf)
{
	for(int i=0;i<n_ide_cmds;i++)
	{
		RECT rct=ide_cmd_rects_src[i];
		rct.top+=button_states[i]*s_height;
		rct.bottom+=button_states[i]*s_height;
		ideimg->DrawBlk(surf,ide_cmd_rects_dest[i].left,
							 ide_cmd_rects_dest[i].top,
							 &rct);
	}

}

int GUI_Panel::IsOverButton(int x,int y)
{
	int b_code=-1;
	POINT pos;
	pos.x=x;
	pos.y=y;
	for(int i=0;i<n_ide_cmds;i++)
	{
		if(PtInRect(&ide_cmd_rects_dest[i],pos))
		{
			b_code=i;
			break;
		}
	}
	return b_code;
}

void GUI_Panel::SetButtonState(int button,int state)
{
	button_states[button]=state;
}



#define ACCION_ESPERANDO_COMANDO  0
#define ACCION_ESPERANDO_PARAM1   1
#define ACCION_ESPERANDO_PARAM2	  2
#define ACCION_LISTO			  3

#define ACCION_TIPO_OBJETOINV	  0
#define ACCION_TIPO_HOTSPOT		  1

class Accion{
public:
	char action_txt[256];
	Accion(){Reset();}
	int comando;
	int param1;
	int param1_type;
	int param2;
	int param2_type;	
	int stage; //0=definiendo comando/1=definiendo par�metro 1/2=definiendo par�metro 2
	void Reset()
	{		
		comando=param1=param1_type=param2=param2_type=-1;
		stage=ACCION_ESPERANDO_COMANDO;
	}
	void Close(){stage=ACCION_LISTO;}
};

class LCL_AG{
	
	//sistema
	CDXScreen* pScreen;
	CDXInput* pInput;
	CDXFader* roomfader; //(no anda en windowed mode)
	LCL_SoftSynth* pSonido;  //sonido con softsynth (experimental) y OGGs


	//GUI/layout
	//-----------------------------------------------------------//
	void CargarGUI_ASCII(char* filename);
	
	//A - room view 
	RECT roomview_rct;
	int roomview_width;
	int roomview_height;

	int action_txt_height;

	//B y C - panel de comandos y flechitas
	RECT action_txt_rct;
	Accion accion;
	char** action_cmds;
	GUI_Panel gui_cmd_panel;

	//RECT mouseover_rct;
	CDXBitmapFont* mouseover_fnt;
	LCL_GFXPack_v0* gui_sprites;
	LCL_Sprite* cursor;	

	//D - inventorio
	LCL_Inventorio inventorio;

	bool draw_gui;
	//-----------------------------------------------------------//


	//accion
	void EjecutarAccion();


	//ROOMS
	//-----------------------------------------------------------//
	LCL_Roompack roompack;
	int curr_room;
	int prev_room;

	int changing_room;

	//room view metrics (ver tambi�n gui/layout)
	int max_scroll_x;
	int max_scroll_y;
	float camara_x;
	float camara_y;	
	//-----------------------------------------------------------//

	//musicas
	void CargarMusica_ASCII(char* filename);
	int n_musicas;	
	HOGGSTREAM* musicas;

	
	//state machine/script
	//---------------------------------------------------------//
	//provisorio, para cargar tokens y scripts en ASCII
	ScriptData scriptdata;
	//
	
	sStack statestack;
	VMSTATE vmstate;
	int flags;

	//script
	int script_state;

	void SetScript(SCRIPT* pscript){vmstate.script=pscript;vmstate.script_ip=0;}
	void ResumeScript(){script_state=RUNNING;}
	void PauseScript(){script_state=PAUSA;}	
	//---------------------------------------------------------//

	//di�logos
	int d_selected;
	LCL_Dialog* dialogger;
	LCL_DialogPack dialogpack;

	//mensajes
	CDXBitmapFont* def_font;
	RECT msg_rect;
	char curr_txt[256];
	int counter;
	int text_delay;




public:

	//interfase/GUI
	POINT mouse_c;
	int lbmouse_counter;


	void Cargar();
	void Init(CDXScreen* screen,CDXInput* input,LCL_SoftSynth* p_Sonido);
	void Tick();
	void Apagar();

	//FUNCIONES DEL JUEGO

	//generales
	friend void ChangeRoom(int newroom);

	//mensajes y di�logos
	friend void DisplayMessage(char* txt);
	friend void DoDialog(int dialog_id);	
};


void LCL_AG::CargarMusica_ASCII(char* filename)
{
	char seps[]=" ,\n\t\r();";
	DWORD size;
	char* buffer=(char*)DumpFileToMem(filename,&size);
	char* p=buffer;
	SacarComentarios(buffer);
	char* token;

	n_musicas=GetNextNumberParam(p);
	musicas=new HOGGSTREAM[n_musicas];

	for(int i=0;i<n_musicas;i++)
	{
		token=GetNextToken(p,seps);
		musicas[i]=pSonido->LoadOGG(token);
		delete token;
	}
}


void LCL_AG::CargarGUI_ASCII(char* filename)
{
	char seps[]=" ,\n\t\r();";
	DWORD size;
	char* buffer=(char*)DumpFileToMem(filename,&size);
	char* p=buffer;
	SacarComentarios(buffer);

	char* token=0;
	void* imgbuffer;

	//A - Ventana de juego
	//-------------------------------------------------------------//
	roomview_rct.left=GetNextNumberParam(p);
	roomview_rct.top=GetNextNumberParam(p);
	roomview_rct.right=GetNextNumberParam(p);
	roomview_rct.bottom=GetNextNumberParam(p);

	roomview_width=roomview_rct.right-roomview_rct.left;
	roomview_height=roomview_rct.bottom-roomview_rct.top;

	//message rect (la que usa DisplayMessage)
	msg_rect.left=roomview_rct.left;
	msg_rect.right=roomview_rct.right-40;
	msg_rect.top=roomview_rct.top+200;

	//txt de DisplayMessage (el que aparece al hablar)
	def_font=new CDXBitmapFont();
	def_font->Create(pScreen,"Comic Sans MS",28,RGB(255,255,255));

	//txt con la acci�n
	action_txt_height=GetNextNumberParam(p);

	action_txt_rct.left=roomview_rct.left;
	action_txt_rct.right=roomview_rct.right;
	action_txt_rct.top=roomview_rct.bottom;
	action_txt_rct.bottom=action_txt_rct.top+action_txt_height;		

	//se llama mouseover pero es el font del txt de la acci�n
	mouseover_fnt=new CDXBitmapFont();
	mouseover_fnt->Create(pScreen,"Comic Sans MS",22,RGB(GetNextNumberParam(p),
														 GetNextNumberParam(p),
														 GetNextNumberParam(p)));

	
	//B - panel de comandos
	//-----------------------------------------------------------------
	//carga la imagen
	gui_cmd_panel.ideimg=new CDXSurface();
	token =GetNextToken(p,seps);
	imgbuffer=DumpFileToMem(token,&size);
	delete token;
	gui_cmd_panel.ideimg->LCL_CrearDesdeImagen(pScreen,imgbuffer,size,INVERTIR_COLOR);
	delete imgbuffer;
	
	//nro de comandos
	gui_cmd_panel.n_ide_cmds=GetNextNumberParam(p);

	
	//lee los textos de los comandos
	action_cmds=new char*[gui_cmd_panel.n_ide_cmds];
	for(int i=0;i<gui_cmd_panel.n_ide_cmds;i++)
		action_cmds[i]=StringFromArg(p,'\"','\"');


	//rects de los botones del panel	
	gui_cmd_panel.ide_cmd_rects_src=new RECT[gui_cmd_panel.n_ide_cmds];
	gui_cmd_panel.ide_cmd_rects_dest=new RECT[gui_cmd_panel.n_ide_cmds];
	gui_cmd_panel.button_states=new int[gui_cmd_panel.n_ide_cmds];	
	
	//rects
	for(i=0;i<gui_cmd_panel.n_ide_cmds;i++)
	{
		gui_cmd_panel.ide_cmd_rects_src[i].left=GetNextNumberParam(p);
		gui_cmd_panel.ide_cmd_rects_src[i].top=GetNextNumberParam(p);
		gui_cmd_panel.ide_cmd_rects_src[i].right=GetNextNumberParam(p);
		gui_cmd_panel.ide_cmd_rects_src[i].bottom=GetNextNumberParam(p);
	}

	gui_cmd_panel.s_width=gui_cmd_panel.ideimg->GetWidth();
	gui_cmd_panel.s_height=gui_cmd_panel.ideimg->GetHeight()/3;
	gui_cmd_panel.ResetPanel();

	gui_cmd_panel.SetPos(action_txt_rct.left,action_txt_rct.bottom);

	

	//C - flechitas para scroll del inventorio
	//-------------------------------------------------------------//
	//carga la imagen
	inventorio.flechasimg=new CDXSurface();
	token=GetNextToken(p,seps);
	imgbuffer=DumpFileToMem(token,&size);
	delete token;
	inventorio.flechasimg->LCL_CrearDesdeImagen(pScreen,imgbuffer,size,INVERTIR_COLOR);
	delete imgbuffer;

	inventorio.f_width=inventorio.flechasimg->GetWidth()/2;
	inventorio.f_height=inventorio.flechasimg->GetHeight()/2;
	
	inventorio.item_width=inventorio.item_height=GetNextNumberParam(p);

	inventorio.x0=roomview_rct.left+gui_cmd_panel.s_width;
	inventorio.y0=action_txt_rct.bottom;

	inventorio.x1=GetNextNumberParam(p);

	inventorio.n_obj_to_draw=GetNextNumberParam(p);

	inventorio.item_space=GetNextNumberParam(p);

	delete buffer;
}


void LCL_AG::Init(CDXScreen* screen,CDXInput* input,LCL_SoftSynth* p_Sonido)
{
	//sistema
	pScreen=screen;
	pInput=input;

	pSonido=p_Sonido;

	roomfader=new CDXFader(pScreen);

	//LAYOUT
	//---------------------------------------------------//

	CargarGUI_ASCII("gui.txt");


	//DIALOGOS
	dialogger=new LCL_Dialog();
	dialogger->Create(pScreen,640,240);
	

	accion.Reset();

	//--------------------------------------------------------//

	//SCRIPT
	scriptdata.CargarComandos_ASCII("comandos.txt");
	



	//RESET
	//------------------------------------------//

	//TEXTO
	text_delay=30;

	//STATE MACHINE/SCRIPT
	vmstate.state=AGS_EXPLORANDO;
	vmstate.script=0;
	vmstate.script_ip=0;
	statestack.Reset(vmstate);	
	
	script_state=0;

	//GUI
	lbmouse_counter=0;

	//ROOMS
	curr_room=1;
	prev_room=curr_room;
	changing_room=-1;

	camara_x=0;
	camara_y=0;	

}

void LCL_AG::Cargar()
{
	//GUI
	gui_sprites=new LCL_GFXPack_v0;
	gui_sprites->Cargar_ASCII(pScreen,"cursores.txt");
	cursor=gui_sprites->CrearSprite(0);	

	//INVENTORIO
	inventorio.Cargar_ASCII(pScreen,"inventorio.txt",scriptdata);
	
	

	//musicas
	CargarMusica_ASCII("musica.txt");
	

	//rooms
	roompack.Cargar_ASCII(pScreen,"escenas.txt");

	//mensajes
	dialogpack.CargarDialogos_ASCII("dialogos.txt",scriptdata);

	//softsynth
	
	pSonido->Play();


	//GAME RESET
	//------------------------------------------------------------------//

	//resetea la info de todos los rooms (game RESET)
	for(int r=0;r<roompack.n_rooms;r++)
		roompack.rooms[r].Reset();

	//si el primer room tiene algun tema, pasarlo
	pSonido->PlayOGG(roompack.rooms[curr_room].music-1,1);
	//pSonido->SetOGG_Vol(

	inventorio.Reset();
	/*for(int i=0;i<20;i++)
		inventorio.AddObject(rand()%3);*/

	
}

void LCL_AG::Apagar()
{
	
}






//MAIN LOOP
//----------------------------------------------------------------------------------------

//cuanto esperar antes de tomar como otro click
#define LBUTTONWAIT 10
void LCL_AG::Tick()
{
	char msg[256];
	static int salida=-1;

	//SCRIPT LCL MODIFICAR: reemplazar los switchs por funciones virtuales!
	//---------------------------------------------------------//
	if(vmstate.script)
	{
		if(vmstate.script_ip<vmstate.script->n_insts)
		{
			if(script_state==RUNNING)
			{
				switch(vmstate.script->insts[vmstate.script_ip].opcode)
				{
					//mostrar mensaje
					case 0:
					{
						
						PauseScript();
						vmstate.script_ip++;						
						DisplayMessage(vmstate.script->insts[vmstate.script_ip-1].txt);						
					}break;

					//dialogo
					case 1:
					{						
						PauseScript();
						vmstate.script_ip++;
						DoDialog(vmstate.script->insts[vmstate.script_ip-1].param1);
					}break;


					case 20:
					{
					}break;
				}
			}
		}
		else
		{
			vmstate.script=0;
			vmstate.script_ip=0;			
		}
		
	}
	//---------------------------------------------------------//

	//para que no muestre el texto de salida y mouseover
	bool salidatxt=0;
	
	//en todos los casos tiene que dibujar el fondo
	RECT camera_rct;
	max_scroll_x=roompack.rooms[curr_room].width-roomview_width;
	max_scroll_y=roompack.rooms[curr_room].height-roomview_height;
	camera_rct.left=camara_x;
	camera_rct.top=camara_y;
	if(camera_rct.left>max_scroll_y)camera_rct.left=max_scroll_x;
	if(camera_rct.top>max_scroll_y)camera_rct.top=max_scroll_y;
	camera_rct.right=camera_rct.left+roomview_width;
	camera_rct.bottom=camera_rct.top+roomview_height;
	roompack.rooms[curr_room].room_bkgrd->DrawBlk(pScreen->GetBack(),0,0,&camera_rct);	
	//posici�n del cursor
	//if(!fullscreen)
	pInput->GetMousePos(&mouse_c.x,&mouse_c.y);
	lbmouse_counter++;
	
	cursor->x=mouse_c.x;
	cursor->y=mouse_c.y;
	cursor->SetAnimation(4);
	
	switch(vmstate.state)
	{
		case AGS_MOSTRANDODIALOGO:
		{	
			roomview_height=480;

			if(camara_x<(max_scroll_x/2))
				camara_x++;
			else if(camara_x>(max_scroll_x/2))
				camara_x--;
			if(camara_y<(max_scroll_y/2))
				camara_y++;
			else if(camara_y>(max_scroll_y/2))
				camara_y--;

			d_selected=dialogger->Show(pScreen->GetBack(),mouse_c);
			

			if(pInput->GetKeyState(CDXKEY_MOUSELEFT)&&d_selected!=-1&&lbmouse_counter>LBUTTONWAIT)
			{
				lbmouse_counter=0;
				vmstate=statestack.GetPrevState();
				SetScript(&dialogger->GetDialog()->scripts[d_selected]);
				
				if(dialogger->GetDialog()->flags[d_selected]&REPETIR)
				{
					PauseScript();
					DisplayMessage(dialogger->GetDialog()->labels[d_selected]);
				}
				else
					ResumeScript();

				break;
			}
  		}break;

		case AGS_MOSTRANDOTEXTO:
		{
			//roomview_height=480;	

			counter--;

			if(pInput->GetKeyState(CDXKEY_MOUSELEFT)&&lbmouse_counter>LBUTTONWAIT)
			{
				lbmouse_counter=0;
				counter=0;
			}
			
			if(counter>0)
			{
				def_font->DrawTransEx(&msg_rect,curr_txt,pScreen->GetBack(),WORD_BREAK|CENTRADO);
			}
			else
			{
				vmstate=statestack.GetPrevState();

				//si hay un script, lo sigue
				if(vmstate.script)
					ResumeScript();
					
			}
			
  		}break;

		case AGS_EXPLORANDO:
		{	
			draw_gui=1;

			salida=-1;
			//inicializa variables de todo

			//ACCION
			if(accion.stage==ACCION_ESPERANDO_COMANDO)
				accion.comando=-1;
			if(accion.stage<=ACCION_ESPERANDO_PARAM1){
				accion.param1=-1;
				accion.param1_type=-1;
			}
			if(accion.stage<=ACCION_ESPERANDO_PARAM2){
				accion.param2=-1;
				accion.param2_type=-1;
			}


			//INVENTORIO
			inventorio.scrolling_down=0;
			inventorio.scrolling_up=0;

			//ACCION
			int mouse_over_action=-1;
			int mouse_over_obj=-1;

			//ROOM/CAMARA
			roomview_height=416-20;

			//INPUT
			bool mouse_button_pressed=0;


			if(pInput->GetKeyState(CDXKEY_MOUSELEFT)&&lbmouse_counter>LBUTTONWAIT)
			{
				lbmouse_counter=0;
				mouse_button_pressed=1;
			}	

			float cx=float(cursor->x)/roomview_width*max_scroll_x;
			float cy=float(cursor->y)/roomview_height*max_scroll_y;

			camara_x=cx;
			camara_y=cy;

		
			//est� en el GUI
			gui_cmd_panel.ResetPanel();
			if(cursor->y>action_txt_rct.top)
			{
				if(cursor->x<288)
				{
					mouse_over_action=gui_cmd_panel.IsOverButton(cursor->x,cursor->y);

					if(mouse_over_action!=-1)
					{
						gui_cmd_panel.SetButtonState(mouse_over_action,1);

						//cierra la elecci�n de comando
						if(mouse_button_pressed)
						{
							accion.Reset();
							accion.comando=mouse_over_action;
							accion.stage=ACCION_ESPERANDO_PARAM1;
						}
					}
				}
				else
				{
					//inventorio
					//------------------------------------------------------------------//
					if(inventorio.carried_objs)
					{
						//flechitas
						if(cursor->x<320)
						{	
						
							if(cursor->y<(416+32))
							{
								inventorio.scrolling_up=1;
								if(mouse_button_pressed&&inventorio.curr_page>0)
									inventorio.curr_page--;							
							}							
							else
							{
								inventorio.scrolling_down=1;
								if(mouse_button_pressed&&inventorio.curr_page<inventorio.n_pages-1)
									inventorio.curr_page++;
							}
						
						}
						else //objetos
						{						
							mouse_over_obj=inventorio.PointOverObject(cursor->x,cursor->y);
							if(mouse_over_obj!=-1)
							{	
								int obj_id=inventorio.inventorio[mouse_over_obj];
							
								if(accion.stage<ACCION_ESPERANDO_PARAM2)
								{
									//marca el objeto
									accion.param1=obj_id;
									accion.param1_type=ACCION_TIPO_OBJETOINV;
								
									//no hay accion ni objeto definido
									if(accion.stage==ACCION_ESPERANDO_COMANDO)
									{									
										accion.comando=-1;
										//ilumina el comando sugerido
										mouse_over_action=inventorio.objetos[obj_id].def_action;
										gui_cmd_panel.SetButtonState(mouse_over_action,1);									
									}

									if(mouse_button_pressed)
									{
										if(accion.stage==ACCION_ESPERANDO_COMANDO)
											accion.comando=mouse_over_action;
										accion.Close();
									}	
								}
							}//end if mouseover obj					
						}//end parte de objetos
					}
				//------------------------------------------------------------------//
				}
			}
			//no est� en el GUI
			else
			{
				if(cursor->y<40  &&roompack.rooms[curr_room].salidas[0]>=0)
					salida=0;
				else 
					if(cursor->x>600 &&roompack.rooms[curr_room].salidas[1]>=0)
						salida=1;
					else
						if(cursor->y>(action_txt_rct.top-20) &&roompack.rooms[curr_room].salidas[2]>=0)
							salida=2;
						else
							if(cursor->x<40  &&roompack.rooms[curr_room].salidas[3]>=0)
								salida=3;
			
				//mouseover text
				if(salida!=-1)
				{
					cursor->SetAnimation(salida);
					if(mouse_button_pressed)
						ChangeRoom(roompack.rooms[curr_room].salidas[salida]);
				}
				else
				{
					bool found_hotspot=0;
					for(int i=0;i<roompack.rooms[curr_room].n_hotspots;i++)
					{
						//si est� sobre un hotspot
						if(PtInRegion(roompack.rooms[curr_room].hotspot_rgns[i],cursor->x+camera_rct.left,cursor->y+camera_rct.top) &&!salidatxt)
						{
							found_hotspot=1;
							cursor->SetAnimation(5);

							//ya hay comando seleccionado
							if(accion.stage<ACCION_ESPERANDO_PARAM2)
							{
								//en cualquier caso este objeto entra como �nico par�metro
								accion.param1=i;
								accion.param1_type=ACCION_TIPO_HOTSPOT;

								//si no hay comando seleccionado
								if(accion.stage==ACCION_ESPERANDO_COMANDO)
								{
									//ilumina la opci�n sugerida
									if(mouse_over_action!=-1)
										gui_cmd_panel.SetButtonState(mouse_over_action,0);
									mouse_over_action=roompack.rooms[curr_room].xdata[i].def_action;
									gui_cmd_panel.SetButtonState(mouse_over_action,1);
								}
								//esto cerraria la acci�n
								if(mouse_button_pressed)
								{
									//si no habia comando elegido usa el sugerido
									if(accion.stage==ACCION_ESPERANDO_COMANDO)
										accion.comando=mouse_over_action;
									accion.Close();
								}							
							}
							break;
						}//end if PtInRgn
					}//end for

					if(!found_hotspot && mouse_button_pressed)
						accion.Reset();
				}//end if not salida
			}//end if y<416	
			
			//arma el txt con la accion
				accion.action_txt[0]='\0';
				if(accion.comando!=-1)
				{	
					if(accion.stage>0)
						gui_cmd_panel.SetButtonState(accion.comando,2);
					strcat(accion.action_txt,action_cmds[accion.comando]);
				}
				if(accion.param1!=-1)
				{
					strcat(accion.action_txt," ");
					if(accion.param1_type==ACCION_TIPO_OBJETOINV)
						strcat(accion.action_txt,inventorio.objetos[accion.param1].desc);
					else
						strcat(accion.action_txt,roompack.rooms[curr_room].hotspot_texts[accion.param1]);
				}
			
			if(accion.stage==ACCION_LISTO)
				EjecutarAccion();
			
				
		}break;
	
	}//end switch state	

			//dibuja el panel
			if(draw_gui)
			{		
				//dibuja el panel
				pScreen->GetBack()->FillRect(action_txt_rct.left,
										 action_txt_rct.top,
										 action_txt_rct.right,
										 480,0); //provisorio!
										 
				if(salida!=-1)
					mouseover_fnt->DrawTransEx(&action_txt_rct,roompack.rooms[curr_room].salida_txts[salida],pScreen->GetBack(),CENTRADO);
				else
					mouseover_fnt->DrawTransEx(&action_txt_rct,accion.action_txt,pScreen->GetBack(),CENTRADO);
			
			
				gui_cmd_panel.Draw(pScreen->GetBack());				
				inventorio.Draw(pScreen->GetBack());
		
			}

	cursor->Animar();
	cursor->Dibujar(0,0,pScreen->GetBack());
	
	if(changing_room>0)
	{
		changing_room--;
		if(!changing_room)
			roomfader->AlphaTransition(pScreen->GetFront(),
									   pScreen->GetBack());
	}
}

void LCL_AG::EjecutarAccion()
{
	/*----------------------------------------------------------------
	ac� puede haber 4 casos:

    CASO 1: acci�n con hotspot
	CASO 2: usar objeto con hotspot

    CASO 3: acci�n con objeto
	CASO 4: usar objeto con objeto	
	-----------------------------------------------------------------*/
	
	//provisorio
	char* caso3_txts[]={"No quiero explorar eso 0",
						"No quiero explorar eso 1",
						"No quiero explorar eso 2",

						"No quiero analizar eso 0",
						"No quiero analizar eso 1",
						"No quiero analizar eso 2",

						"No quiero usar eso 0",
						"No quiero usar eso 1",
						"No quiero usar eso 2",

						"No quiero dialogar con eso 0",
						"No quiero dialogar con eso 1",
						"No quiero dialogar con eso 2"};


	//CASOS 1 y 2	
	if(accion.param1_type==ACCION_TIPO_HOTSPOT)
	{
		bool found_event=0;
		for(int e=0;e<roompack.rooms[curr_room].xdata[accion.param1].n_events;e++)
		{
			//encontr� un evento
			if(roompack.rooms[curr_room].xdata[accion.param1].events[e].event_type==accion.comando)
			{			
				found_event=1;
				SetScript(roompack.rooms[curr_room].xdata[accion.param1].events[e].script);
				ResumeScript();
				break;
			}
		}
		if(!found_event)
			DisplayMessage("No creo que sea una buena idea");
	}
	else		
		{
			//CASO 3
			if(accion.param2==-1)
			{
				if(inventorio.objetos[accion.param1].scripts[accion.comando])
				{
					SetScript(inventorio.objetos[accion.param1].scripts[accion.comando]);
					ResumeScript();
				}
				else
					DisplayMessage(caso3_txts[accion.comando+rand()%3]);
			}

		}

	accion.Reset();
}


//FUNCIONES DEL JUEGO
//----------------------------------------------------------------------------------------

//mensajes y di�logos
/*
void LCL_AG::DoDialog(int dialog_id)
{
	draw_gui=0;
	dialogger->SetDialog(&dialogpack.dialogos[dialog_id]);
	statestack.SaveState(vmstate);
	vmstate.state=AGS_MOSTRANDODIALOGO;
	vmstate.script=0;
}

void LCL_AG::DisplayMessage(char* txt)
{
	counter=text_delay+strlen(txt);
	strcpy(curr_txt,txt);
	
	statestack.SaveState(vmstate);
	vmstate.state=AGS_MOSTRANDOTEXTO;
	vmstate.script=0;
}

void LCL_AG::ChangeRoom(int newroom)
{
	prev_room=curr_room;
	curr_room=newroom;

	changing_room=2;

	//cambia la m�sica (acordarse que los temas se numeran en el editor desde
	//                  1 y en el array desde 0)

	if(roompack.rooms[curr_room].music)
	{
		//si no es la misma que la anterior, la pasa
		if(roompack.rooms[curr_room].music!=roompack.rooms[prev_room].music)
			pSonido->PlayOGG(roompack.rooms[curr_room].music-1,true);

		pSonido->SetOGG_Vol(roompack.rooms[curr_room].volumen);
	}
}
*/



//GAME OBJECTS
//----------------------------------------------------------------------------------------

LCL_AG escena3;
LCL_AG* curr_ag=&escena3;



//mensajes y di�logos

void DoDialog(int dialog_id)
{
	curr_ag->draw_gui=0;
	curr_ag->dialogger->SetDialog(&curr_ag->dialogpack.dialogos[dialog_id]);
	curr_ag->statestack.SaveState(curr_ag->vmstate);
	curr_ag->vmstate.state=AGS_MOSTRANDODIALOGO;
	curr_ag->vmstate.script=0;
}

void DisplayMessage(char* txt)
{
	curr_ag->counter=curr_ag->text_delay+strlen(txt);
	strcpy(curr_ag->curr_txt,txt);
	
	curr_ag->statestack.SaveState(curr_ag->vmstate);
	curr_ag->vmstate.state=AGS_MOSTRANDOTEXTO;
	curr_ag->vmstate.script=0;
}

void ChangeRoom(int newroom)
{
	//-1 significa ir al cuarto anterior	
	if(newroom==-1)
	{
		curr_ag->curr_room=curr_ag->prev_room;
	}
	else
	{
		curr_ag->prev_room=curr_ag->curr_room;
		curr_ag->prev_room=curr_ag->curr_room;
		curr_ag->curr_room=newroom;
	}


	//actualiza el nro de visitas
	curr_ag->roompack.rooms[curr_ag->curr_room].visited++;

	//2 flippings de pantalla para el fade
	curr_ag->changing_room=2;


	//cambia la m�sica (acordarse que los temas se numeran en el editor desde
	//                  1 y en el array desde 0)
	if(curr_ag->roompack.rooms[curr_ag->curr_room].music)
	{
		//si no es la misma que la anterior, la pasa
		if(curr_ag->roompack.rooms[curr_ag->curr_room].music!=curr_ag->roompack.rooms[curr_ag->prev_room].music)
			curr_ag->pSonido->PlayOGG(curr_ag->roompack.rooms[curr_ag->curr_room].music-1,true);

		//curr_ag->pSonido->SetOGG_Vol(curr_ag->roompack.rooms[curr_ag->curr_room].volumen);
	}
}






// ------------------------------------------------------------------------------------------
// FiniApp - Destroy the CDX objects
// ------------------------------------------------------------------------------------------
void FiniApp(void)
{
	//GAME OBJECTS
	//--------------------------------------------------------------------//

	escena3.Apagar();

	//SYSTEM
	//--------------------------------------------------------------------//
	Sonido.ShutDown();

    SAFEDELETE( Screen );       // delete the screen object	
	SAFEDELETE( Input );       // delete the screen object		
}


// ------------------------------------------------------------------------------------------
// WinProc, this handles all windows messages
// ------------------------------------------------------------------------------------------
long PASCAL WinProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static POINT mousepos;

	switch(message)
	{

		case WM_KEYDOWN:
		{
				switch(wParam)      // if ESC key is hit, quit program
			    {
					case VK_ESCAPE:
					{						
						//bActive=false;
						//FiniApp();
						DestroyWindow(hwnd);
					}break;				
				}
				return 0;
		}break;

		case WM_MOUSEMOVE:
			{
				escena3.mouse_c.x = LOWORD(lParam);  // horizontal position of cursor 
				escena3.mouse_c.y = HIWORD(lParam);  // vertical position of cursor 
				return 0;

			}break;
				
		case WM_DESTROY:
			{
				PostQuitMessage(0); // terminate program
				return 0;
			}break;
	}

	return DefWindowProc(hwnd, message, wParam, lParam);
}
// ------------------------------------------------------------------------------------------



//
// ------------------------------------------------------------------------------------------
BOOL CALLBACK configdlgproc(HWND hwndDlg,UINT message,WPARAM wParam,LPARAM lParam) 
{ 
	static HBITMAP startup;
	static HDC bdc;
	HDC hdc;
	PAINTSTRUCT ps;
	
    switch (message) 
    { 

		case WM_PAINT:
		{
			hdc=BeginPaint(hwndDlg,&ps);
			SelectObject(bdc,startup);
			BitBlt(hdc,0,0,254,100,bdc,0,0,SRCCOPY);
			EndPaint(hwndDlg,&ps);			
		}break;

		case WM_INITDIALOG:
		{
			//el logo de startup
			DWORD size;
			void* img=DumpFileToMem("startup.jpg",&size);
			hdc=GetDC(hwndDlg);
			bdc=CreateCompatibleDC(hdc);
			startup=CargarJPG(hdc,img,size);
			delete img;

			ReleaseDC(hwndDlg,hdc);			
			

			
			//posiciona en el centro
			RECT dlg_rct;
			GetWindowRect(hwndDlg,&dlg_rct);
			SetWindowPos(hwndDlg,HWND_TOPMOST,
								   (GetSystemMetrics(SM_CXSCREEN)-(dlg_rct.right-dlg_rct.left))/2,
				 				   (GetSystemMetrics(SM_CYSCREEN)-(dlg_rct.bottom-dlg_rct.top))/2,
								   0,0,SWP_NOSIZE);

			//checks			
			SendDlgItemMessage(hwndDlg,IDC_FULLSCREEN,BM_SETCHECK,(WPARAM)BST_CHECKED,0);
			SendDlgItemMessage(hwndDlg,IDC_16BIT,BM_SETCHECK,(WPARAM)BST_CHECKED,0);
			SendDlgItemMessage(hwndDlg,IDC_LOFI,BM_SETCHECK,(WPARAM)BST_CHECKED,0);
			
			
		}break;

        case WM_COMMAND: 
            switch (LOWORD(wParam)) 
            { 
                case IDOK: 
					{
						if(SendDlgItemMessage(hwndDlg,IDC_FULLSCREEN,BM_GETCHECK,0,0)==BST_CHECKED)
							fullscreen=1;
						else
							fullscreen=0;
						
						if(SendDlgItemMessage(hwndDlg,IDC_16BIT,BM_GETCHECK,0,0)==BST_CHECKED)
							bpp=16;
						else
							bpp=32;				

						EndDialog(hwndDlg,true);
						return TRUE;
					}
    
            } 

			case WM_DESTROY:
				{
					DeleteObject(startup);
					DeleteDC(bdc);
				}break;
    } 
    return FALSE; 
} 




// ------------------------------------------------------------------------------------------
// InitApp - Create the window and the CDX objects
// ------------------------------------------------------------------------------------------
BOOL InitApp(HINSTANCE hInst, int nCmdShow)
{	
	WNDCLASS    WndClass;
	DWORD       dwStyle;

	//parent window
	WndClass.style = CS_HREDRAW | CS_VREDRAW|CS_OWNDC;
	WndClass.lpfnWndProc = WinProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInst;
	WndClass.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(APP_ICON));
	WndClass.hCursor = LoadCursor(0, IDC_ARROW);
	WndClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	WndClass.lpszMenuName = 0;//MAKEINTRESOURCE(IDR_MENU);
	WndClass.lpszClassName = NAME;
	RegisterClass(&WndClass);

	dwStyle=WS_OVERLAPPEDWINDOW;

	
	//di�logo de configuraci�n
	//--------------------------------------------------------//
#ifdef PREGUNTARCONFIG
	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_CONFIG),0,configdlgproc,0);
#endif
	//--------------------------------------------------------//

	if(fullscreen)
		dwStyle=WS_POPUP;	
		
	hWnd = CreateWindowEx(0,
						  NAME,TITLE,
						  dwStyle,
						  0,
						  0,
						  SCREEN_WIDTH,SCREEN_HEIGHT,
						  NULL,NULL,hInst,NULL);

	//Window Setup
	//-----------------------------------------------------------------//
	if(!fullscreen)
	{
		SetWindowLong(hWnd,GWL_STYLE,dwStyle);
		// set the client area size to SCREEN_WIDTH , SCREEN_HEIGHT
		RECT rc;
		SetRect(&rc, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
		AdjustWindowRectEx(&rc,GetWindowStyle(hWnd),GetMenu(hWnd) != NULL,
						   GetWindowExStyle(hWnd));

		// set windows coordinates to 0,0
		SetWindowPos(hWnd, NULL, 0, 0, rc.right-rc.left, rc.bottom-rc.top,
					 SWP_NOZORDER | SWP_NOACTIVATE);

		SetWindowPos(hWnd, HWND_NOTOPMOST,
			(GetSystemMetrics(SM_CXSCREEN)-SCREEN_WIDTH)/2,
			(GetSystemMetrics(SM_CYSCREEN)-SCREEN_HEIGHT)/2,
			0, 0,SWP_NOSIZE | SWP_NOACTIVATE);	
	}



    // Create the CDXSreen object
	Screen = new CDXScreen();

	if(fullscreen)
	{
		if( FAILED(Screen->CreateFullScreen(hWnd,SCREEN_WIDTH,SCREEN_HEIGHT,DEF_BPP)))
			MessageBox(0,"Error al inicializar video",0,0);
	}
	else
	{
		if( FAILED(Screen->CreateWindowed(hWnd, SCREEN_WIDTH, SCREEN_HEIGHT)))
			MessageBox(0,"Error al inicializar video",0,0);
	}		


	//-----------------------------------------------------------------//

	// show the main window
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	//Input
	//-----------------------------------------------------------------//
	Input = new CDXInput( );
	if( Input == NULL )
		MessageBox(0,"Error al inicializar DirectInput",0,0);

	Input->SetActiveDevices(MOUSE,KEYBOARD,0);
	
	/*
	if(MOUSE)
		Input->SetMouseAbs();
		*/

	if( Input->Create(hInst , hWnd ) < 0 )
		MessageBox(0,"Error al crear DirectInput",0,0);
	//-----------------------------------------------------------------//


	//Sonido
	//-----------------------------------------------------------------//
	if(!Sonido.Init(hWnd,44100,200))
		MessageBox(0,"Error en sonido",0,0);


	//GAME OBJS
	//-----------------------------------------------------------------//

	escena3.Init(Screen,Input,&Sonido);
	escena3.Cargar();

	//inits de prueba
	//escena3.DoDialog(0);	
	
	return TRUE;
}
// ------------------------------------------------------------------------------------------


// ------------------------------------------------------------------------------------------
// WinMain
// ------------------------------------------------------------------------------------------
int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	DWORD t,
		  t0=0,
		  fps_const;
	fps_const=1000/MIN_FPS;
	
	if(!InitApp(hInst, nCmdShow))
        MessageBox(0,"Error al inicializar",0,0);

	if(MOUSE)
		Input->SetMouseLimits( 0 , 0 , 
                           SCREEN_WIDTH ,
                           SCREEN_HEIGHT);
	
	t=GetTickCount();
	t0=t;

    //if(fullscreen)
		ShowCursor(0);

	while(1)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if(!GetMessage(&msg, NULL, 0, 0 )) goto APAGAR;
			TranslateMessage(&msg); 
			DispatchMessage(&msg);
		}
		else if(bActive)                            // if application has the focus, process
		{
		//frame dependant
		//------------------------------------------------------//
			t=GetTickCount();
			if( (t-t0)>=fps_const)
			{
				t0=GetTickCount();
				//INPUT
				// update the input object
				Input->Update( );
			
				escena3.Tick();

				Screen->Flip();
			}			
		//------------------------------------------------------//
		//tutto il tempo
		//------------------------------------------------------//
		
		//------------------------------------------------------//
		}
		else WaitMessage();
	}

APAGAR:
	
	FiniApp();			// destroy all objects
	MessageBox(0,"Debug Checkpoint: Hasta ac� llega sin colgarse","Viste Rocky, vos pod�as...",0);

	return 0;	
}
// ------------------------------------------------------------------------------------------







