#include "LCL_Mapa.h"

#define SECTOR_WIDTH	640
#define SECTOR_HEIGHT	480

//MAPA
//******************************************************************

//-----------------------------------------------------------------//
void LCL_Mapa::Setear_Vista(int x0,int y0,int x1,int y1)
//-----------------------------------------------------------------//
{
	//rect de la vista
	view_rect.left=x0;
	view_rect.top=y0;
	view_rect.right=x1;
	view_rect.bottom=y1;
	
	//width y height para cuando hagan falta
	v_width=x1-x0;
	v_height=y1-y0;

	//numero de filas y columnas que dibujar para llenar la vista
	n_tiles_to_draw_x=v_width/tile_width+2;
	n_tiles_to_draw_y=v_height/tile_height+2;

	//m�xima posici�n de scrolling
	mapa_maxpos_x=map_width_in_px-v_width;
	mapa_maxpos_y=map_height_in_px-v_height;
	
	//posici�n inicial
	mapa_pos_x=0;
	mapa_pos_y=0;	
}
//-----------------------------------------------------------------//

//-----------------------------------------------------------------//
int LCL_Mapa::DibujarFila(CDXSurface* surf,int fila)
//-----------------------------------------------------------------//
{
	//lo mismo que para dibujarpiso
	int start_tile_x=mapa_pos_x/tile_width;
	int start_tile_y=mapa_pos_y/tile_height;

	int offset_x=mapa_pos_x%tile_width;
	int offset_y=mapa_pos_y%tile_height;

	int n_ttdx=n_tiles_to_draw_x;
	int n_ttdy=n_tiles_to_draw_y;

	if((start_tile_x+n_ttdx)>map_width_in_t)
		n_ttdx=map_width_in_t-start_tile_x;

	if((start_tile_y+n_ttdy)>map_height_in_t)
		n_ttdy=map_height_in_t-start_tile_y;

	if(fila>=n_ttdy-1)return 0;

	//dibuja la fila
	int ti_y=-offset_y+fila*tile_height;
	for(int ix=0;ix<n_ttdx;ix++)
	{
		int ti_x=-offset_x+ix*tile_width;
		
		MAPCEL* map_celp=&map_array[(fila+start_tile_y)*map_width_in_t+ix+start_tile_x];

		//capa
		for(int i=1;i<n_capas;i++)
		{
			if(map_celp->nivel[i])
			{
				//transparente o no
				if(tiles->transparente[map_celp->nivel[i]])
					tiles->BlitCelTrans(surf,ti_x,ti_y-(i-1)*tile_width,map_celp->nivel[i]);		
				else
					tiles->BlitCel(surf,ti_x,ti_y-(i-1)*tile_width,map_celp->nivel[i]);		
			}
		}
	}

	return ti_y+32;
}
//-----------------------------------------------------------------//


//-----------------------------------------------------------------//
void LCL_Mapa::DibujarPiso(CDXSurface* surf)
//-----------------------------------------------------------------//
{
	int start_tile_x=mapa_pos_x/tile_width;
	int start_tile_y=mapa_pos_y/tile_height;

	int offset_x=mapa_pos_x%tile_width;
	int offset_y=mapa_pos_y%tile_height;

	int n_ttdx=n_tiles_to_draw_x;
	int n_ttdy=n_tiles_to_draw_y;
	
	if((start_tile_x+n_ttdx)>map_width_in_t)
		n_ttdx=map_width_in_t-start_tile_x;

	if((start_tile_y+n_ttdy)>map_height_in_t)
		n_ttdy=map_height_in_t-start_tile_y;

	for(int iy=0;iy<n_ttdy;iy++)
		for(int ix=0;ix<n_ttdx;ix++)
		{
			int ti_x=-offset_x+ix*tile_width;
			int ti_y=-offset_y+iy*tile_height;
			
			MAPCEL* map_celp=&map_array[(iy+start_tile_y)*map_width_in_t+ix+start_tile_x];
			
			//dibuja grilla (DEBUG & EDIT ONLY)
			surf->FillRect(ti_x,ti_y,ti_x+tile_width,ti_y+tile_height,80*((ix+start_tile_x+iy+start_tile_y)%2));
			//end DAEO

			//piso
			if(map_celp->nivel[0])
			{
				//transparente o no
				if(tiles->transparente[map_celp->nivel[0]])
					tiles->BlitCelTrans(surf,ti_x,ti_y,map_celp->nivel[0]);		
				else
					tiles->BlitCel(surf,ti_x,ti_y,map_celp->nivel[0]);		
			}
		}
}
//-----------------------------------------------------------------//


//-----------------------------------------------------------------//
void LCL_Mapa::Mover(int* x,int* y)
//-----------------------------------------------------------------//
{
	if(*x<0)*x=0;
	if(*y<0)*y=0;

	if(*x>mapa_maxpos_x)*x=mapa_maxpos_x;
	if(*y>mapa_maxpos_y)*y=mapa_maxpos_y;

	mapa_pos_x=*x;
	mapa_pos_y=*y;	
}
//-----------------------------------------------------------------//



//-----------------------------------------------------------------//
void LCL_Mapa::NuevoMapa(int p_ntiles_x,int p_ntiles_y,int p_ncapas)
//-----------------------------------------------------------------//
{
	int ix,iy;

	map_array=new MAPCEL[p_ntiles_x*p_ntiles_y];

	//Metrics
	map_width_in_t=p_ntiles_x;
	map_height_in_t=p_ntiles_y;

	tile_width =32;
	tile_height =32;

	map_width_in_px=tile_width*map_width_in_t;	
	map_height_in_px=tile_height*map_height_in_t;

	n_capas=p_ncapas;

	//inicializa las capas
	for(iy=0;iy<map_height_in_t;iy++)
		for(ix=0;ix<map_width_in_t;ix++)
		{			
			map_array[iy*map_width_in_t+ix].nivel=new CAPA[n_capas];
			ZeroMemory(map_array[iy*map_width_in_t+ix].nivel,n_capas*sizeof(CAPA));
		}

		
	//SECTORES

	sector_width=SECTOR_WIDTH;
	sector_height=SECTOR_HEIGHT;

	n_sectors_x=map_width_in_px/sector_width;
	if(sector_width*n_sectors_x<map_width_in_px)
		n_sectors_x++;
	n_sectors_y=map_height_in_px/sector_height;
	if(sector_height*n_sectors_y<map_height_in_px)
		n_sectors_y++;
	
	sectores=new Sector[n_sectors_x*n_sectors_y];

	//inicializa los sectores
	for(iy=0;iy<n_sectors_y;iy++)
		for(ix=0;ix<n_sectors_x;ix++)
		{
			int s_width=sector_width;
			int s_height=sector_height;

			//setea los l�mites
			sectores[iy*n_sectors_x+ix].SetLimits(ix*sector_width,
												  iy*sector_height,
												  s_width,
												  s_height);			
			//datos espec�ficos a cada sector
			int sector_code=iy*n_sectors_x+ix;
		}	
}
//-----------------------------------------------------------------//


//-----------------------------------------------------------------//
void LCL_Mapa::AsignarTileset(LCL_Tile* tileset)
//-----------------------------------------------------------------//
{
	//lo que ya se sabe
	tiles=tileset;
}
//-----------------------------------------------------------------//


//m�s que nada para el editor
MAPCEL* LCL_Mapa::GetMapcel_px(int x,int y)
{
	return &map_array[(y/tile_height)*map_width_in_t+(x/tile_width)];
}


//MAPA
//******************************************************************


//---------------------------------------------------------------------//
void Sector::Clear()
//---------------------------------------------------------------------//
{
	sprites.Clear(1);
	obj_count=0;
	if(array)
		free(array);
}
//---------------------------------------------------------------------//



//---------------------------------------------------------------------//
void Sector::SetLimits(int x0,int y0,int width,int height)
//---------------------------------------------------------------------//
{
	sector_rct.left=x0;
	sector_rct.top=y0;
	sector_rct.right=x0+width-1;
	sector_rct.bottom=y0+height-1;
}
//---------------------------------------------------------------------//


//---------------------------------------------------------------------//
void Sector::SortearArray()
//---------------------------------------------------------------------//
{
	int p = 0, h = 0, k = 0, i = 0, j = 0; 
	LCL_Sprite* temp; 
	
	if (obj_count < 2) return; 
	
	for ( p = 0; p < obj_count-1; p++ ) 
	{ 
		h = p; 
		for ( k = p + 1; k < obj_count ; k++ ) 
		{
			if ((array[k]->y < array[h]->y)	||
				((array[k]->y == array[h]->y))&&
				(array[k]->x < array[h]->x)	||
				((array[k]->y == array[h]->y))&&
				(array[k]->x == array[h]->x)	&&
				(array[k]->id < array[h]->id)) 
					h = k; 
		}
			
		if ( p != h ) 
		{ 
			i = h; 
			j = p; 
			temp = array[i]; 
			array[i] = array[j]; 
			array[j] = temp;
		}
	}
}
//---------------------------------------------------------------------//
		
