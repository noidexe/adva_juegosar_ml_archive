// ------------------------------------------------------------------------------------------
// FILE: LCL_EXTENSIONS.H
//
//
// ------------------------------------------------------------------------------------------

#ifndef LCL_MAPA
#define	LCL_MAPA

#include <windows.h>

//CDX LITE
#include "CDX.h"
#include "cdxscreen.h"
#include "cdxsurface.h"

#include "LCL_Tile.h"
#include "LCL_Sprite.h"


#define CAPA int

typedef struct _MAPCEL
{	
	CAPA* nivel;
} MAPCEL;


class Sector{	
	void Llenar_Array()
	{
		//realloquea el array
		if(array)
			array=(LCL_Sprite**)realloc(array,sizeof(LCL_Sprite*)*obj_count);
		else
			array=(LCL_Sprite**)malloc(sizeof(LCL_Sprite*)*obj_count);

		//llena el array
		LCL_Sprite* node;
		int i=0;
		for(node=sprites.GetFirst();node!=0;node=sprites.GetNext(node))
		{
			array[i]=node;i++;
		}
	}	
public:
	LCL_Sprite** array;
	RECT sector_rct;
	LCL_SpriteList sprites;	
	int obj_count;
	Sector(){obj_count=0;array=0;}	
	~Sector(){
		Clear();
	}
	void SortearArray();
	void AgregarSprite(LCL_Sprite* object)
	{
		//lo agrega a la lista
		sprites.AddLCL_Sprite(object);
		obj_count++;
		Llenar_Array();		
	}
	void RemoverSprite(LCL_Sprite* object)
	{
		//lo agrega a la lista
		sprites.DelLCL_Sprite(object,0);
		obj_count--;
		Llenar_Array();
	}
	void SetLimits(int x0,int y0,int width,int height);
	void Clear();
};

class LCL_Mapa
{
	//datos del mapa
	LCL_Tile*	tiles;
	MAPCEL*		map_array;
	int			n_capas;
	int			map_width_in_t;		//dimensiones
	int			map_height_in_t;	//EN TILES
	int			map_width_in_px;	//dimensiones
	int			map_height_in_px;	//EN PIXELS
	int			tile_width;
	int			tile_height;

	//vista
	RECT		view_rect;	
	int			v_width;
	int			v_height;	
	int			n_tiles_to_draw_x;
	int			n_tiles_to_draw_y;

	//sectores	
	int			sector_width;
	int			sector_height;

	//posicion
	int mapa_pos_x;
	int mapa_pos_y;

	int mapa_maxpos_x;
	int mapa_maxpos_y;
	
public:
	//sectores
	Sector*		sectores;
	int			n_sectors_x;
	int			n_sectors_y;

	void Setear_Vista(int x0,int y0,int x1,int y1);
	void DibujarPiso(CDXSurface* surf);
	int	 DibujarFila(CDXSurface* surf,int fila);
	void Mover(int* x,int* y);
	void NuevoMapa(int p_ntiles_x,int p_ntiles_y,int p_ncapas);
	void AsignarTileset(LCL_Tile* tileset);
	MAPCEL* GetMapcel_px(int x,int y);
	int GetMapWidth_px(){return map_width_in_px;}
	int GetMapHeight_px(){return map_height_in_px;}
	int GetMapWidth_t(){return map_width_in_t;}
	int GetSectorWidth(){return sector_width;}
	int GetSectorHeight(){return sector_height;}
	int GetMapHeight_t(){return map_height_in_t;}
	int GetNCapas(){return n_capas;}
	MAPCEL* GetMapArray(){return map_array;}
	LCL_Mapa(){
		map_array=0;
		tiles=0;
	}
	~LCL_Mapa(){
		int ix,iy;
		MessageBox(0,"Destruyendo mapa...",0,0);
		if(map_array)
		{
		/*	
			//borra el map_array
			for(iy=0;iy<map_height_in_t;iy++)
				for(ix=0;ix<map_width_in_t;ix++)
					if(map_array[iy*map_width_in_t+ix].nivel)
						delete []map_array[iy*map_width_in_t+ix].nivel;
		*/	

			
		}	
	}
};

#endif