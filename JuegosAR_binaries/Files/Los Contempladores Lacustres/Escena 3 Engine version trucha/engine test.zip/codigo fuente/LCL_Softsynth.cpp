#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "LCL_SoftSynth.h"

#include "utils.h"


//GLOBALS
//--------------------------------------------------------------//

//sistema y control de eventos
CDSoundSystem CSonido;
	
//playerthread
HANDLE rghEvent[2];
DWORD playerthread_id;
HANDLE playerthread;
DWORD WINAPI Player_Thread(LPVOID data);

//output callback
//void(*lpoutputfcn)(short*,long,int);

//OGG STREAMS
//-------------------------------------------------------------//
#define MAX_OGG_STREAMS 16

//stream buffer
short* streambuffer;

int volumen_ogg=100;
OGGSTREAM* curr_ogg;
OGGSTREAM* oggs[MAX_OGG_STREAMS];

//--------------------------------------------------------------//



/*----------------------------------------------------------------------------
COPIADO Y PEGADO DE ALOGG
una libreria para usar OGGS en Allegro de Javier Gonz�lez
----------------------------------------------------------------------------*/
size_t  _alogg_ogg_read(void *ptr, size_t size, size_t nmemb, void *datasource)
{
  OGGSTREAM *ogg = (OGGSTREAM *)datasource;
  int data_pos = ogg->data_cursor - (char *)ogg->data;
  int data_left = ogg->data_len - data_pos;
  int bytes_asked = size * nmemb;

  /* check how much we can copy */
  if (bytes_asked <= data_left) {
    /* we can copy it all */
    memcpy(ptr, (const void *)ogg->data_cursor, bytes_asked);
    ogg->data_cursor += bytes_asked;
    /* all items read */
    return nmemb;
  }
  else {
    int items = data_left / size;
    int bytes = items * size;
    /* check we are copying at least one item */
    if (items < 1)
      return 0;
    /* copy whatever we have left */
    memcpy(ptr, (const void *)ogg->data_cursor, bytes);
    ogg->data_cursor += bytes;
    /* return how many items we read */
    return items;
  }
}

int _alogg_ogg_seek(void *datasource, ogg_int64_t offset, int whence) {
  OGGSTREAM *ogg = (OGGSTREAM *)datasource;
  char *new_data_cursor;

  if (whence == SEEK_CUR)
    new_data_cursor = ogg->data_cursor + offset;
  else if (whence == SEEK_SET)
    new_data_cursor = (char *)ogg->data + offset;
  else if (whence == SEEK_END)
    new_data_cursor = (char *)ogg->data + ogg->data_len + offset;
  else
    return -1;

  /* check the new pointer is valid */
  if ((new_data_cursor < (char *)ogg->data) ||
     (new_data_cursor > ((char *)ogg->data + ogg->data_len))) {
    return -1;
  }
  else {
    ogg->data_cursor = new_data_cursor;
    return 0;
  }
}

int _alogg_ogg_close(void *datasource) {
  OGGSTREAM *ogg = (OGGSTREAM *)datasource;
  ogg->data_cursor = (char *)ogg->data;

  return 0;
}

long _alogg_ogg_tell(void *datasource) {
  OGGSTREAM *ogg = (OGGSTREAM *)datasource;
  return (ogg->data_cursor - (char *)ogg->data);
}

ov_callbacks _alogg_ogg_callbacks = {&_alogg_ogg_read,
									 &_alogg_ogg_seek,
									 &_alogg_ogg_close,
									 &_alogg_ogg_tell};
//----------------------------------------------------------------------------
//end alogg

/*
void prueba(short* sndbuffer,long n_samples,int ticklength)
{
	static t=0;
	//por cada sample:			
	for(long i=0;i<n_samples;i++)
	{		
		float output=ambient->Tick();
		sndbuffer[i]=output;

	
			
	}//end for nsamples	
}
*/


void OGGStream(short* sndbuffer,long n_samples)
{	
	char* buffer=(char*)streambuffer;
	long bytes_read=0;
	long last_pos=0;
	long total_bytes=n_samples;
	
	while (bytes_read<total_bytes)
	{
		long bytes_to_read=total_bytes-bytes_read;
		long ret=ov_read(&curr_ogg->vf, &buffer[bytes_read],min(bytes_to_read,4096),0,2,1,&curr_ogg->current_section);
		if(ret==0)
		{
			if(curr_ogg->loop)
				ov_raw_seek(&curr_ogg->vf,0);
			else
				curr_ogg=0;
			break;
		}
		if(ret==OV_HOLE ||ret==OV_EBADLINK )continue;
		bytes_read+=ret;		
	}     

	//buffer+=bytes_read;
	for(long i=0,long j=0;i<n_samples;i+=2,j++)
	{
		sndbuffer[i]+=streambuffer[j]*volumen_ogg/100;
		sndbuffer[i+1]+=streambuffer[j]*volumen_ogg/100;
	}

	
}




//player thread
//--------------------------------------------------------------//

//--------------------------------------------------------------------//

DWORD WINAPI Player_Thread(LPVOID data)

//--------------------------------------------------------------------//
{
	static short* sndbuffer;
	static LONG n_samples;	
	
	//prueba
	static DWORD t=0;

	while(1)
	{
		DWORD dwEvt = MsgWaitForMultipleObjects(2,rghEvent,false,INFINITE,QS_ALLEVENTS);
		dwEvt -= WAIT_OBJECT_0;
 
		if (dwEvt < 2) 
		{
			CSonido.dwPos=dwEvt;
			if(CSonido.OpenStreamBuffer(&sndbuffer,&n_samples))
			{
				//AC� VA LA SALIDA DE SONIDO (REAL TIME!)
				//------------------------------------------------------------------//
				ZeroMemory(sndbuffer,n_samples*2);

				if(curr_ogg)
					OGGStream(sndbuffer,n_samples);
				//prueba
				//(*lpoutputfcn)(sndbuffer,n_samples,0);
				//end prueba	
				
				/*
				//clipping
				if(sndbuffer[i]>32000)
					sndbuffer[i]=32000;
				if(sndbuffer[i]<-32000)
					sndbuffer[i]=-32000;			
					*/
		

				CSonido.CloseStreamBuffer();     
			}
	}//end if dwEvt

	}//end while
	return 1;
}
//--------------------------------------------------------------------//


// LCL Softsynth
//--------------------------------------------------------------//

int LCL_SoftSynth::Init(HWND hwnd,int sample_rate,int latency)
{
		//PLATER DATA
		pd.bpm=125;
		pd.samplerate=sample_rate;
		pd.ticklength=pd.samplerate*60/pd.bpm/4;

		if(!CSonido.Init(hwnd,sample_rate,latency))
			return 0;

		CSonido.GetEventHandles(rghEvent);

		playerthread=CreateThread(0,0,
								  Player_Thread,
								  0,
						          0 ,
						          &playerthread_id);

		//OGG
		//--------------------------------------------------//
//caprichos de libfilevorbis
#ifdef _WIN32
		_setmode( _fileno( stdin ), _O_BINARY );
		_setmode( _fileno( stdout ), _O_BINARY );
#endif

		curr_ogg=0;

		for(int i=0;i<MAX_OGG_STREAMS;i++)
			oggs[i]=0;
	

		streambuffer=new short[CSonido.bufSize];


		
		//--------------------------------------------------//
		//SetOutputCallBack(prueba);

		return 1;
}

void LCL_SoftSynth::ShutDown()
{	
	CSonido.Stop();
	CloseHandle(playerthread);

	//ogg shutdown
	for(int i=0;i<MAX_OGG_STREAMS;i++)
			FreeOGG(i);
	delete streambuffer;

	//system shutdown
	CSonido.ShutDown();		
}


void LCL_SoftSynth::Play()
{
	CSonido.Play();
	ResumeThread(playerthread);
}

void LCL_SoftSynth::Stop()
{
	SuspendThread(playerthread);
	CSonido.Stop();
}

/*
void LCL_SoftSynth::SetOutputCallBack(void(*p_lpoutputfcn)(short*,long,int))
{	
		lpoutputfcn=p_lpoutputfcn;
}
*/


HOGGSTREAM LCL_SoftSynth::LoadOGG(char* filename)
{
	//parte reeemplazable
	DWORD size;
	void* oggbuffer=DumpFileToMem(filename,&size);
	//end pr

	OGGSTREAM* ogg=new OGGSTREAM;

	/* fill in the ogg struct */
	ogg->data = oggbuffer;
	ogg->data_cursor = (char *)ogg->data;
	ogg->data_len = size;
	memset((void *)&ogg->vf, 0, sizeof(ogg->vf));
	ogg->loop=1;
	ogg->current_section=-1;

	/* use vorbisfile to open it */
	long ret = ov_open_callbacks((void *)ogg, &(ogg->vf), NULL, 0, _alogg_ogg_callbacks);

	/* if error */
	if (ret < 0) {
		delete ogg->data;
		delete ogg;
		MessageBox(0,"Error al abrir el ogg",0,0);
		return -1;	
	}

	//lo alloquea
	int i=0;
	while(oggs[i])i++;

	oggs[i]=ogg;

	return i;
}

void LCL_SoftSynth::FreeOGG(HOGGSTREAM hoggstream)
{
	if(oggs[hoggstream])
	{
		delete oggs[hoggstream]->data;		
		ov_clear(&oggs[hoggstream]->vf);    
		delete oggs[hoggstream];

		oggs[hoggstream]=0;
	}
}

void LCL_SoftSynth::PlayOGG(HOGGSTREAM hoggstream,bool loop)
{
	OGGSTREAM* prev_ogg=curr_ogg;
	curr_ogg=oggs[hoggstream];
	curr_ogg->loop=loop;
	ov_raw_seek(&curr_ogg->vf,0);	

	if(prev_ogg)
		ov_crosslap(&prev_ogg->vf, &curr_ogg->vf);
}

void LCL_SoftSynth::SetOGG_Vol(int volumen)
{
	volumen_ogg=volumen;
}



