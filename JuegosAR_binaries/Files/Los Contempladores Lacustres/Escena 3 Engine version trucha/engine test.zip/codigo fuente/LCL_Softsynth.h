#ifndef LCL_SOFTSYNTH
#define LCL_SOFTSYNTH

#include <windows.h>

#include "dsoundsystem.h"

#include "synths_and_fx.h"

//para OGG playback
#include "vorbis/codec.h"
#include "vorbis/vorbisfile.h"

#ifdef _WIN32
#include <io.h>
#include <fcntl.h>
#endif


//types
//------------------------------------------------------------------//

//OGG
typedef struct _OGGSTREAM{
	/* data info */
	void *data;                      /* ogg data */
	char *data_cursor;               /* pointer to data being read */
	int data_len;                    /* size of the data */
	
	/* decoder info */
	OggVorbis_File vf;
	int current_section;

	/*otros*/
	bool loop;

} OGGSTREAM;



//HANDLES
#define HOGGSTREAM int

//classes
//------------------------------------------------------------------//

class LCL_SoftSynth{
	//playing y sync
	struct PLAYERDATA{
		int bpm;
		int samplerate;
		int ticklength;
	}pd;

public:
	//control
	void Play();
	void Stop();
	//sync
	int GetBPM(){return pd.bpm;}
	void SetBPM(int bpm){pd.bpm=bpm;}
	//ogg
	HOGGSTREAM LoadOGG(char* filename);
	void FreeOGG(HOGGSTREAM hoggstream);
	void PlayOGG(HOGGSTREAM hoggstream,bool loop);
	void SetOGG_Vol(int volumen);
	//setup
	int Init(HWND hwnd,int sample_rate,int latency);
	void ShutDown();
	//void SetOutputCallBack(void(*p_lpoutputfcn)(short*,long,int));	
	

};


#endif