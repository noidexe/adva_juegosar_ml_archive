#include "LCL_Sprite.h"

#include "utils.h"

//--------------------------------------------------------------------------//
int LCL_Sprite::Animar()
//--------------------------------------------------------------------------//
{
	counter++;
	if(counter>=xspriteinfo->sequences[curr_sequence].speed)
	{
		counter=0;		
		if(curr_frame<xspriteinfo->sequences[curr_sequence].n_frames-1)
			curr_frame++;
		else
		{			
			if(xspriteinfo->sequences[curr_sequence].loop)
				curr_frame=0;
			else
				return 1;
		}
	}
	return 0;		
}
//--------------------------------------------------------------------------//



//--------------------------------------------------------------------------//
void LCL_Sprite::Reset()
//--------------------------------------------------------------------------//
{
	curr_sequence=0;
	curr_frame=0;
	counter=0;
	direction=0;
	state=0;
}
//--------------------------------------------------------------------------//


//--------------------------------------------------------------------------//
void LCL_Sprite::Dibujar(int camera_x,int camera_y,CDXSurface * surf)	
//--------------------------------------------------------------------------//
{
	if(curr_frame>=xspriteinfo->sequences[curr_sequence].n_frames)
		curr_frame=0;

	tile->BlitCelTrans(surf,
					   x-xspriteinfo->xc-camera_x,
					   y-xspriteinfo->yc-camera_y,
					   xspriteinfo->sequences[curr_sequence].framebuffer[curr_frame]);
}
//--------------------------------------------------------------------------//


//--------------------------------------------------------------------------//
void LCL_Sprite::DibujarAlphaFast(int camera_x,int camera_y,CDXSurface * surf)	
//--------------------------------------------------------------------------//
{
	if(curr_frame>=xspriteinfo->sequences[curr_sequence].n_frames)
		curr_frame=0;

	tile->BlitCelTransAlphaFast(surf,
					   x-xspriteinfo->xc-camera_x,
					   y-xspriteinfo->yc-camera_y,
					   xspriteinfo->sequences[curr_sequence].framebuffer[curr_frame]);
}
//--------------------------------------------------------------------------//



//--------------------------------------------------------------------------//
void LCL_Sprite::DibujarRZ(int camera_x,int camera_y,CDXSurface * surf,double angle,double scale)
//--------------------------------------------------------------------------//
{
	tile->BlitCelTransRZ(surf,
					x-xspriteinfo->xc-camera_x,
					y-xspriteinfo->yc-camera_y,
					xspriteinfo->sequences[curr_sequence].framebuffer[curr_frame],
					angle,scale);

}
//--------------------------------------------------------------------------//


//--------------------------------------------------------------------------//
LCL_Sprite* LCL_SpriteList::GetNearest(int x0,int y0,int *distance)
//--------------------------------------------------------------------------//
{
	LCL_Sprite* Node;
	LCL_Sprite* selected=0;
	int dist;
	int dx,dy;
	int min_dist=999;
	for(Node=GetFirst();Node!=NULL;Node=GetNext(Node))
	{
		dx=abs(Node->x-x0);
		dy=abs(Node->y-y0);
		dist=Fast_Distance_2D(dx,dy);
		if(dist<min_dist)
		{
			min_dist=dist;
			selected=Node;
		}
	}
	if(distance)*distance=min_dist;

	return selected;
}
//--------------------------------------------------------------------------//

//---------------------------------------------------------------------//

bool PtInAO(LCL_Sprite* ao,int x0,int y0)

//---------------------------------------------------------------------//
{	
	RECT bounding_rect;
	bounding_rect.left=ao->x-ao->xspriteinfo->xc;
	bounding_rect.right=bounding_rect.left+ao->xspriteinfo->cel_width;
	
	if(x0<bounding_rect.left || x0>bounding_rect.right)
		return 0;

	bounding_rect.top=ao->y-ao->xspriteinfo->yc;
	bounding_rect.bottom=bounding_rect.top+ao->xspriteinfo->cel_height;

	if(y0<bounding_rect.top || y0>bounding_rect.bottom)
		return 0;

	return 1;
}
//---------------------------------------------------------------------//


////////////////////////////////////////////////////////////////////////

int Fast_Distance_2D(int x, int y)

////////////////////////////////////////////////////////////////////////
{
// this function computes the distance from 0,0 to x,y with 3.5% error

// first compute the absolute value of x,y
x = abs(x);
y = abs(y);

// compute the minimum of x,y
int mn = MIN(x,y);

// return the distance
return(x+y-(mn>>1)-(mn>>2)+(mn>>4));

} // end Fast_Distance_2D
////////////////////////////////////////////////////////////////////////


//Manejo de recursos: gfx, mods, etc.
// ------------------------------------------------------------------------------------------



void LCL_GFXPack_v0::Cargar_ASCII(CDXScreen* pScreen,char* filename)
{
	char txt[128];	//DEBUG ONLY

	FILE* debugfp=fopen("debug_log.txt","w");

	int i=0;
	char seps[]=" ,\n\t\r";
	DWORD size;
	char* buffer=(char*)DumpFileToMem(filename,&size);

	//MessageBox(0,"Va a cargar el spritepack",0,0);

	//primero elimina los comentarios
	while(buffer[i]!='\0')
	{
		if(buffer[i]!=';') 
			i++;
		else
		{
			int j=0;
			buffer[i]=',';	
			i++;
			while(buffer[i]!='\n' && buffer[i]!='\0')
			{
				txt[j++]=buffer[i];
				buffer[i]=' ';
				i++;
			}
			txt[j]='\0';
		}
	}
	//end eliminar comentarios

	//IMAGENES
	//MessageBox(0,buffer,"CP",0);

	//nro de imagenes
	surface_count=atoi(strtok(buffer,seps));
	
	sprintf(txt,"N_Surfaces:%d",surface_count);
	//MessageBox(0,txt,0,0);

	surfaces=new CDXSurface*[surface_count];

	fprintf(debugfp,"N_Surfaces:%d\n",surface_count);

	//carga las imagenes en las surfaces
	for(i=0;i<surface_count;i++)
	{
		char* img_name=strtok(0,seps);
		fprintf(debugfp,"Img_name:%s\n",img_name);
		DWORD size;
		void* img_data=DumpFileToMem(img_name,&size);
		surfaces[i]=new CDXSurface;
		surfaces[i]->LCL_CrearDesdeImagen(pScreen,img_data,size,INVERTIR_COLOR);
		//MessageBox(0,img_name,"Carg� imagen",0);
		delete img_data;

		surfaces[i]->SetColorKey();
	}

	//XSPRITEINFOS

	//nro de xspriteinfos
	xspriteinfos_count=atoi(strtok(0,seps));	
	
	sprintf(txt,"N_Spriteinfos:%d",xspriteinfos_count);
	//MessageBox(0,txt,0,0);
	xspriteinfos=new XSPRITEINFO*[xspriteinfos_count];

	fprintf(debugfp,"N_XspriteInfos:%d\n",xspriteinfos_count);
	
	for(i=0;i<xspriteinfos_count;i++)
	{
		xspriteinfos[i]=new XSPRITEINFO;
		
		//xspriteinfo
		xspriteinfos[i]->cel_width=atoi(strtok(0,seps));
		xspriteinfos[i]->cel_height=atoi(strtok(0,seps));
		xspriteinfos[i]->n_frames=atoi(strtok(0,seps));

		fprintf(debugfp,"Cel_Width:%d\n",xspriteinfos[i]->cel_width);
		fprintf(debugfp,"Cel_Height:%d\n",xspriteinfos[i]->cel_height);
		fprintf(debugfp,"N_Frames:%d\n",xspriteinfos[i]->cel_width);


		sprintf(txt,"W:%d,H:%d,N_frames:%d",
					xspriteinfos[i]->cel_width,
					xspriteinfos[i]->cel_height,
					xspriteinfos[i]->n_frames);					
		//MessageBox(0,txt,0,0);

		xspriteinfos[i]->xc=atoi(strtok(0,seps));
		xspriteinfos[i]->yc=atoi(strtok(0,seps));

		sprintf(txt,"Xc:%d Yc:%d",xspriteinfos[i]->xc,
								  xspriteinfos[i]->yc);
		//MessageBox(0,txt,0,0);
		
		fprintf(debugfp,"XC::%d\n",xspriteinfos[i]->xc);
		fprintf(debugfp,"YC:%d\n",xspriteinfos[i]->yc);
		
		

		//n_sequences
		xspriteinfos[i]->n_sequences=atoi(strtok(0,seps));

		sprintf(txt,"N_Sequences:%d",xspriteinfos[i]->n_sequences);
		//MessageBox(0,txt,0,0);
		

		fprintf(debugfp,"N_Sequences:%d\n",xspriteinfos[i]->n_sequences);

		xspriteinfos[i]->sequences=new SEQUENCE[xspriteinfos[i]->n_sequences];

		for(int j=0;j<xspriteinfos[i]->n_sequences;j++)
		{
			xspriteinfos[i]->sequences[j].n_frames=atoi(strtok(0,seps));

			sprintf(txt,"Seq %d]N_Frames:%d",j,xspriteinfos[i]->sequences[j].n_frames);
			//MessageBox(0,txt,0,0);

			xspriteinfos[i]->sequences[j].framebuffer=new int[xspriteinfos[i]->sequences[j].n_frames];
			for(int k=0;k<xspriteinfos[i]->sequences[j].n_frames;k++)
				xspriteinfos[i]->sequences[j].framebuffer[k]=atoi(strtok(0,seps));

			xspriteinfos[i]->sequences[j].speed=atoi(strtok(0,seps));

			sprintf(txt,"Seq %d]Speed:%d",j,xspriteinfos[i]->sequences[j].speed);
			//MessageBox(0,txt,0,0);
			
			xspriteinfos[i]->sequences[j].loop=atoi(strtok(0,seps));

			sprintf(txt,"Seq %d]Loop:%d",j,xspriteinfos[i]->sequences[j].loop);
			//MessageBox(0,txt,0,0);
		}
	}

	
	//CLASES

	//nro de clases
	n_clases=atoi(strtok(0,seps));	
	clases=new AOCLASS[n_clases];

	for(i=0;i<n_clases;i++)
	{
		clases[i].template_id=atoi(strtok(0,seps));
		clases[i].img_id=atoi(strtok(0,seps));
	}
	

	fclose(debugfp);
	delete buffer;
}

LCL_GFXPack_v0::LCL_GFXPack_v0()
{
	surfaces=0;
	tiles=0;
	xspriteinfos=0;
}

LCL_GFXPack_v0::~LCL_GFXPack_v0()
{
	int i=0;
	
	//borra las surfaces
	if(surfaces)
	{
		for(i=0;i<surface_count;i++)
			SAFEDELETE(surfaces[i]);
		delete surfaces;
	}

	//borra los tiles
	if(tiles)
	{
		for(i=0;i<tile_count;i++)
			SAFEDELETE(tiles[i]);
		delete tiles;
	}

	//borra los xspriteinfos
	if(surfaces)
	{
		for(i=0;i<xspriteinfos_count;i++)
			SAFEDELETE(xspriteinfos[i]);
		delete xspriteinfos;
	}

	//borra las clases
	SAFEDELETE(clases);
		
}

LCL_Sprite* LCL_GFXPack_v0::CrearSprite(int clase)
{
	LCL_Tile* tmp_tile=new LCL_Tile;

	tmp_tile->Crear(surfaces[clases[clase].img_id],
					xspriteinfos[clases[clase].template_id]->cel_width,
					xspriteinfos[clases[clase].template_id]->cel_height,
					xspriteinfos[clases[clase].template_id]->n_frames);
	LCL_Sprite* tmp= new LCL_Sprite(tmp_tile,xspriteinfos[clases[clase].template_id]);

	tmp->clase=clase;

	return tmp;
}