#ifndef LCL_SPRITE
#define	LCL_SPRITE

#include <windows.h>

// m�ximo y m�nimo
#define MIN(a, b)  (((a) < (b)) ? (a) : (b)) 
#define MAX(a, b)  (((a) > (b)) ? (b) : (a)) 

//CDX LITE
#include "CDX.h"
#include "cdxscreen.h"
#include "cdxsurface.h"

#include "LCL_Tile.h"

//LCL_Sprite

//estructura para guardar info de los AO en archivos
typedef struct _AODATA{
	BYTE	clase;
	int		id;
	int		x;
	int		y;
} AODATA;

typedef struct _AOCLASS{
	int template_id;
	int img_id;
}AOCLASS;

typedef struct _SEQUENCE{
	int n_frames;
	int speed;
	int* framebuffer;	
	bool loop;	
} SEQUENCE;

typedef struct _XSPRITEINFO{
	int cel_width;
	int cel_height;
	int xc;
	int yc;
	int n_frames;
	int n_sequences;
	SEQUENCE* sequences;
} XSPRITEINFO;

class LCL_Sprite{
protected:
	LCL_Tile* tile;	
	int curr_sequence;
	int curr_frame;
	int counter;	
	LCL_Sprite* m_Next;		
	LCL_Sprite* m_Prev;		
public:	
	XSPRITEINFO* xspriteinfo;	
	int direction;
	int clase;
	int state;
	int x,y;
	int id;
	LCL_Sprite(LCL_Tile* p_tile,XSPRITEINFO* p_xspriteinfo)
	{
		xspriteinfo=p_xspriteinfo;
		tile=p_tile;
		Reset();
	}	
	void Reset();
	void SetAnimation(int anim_id){curr_sequence=anim_id;}	
	void ResetAnimation(){counter=0;curr_frame=0;}	
	int Animar();
	void Dibujar(int camera_x,int camera_y,CDXSurface * surf);	
	void DibujarRZ(int camera_x,int camera_y,CDXSurface * surf,double angle,double scale);	
	void DibujarAlphaFast(int camera_x,int camera_y,CDXSurface * surf);
	void SetDirection();
	void SetNext(LCL_Sprite* lpAO) { m_Next = lpAO; }
    void SetPrev(LCL_Sprite* lpAO) { m_Prev = lpAO; }
    LCL_Sprite* GetNext(void) { return m_Next; }
    LCL_Sprite* GetPrev(void) { return m_Prev; }
	virtual void Control(){};
};

class LCL_SpriteList
{
public:
	virtual ~LCL_SpriteList(void){m_objectList.Clear(TRUE);}
    void AddLCL_Sprite(LCL_Sprite* p_object) { m_objectList.Add(p_object); }
    void DelLCL_Sprite(LCL_Sprite* p_object,bool delete_me) { m_objectList.Remove(p_object, delete_me); }
    LONG GetCount(void) { return m_objectList.GetCount(); }
    LCL_Sprite* GetFirst(void) { return m_objectList.GetFirst(); }
    LCL_Sprite* GetNext(LCL_Sprite* p_object) { return m_objectList.Next(p_object); }
	LCL_Sprite* LCL_SpriteList::GetNearest(int x0,int y0,int *distance);
	void Clear(bool b_remove){m_objectList.Clear(b_remove);}
private:
	CDXCList<LCL_Sprite> m_objectList;  // Linked List template
};


// Clases para manejo de resources:gr�ficos, mods, etc.
// ------------------------------------------------------------------------------------------

class LCL_GFXPack_v0{
	int surface_count;
	int tile_count;
	int xspriteinfos_count;
	int n_clases;
public:
	CDXSurface**	surfaces;
	LCL_Tile**		tiles;
	XSPRITEINFO**	xspriteinfos;
	AOCLASS*		clases;
	LCL_GFXPack_v0();
	~LCL_GFXPack_v0();	
	void Cargar_ASCII(CDXScreen* pScreen,char* filename);
	LCL_Sprite* CrearSprite(int clase);
	int GetNClases(){return n_clases;}
};

int Fast_Distance_2D(int x, int y);
bool PtInAO(LCL_Sprite* ao,int x0,int y0);

#endif
