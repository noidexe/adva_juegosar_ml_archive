#include "LCL_Tile.h"

void LCL_Tile::Crear(CDXSurface* source_imgp,int tile_width,int tile_height,int n_tiles)
{
	source_img=source_imgp;
	int width=source_img->GetWidth();

	n_cels=n_tiles;
	cel_rects=new RECT[n_cels];
	codigo=new int[n_cels];
	transparente=new bool[n_cels];
	defaultlayer=new int[n_cels];

	cel_width=tile_width;
	cel_height=tile_height;

	int ix=0;
	int iy=0;
	for(int i=0;i<n_cels;i++)
	{
		if((ix+cel_width)>width)
		{
			ix=0;
			iy+=cel_height;
		}
		cel_rects[i].left=ix;
		cel_rects[i].top=iy;
		cel_rects[i].right=cel_rects[i].left+cel_width;
		cel_rects[i].bottom=cel_rects[i].top+cel_height;

		codigo[i]=0;
		defaultlayer[i]=0;
		transparente[i]=0;

		ix+=cel_width;
	}
}

void LCL_Tile::BlitCel(CDXSurface* surf,int x,int y,int n_cel)
{
	source_img->DrawBlk(surf,x,y,&cel_rects[n_cel]);
}

void LCL_Tile::BlitCelTransRZ(CDXSurface* surf,int x,int y,int n_cel,double angle,double scale)
{
	source_img->DrawTransRotoZoom(surf,x,y,&cel_rects[n_cel],angle,scale);
}

void LCL_Tile::BlitCelTrans(CDXSurface* surf,int x,int y,int n_cel)
{
	source_img->DrawTrans(surf,x,y,&cel_rects[n_cel]);
}

void LCL_Tile::BlitCelTransAlphaFast(CDXSurface* surf,int x,int y,int n_cel)
{
	source_img->DrawTransAlphaFast(surf,x,y,&cel_rects[n_cel]);
}


