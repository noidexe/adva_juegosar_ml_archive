#ifndef LCL_TILE
#define	LCL_TILE

#include <windows.h>

//CDX LITE
#include "CDX.h"
#include "cdxscreen.h"
#include "cdxsurface.h"

class LCL_Tile{
	CDXSurface* source_img;
	RECT*		cel_rects;		
	int			n_cels;
	int			cel_width;
	int			cel_height;	
public:	
	bool*		transparente;
	int*		defaultlayer;
	int*		codigo;
	void Crear(CDXSurface* source,int tile_width,int tile_height,int n_tiles);
	void BlitCel(CDXSurface* surf,int x,int y,int n_cel);
	void BlitCelTrans(CDXSurface* surf,int x,int y,int n_cel);
	void BlitCelTransAlphaFast(CDXSurface* surf,int x,int y,int n_cel);	
	void BlitCelTransRZ(CDXSurface* surf,int x,int y,int n_cel,double angle,double scale);
	void SetearCodigo(int index,int value){codigo[index]=value;}
	int GetCodigo(int index){return codigo[index];}	
	int GetTileWidth(){return cel_width;}
	int GetTileHeight(){return cel_height;}
};

#endif