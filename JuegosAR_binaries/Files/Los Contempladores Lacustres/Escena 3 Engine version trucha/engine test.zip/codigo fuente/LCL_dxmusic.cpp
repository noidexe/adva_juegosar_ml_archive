//LCL_dxmusic.cpp

#include "LCL_dxMusic.h"


HRESULT LCL_DXMusic::Init(HWND hwnd)
{

	if(FAILED(CoInitialize(0)))
		return 0;
	
	if(FAILED(CoCreateInstance(CLSID_DirectMusicPerformance,
							   NULL,
							   CLSCTX_INPROC,
							   IID_IDirectMusicPerformance,
							   (void**)&dm_perf)))
		return 0;

	if(FAILED(dm_perf->Init(0,0,hwnd)))
		return 0;

	if(FAILED(dm_perf->AddPort(0)))
		return 0;

	if(FAILED(CoCreateInstance(CLSID_DirectMusicLoader,
							   NULL,
							   CLSCTX_INPROC,
							   IID_IDirectMusicLoader,
							   (void**)&dm_loader)))
		return 0;


	for(int i=0;i<DM_NUM_SEGMENTS;i++)
	{
		dm_midi[i].dm_segment=0;
		dm_midi[i].dm_segstate=0;
	}

	n_midis=0;
	midi_playing=-1;



	return 1;
}


int LCL_DXMusic::LoadMIDI(void* mem_ptr, DWORD size)
{	
	
    DMUS_OBJECTDESC ObjDesc; 
    
    ObjDesc.dwSize = sizeof(DMUS_OBJECTDESC);
    ObjDesc.guidClass = CLSID_DirectMusicSegment;
    ObjDesc.dwValidData = DMUS_OBJ_CLASS | DMUS_OBJ_MEMORY;
    ObjDesc.pbMemData = (BYTE *) mem_ptr;
    ObjDesc.llMemLength = size;
 
    dm_loader->GetObject(&ObjDesc,IID_IDirectMusicSegment2, (void**) &dm_midi[n_midis].dm_segment);


    dm_midi[n_midis].dm_segment->SetParam(GUID_StandardMIDIFile,-1, 0, 0, (void*)dm_perf);
	dm_midi[n_midis].dm_segment->SetParam(GUID_Download, -1, 0, 0, (void*)dm_perf);

	n_midis++;
	return n_midis-1;
} // end loadmidi


void LCL_DXMusic::PlayMIDI(int midi_id,bool loop)
{	
	if(loop)
		dm_midi[midi_id].dm_segment->SetRepeats(9999);
    dm_perf->PlaySegment(dm_midi[midi_id].dm_segment, 0, 0, &dm_midi[midi_id].dm_segstate);

	midi_playing=midi_id;  
}

int LCL_DXMusic::is_music_playing()
{
	if(midi_playing!=-1)
	{
		if(dm_perf->IsPlaying(0,dm_midi[midi_playing].dm_segstate)!=S_OK)			
			midi_playing=-1;
	}
	return midi_playing;
}


void LCL_DXMusic::StopMIDI()
{
	dm_perf->Stop(NULL, NULL, 0, 0);
	midi_playing=-1;
}


void LCL_DXMusic::FreeMIDI(int midi_id)
{
	dm_midi[midi_id].dm_segment->SetParam(GUID_Unload, -1, 0, 0, (void*)dm_perf);
 
	// Release the segment.
	dm_midi[midi_id].dm_segment->Release();

}


HRESULT LCL_DXMusic::ShutDown()
{
    // If there is any music playing, stop it. This is 
    // not really necessary, because the music will stop when
    // the instruments are unloaded or the performance is
    // closed down.
    dm_perf->Stop( NULL, NULL, 0, 0 );
 
    // Unload instruments � this will cause silence.
    // CloseDown unloads all instruments, so this call is also not 
    // strictly necessary.
	for(int i=0;i<n_midis;i++)
		FreeMIDI(i);	
 
    // CloseDown and Release the performance object.
    dm_perf->CloseDown();
    dm_perf->Release();
 
    // Release the loader object.
    dm_loader->Release();
 
    // Release COM.
    CoUninitialize();
 
    return S_OK;
}
