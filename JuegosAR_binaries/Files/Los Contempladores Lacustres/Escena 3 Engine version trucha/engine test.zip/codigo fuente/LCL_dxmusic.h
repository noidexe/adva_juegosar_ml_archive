#include <dmksctrl.h>
#include <dmusici.h>
#include <dmusicc.h>
#include <dmusicf.h>

#define DM_NUM_SEGMENTS 16	//m�ximo n�mero de midis cargados


typedef struct DMUSIC_MIDI_TYP{
	IDirectMusicSegment			*dm_segment;
	IDirectMusicSegmentState	*dm_segstate;
	int							id;
	int							state;
} DMUSIC_MIDI;


class LCL_DXMusic{
	IDirectMusicPerformance	*dm_perf;
	IDirectMusicLoader		*dm_loader;

	DMUSIC_MIDI				dm_midi[DM_NUM_SEGMENTS];
	int midi_playing;
	int n_midis;
public:
	//setup
	HRESULT Init(HWND hwnd);
	HRESULT ShutDown();

	//i/o
	int LoadMIDI(void* mem_ptr, DWORD size);
	void FreeMIDI(int midi_id);

	//playback b�sico
	void PlayMIDI(int midi_id, bool loop);
	void StopMIDI();
	void SetVolume();	
	int is_music_playing();

	
};





