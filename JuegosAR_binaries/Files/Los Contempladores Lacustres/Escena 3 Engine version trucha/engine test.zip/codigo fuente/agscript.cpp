#include "agscript.h"
#include "agscriptx.h"
#include "parsing.h"

#include <stdlib.h>
#include <string.h>

#include "utils.h"

/*
const char* comandos[]={"EGO:",
						"DIALOG",
						0};
*/


//PROVISORIO
#include <windows.h>

int CompilarScript(char* ASCII_script,SCRIPT* script,ScriptData &scriptdata)
{
	char seps[]=" \n\t\r|,;()";
	int cmd;

	//reserva espacio para el script (m�x 32 instrucciones)
	script->n_insts=0;
	script->insts=(DINSTRUCTION*)malloc(sizeof(DINSTRUCTION)*32);

	char* p=ASCII_script;
	
	char* comando=0;
	
	
	//LEE EL DIALOG SCRIPT
	do{
		if(comando)delete comando;
		comando=GetNextToken(p,seps);
		//DEBUG
		//MessageBox(0,comando,"COMANDO",0);		

		cmd=0;
		while(cmd<scriptdata.n_comandos && stricmp(comando,scriptdata.comandos[cmd].token))cmd++;

		if(cmd<scriptdata.n_comandos)
		{
			script->insts[script->n_insts].opcode=scriptdata.comandos[cmd].opcode;

			char tb[256];
			
			switch(scriptdata.comandos[cmd].tipo)
			{
				//TIPO 0 recibe un int como par�metro
				case 0:
					{
						script->insts[script->n_insts].param1=GetNextNumberParam(p);

						//debug
						/*
						sprintf(tb,"%02d] Token: %s\nOpcode: %d\nParam1:%d\nParam2:N/A",
												script->n_insts,
												scriptdata.comandos[cmd].token,
												script->insts[script->n_insts].opcode,
												script->insts[script->n_insts].param1);
						MessageBox(0,tb,"Compilando",0);
						*/
					}break;

				//TIPO 1 recibe un txt como par�metro
				case 1:
					{						
						script->insts[script->n_insts].txt=StringFromArg(p,'\"','\"');

						//debug
						/*
						sprintf(tb,"%02d] Token: %s\nOpcode: %d\nParam1:%s\nParam2:N/A",
												script->n_insts,
												scriptdata.comandos[cmd].token,
												script->insts[script->n_insts].opcode,
												script->insts[script->n_insts].txt);
						MessageBox(0,tb,"Compilando",0);
						*/
					}break;

				//TIPO 2 recibe un txt y un int como par�metros
				case 2:
					{
						script->insts[script->n_insts].txt=StringFromArg(p,'\"','\"');
						script->insts[script->n_insts].param2=GetNextNumberParam(p);

						//debug
						/*
						sprintf(tb,"%02d] Token: %s\nOpcode: %d\nParam1:%s\nParam2:%d",
												script->n_insts,
												scriptdata.comandos[cmd].token,
												script->insts[script->n_insts].opcode,
												script->insts[script->n_insts].txt,
												script->insts[script->n_insts].param2);
						MessageBox(0,tb,"Compilando",0);
						*/
					}break;

				//TIPO 3 recibe dos ints como par�metros
				case 3:
					{	
						script->insts[script->n_insts].param1=GetNextNumberParam(p);
						script->insts[script->n_insts].param2=GetNextNumberParam(p);

						/*
						sprintf(tb,"%02d] Token: %s\n Opcode: %d\nParam1:%d\nParam2:%d",
												script->n_insts,
												scriptdata.comandos[cmd].token,
												script->insts[script->n_insts].opcode,
												script->insts[script->n_insts].param1,
												script->insts[script->n_insts].param2);
						MessageBox(0,tb,"Compilando",0);
						*/
					}break;

				//TIPO 4: no recibe ning�n tipo de par�metro
				case 4:
					{
						/*
						sprintf(tb,"%02d] Token: %s\n Opcode: %d\nParam1:N/A\nParam2:N/A",
												script->n_insts,
												scriptdata.comandos[cmd].token,
												script->insts[script->n_insts].opcode,
												script->insts[script->n_insts].param1,
												script->insts[script->n_insts].param2);
						MessageBox(0,tb,"Compilando",0);
						*/
					}break;



				

			}//end switch command

			script->n_insts++;

		}//end if

			
	} while(stricmp(comando,"@STOP"));
		
	script->insts=(DINSTRUCTION*)realloc(script->insts,sizeof(DINSTRUCTION)*script->n_insts);

	return p-ASCII_script;
}
/*
void SerializarScript(SCRIPT* script,FILE* fp)
{	
	//escribe el nro de instrucciones
	unsigned char n_insts=script->n_insts;
	fwrite(&n_insts,1,1,fp);

	//escribe todo
	for(int i=0;i<script->n_insts;i++)
	{
		DINSTRUCTIONFILE fileinstr;

		fileinstr.opcode=script->insts[i].opcode;

		//busca el tipo
		int j=0;
		while(scriptdata.comandos[j].opcode!=fileinstr.opcode)j++;
				
		switch(scriptdata.comandos[j].tipo)
		{
				//TIPO 0 recibe un int como par�metro
				case 0:
					{
						fileinstr.paramsize=script->insts[i].param1;
						fwrite(&fileinstr,sizeof(DINSTRUCTIONFILE),1,fp);						
					}break;

				//TIPO 1 recibe un txt como par�metro
				case 1:
					{
						fileinstr.paramsize=strlen(script->insts[i].txt);
						fwrite(&fileinstr,sizeof(DINSTRUCTIONFILE),1,fp);
						fwrite(script->insts[i].txt,1,fileinstr.paramsize,fp);
					}break;

				//TIPO 2 recibe un txt y un int como par�metros
				case 2:
					{
						//escribe el txt
						fileinstr.paramsize=strlen(script->insts[i].txt);
						fwrite(&fileinstr,sizeof(DINSTRUCTIONFILE),1,fp);
						fwrite(script->insts[i].txt,1,fileinstr.paramsize,fp);
						//y despu�s el param2 (int)
						fwrite(&script->insts[i].param2,1,sizeof(int),fp);
					}break;

				//TIPO 3 recibe dos ints como par�metros
				case 3:
					{
						fileinstr.paramsize=script->insts[i].param1;
						fwrite(&fileinstr,sizeof(DINSTRUCTIONFILE),1,fp);
						//y despu�s el param2 (int)
						fwrite(&script->insts[i].param2,1,sizeof(int),fp);						
					}break;	
				//TIPO 4 ning�n par�metro
				case 4:
					{
						fwrite(&fileinstr,sizeof(DINSTRUCTIONFILE),1,fp);
					}break;
		
		}//end switch tipo

	}//end for

}

void DesCompilarScript(FILE* fp,char* txt)
{
	char tmp[256];

	//lee el nro de instrucciones
	unsigned char n_insts;
	fread(&n_insts,1,1,fp);

	//escribe todo
	for(int i=0;i<n_insts;i++)
	{
		DINSTRUCTIONFILE fileinstr;
		fread(&fileinstr,sizeof(DINSTRUCTIONFILE),1,fp);	

		//busca el comando
		int j=0;
		while(scriptdata.comandos[j].opcode!=fileinstr.opcode)j++;

		//lo escribe
		strcat(txt,scriptdata.comandos[j].token);
		strcat(txt,"(");
				
		switch(scriptdata.comandos[j].tipo)
		{
				//TIPO 0 recibe un int como par�metro
				case 0:
					{
						//escribe el param1
						sprintf(tmp,"%d",fileinstr.paramsize);
						strcat(txt,tmp);
						strcat(txt,");");
					}break;

				//TIPO 1 recibe un txt como par�metro
				case 1:
					{
						strcat(txt,"\"");
						fread(tmp,1,fileinstr.paramsize,fp);
						tmp[fileinstr.paramsize]='\0';
						strcat(txt,tmp);
						strcat(txt,"\");");
					}break;

				//TIPO 2 recibe un txt y un int como par�metros
				case 2:
					{
						//escribe el txt
						strcat(txt,"\"");
						fread(tmp,1,fileinstr.paramsize,fp);
						tmp[fileinstr.paramsize]='\0';
						strcat(txt,tmp);
						strcat(txt,"\",");
						//y despu�s el param2 (int)
						int param2;
						fread(&param2,1,sizeof(int),fp);
						sprintf(tmp," %d",param2);
						strcat(txt,tmp);
						strcat(txt,");");
					}break;

				//TIPO 3 recibe dos ints como par�metros
				case 3:
					{
						//escribe el param1
						sprintf(tmp,"%d",fileinstr.paramsize);
						strcat(txt,tmp);
						strcat(txt,",");					
						//y despu�s el param2 (int)
						int param2;
						fread(&param2,1,sizeof(int),fp);
						sprintf(tmp," %d",param2);
						strcat(txt,tmp);
						strcat(txt,");");
					}break;	

				//TIPO 4: ning�n par�metro
				case 4:
					{
						strcat(txt,"();");
					}break;
		
		}//end switch tipo
	
		strcat(txt,"\n\r");

	}//end for
}
*/
#define MAX_COMANDOS 32
void ScriptData::CargarComandos_ASCII(char* filename)
{
	char seps[]=" \n\t\r|,;()";
	DWORD size;
	char* buffer=(char*)DumpFileToMem(filename,&size);

	SacarComentarios(buffer);
	char* p=buffer;
	

	comandos=(COMANDO*)malloc(sizeof(COMANDO)*MAX_COMANDOS);
	n_comandos=0;

	
	char*comando=GetNextToken(p,seps);

	while(stricmp(comando,"@stop"))
	{		
		strcpy(comandos[n_comandos].token,comando);
		
		
		comandos[n_comandos].opcode=GetNextNumberParam(p);
		comandos[n_comandos].tipo=GetNextNumberParam(p);

		//debug
		char tb[128];
		sprintf(tb,"Comando:%s Opcode:%d Tipo:%d",comandos[n_comandos].token
												 ,comandos[n_comandos].opcode
												 ,comandos[n_comandos].tipo);
		//MessageBox(0,tb,"Debug info",0);

		n_comandos++;

		if(comando)
			delete comando;
		comando=GetNextToken(p,seps);
	}

	comandos=(COMANDO*)realloc(comandos,sizeof(COMANDO)*(n_comandos+1));

	//comandos[n_comandos].token=0;

	delete buffer;
}
