#ifndef AGSCRIPT
#define AGSCRIPT

typedef struct _DINSTRUCTION
{
	int opcode;
	union{
			char* txt;
			int	  param1;
	};
	int param2;
} DINSTRUCTION;

typedef struct _DINSTRUCTIONFILE
{
	unsigned char opcode;
	int paramsize;
}DINSTRUCTIONFILE;

typedef struct _SCRIPT
{
	int n_insts;
	DINSTRUCTION* insts;
} SCRIPT;


//SCRIPT SETUP/COMANDOS RECONOCIDOS
//------------------------------------------------------//

typedef struct _COMANDO{
	unsigned char opcode;
	char token[32];
	unsigned char tipo;
} COMANDO;

class ScriptData{
public:
	int n_comandos;
	COMANDO* comandos;
	void CargarComandos_ASCII(char* filename);
};

#endif
