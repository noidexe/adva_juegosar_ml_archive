#ifndef AGSCRIPTX
#define AGSCRIPTX

#include "agscript.h"



#include "stdio.h"

int CompilarScript(char* ASCII_script,SCRIPT* script, ScriptData &scriptdata);

#ifdef EDITOR
void SerializarScript(SCRIPT* script,FILE* fp);
void DesCompilarScript(FILE* fp,char* txt);
#endif

#endif