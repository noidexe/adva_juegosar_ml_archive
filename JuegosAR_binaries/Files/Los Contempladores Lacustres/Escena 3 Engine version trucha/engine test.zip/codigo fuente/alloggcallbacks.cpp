/* fill in the ogg struct */
  ogg->data = data;
  ogg->data_cursor = (char *)data;
  ogg->data_len = data_len;
  memset((void *)&ogg->vf, 0, sizeof(ogg->vf));
  ogg->audiostream = NULL;
  ogg->loop = FALSE;
  ogg->auto_polling = FALSE;
  ogg->current_section = -1;

  /* use vorbisfile to open it */
  ret = ov_open_callbacks((void *)ogg, &(ogg->vf), NULL, 0, _alogg_ogg_callbacks);

  /* if error */
  if (ret < 0) {
    free((void *)ogg);
    return NULL;
  }

