#include "cargarjpg.h"

HBITMAP CargarJPG(HDC hdc,void* img_data_ptr,DWORD img_size)
{
	HBITMAP bmp;

	LPVOID pvData = NULL;
		
	// alloc memory based on file size
	HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, img_size);
	pvData = GlobalLock(hGlobal);

	DWORD dwBytesRead = img_size;
		
	// read file and store in global memory
	memcpy(pvData, img_data_ptr, img_size);

	GlobalUnlock(hGlobal);

	LPSTREAM pstm = NULL;
	
	// create IStream* from global memory
	HRESULT hr = CreateStreamOnHGlobal(hGlobal, TRUE, &pstm);
	if ( (!SUCCEEDED(hr)) || (pstm == NULL))
		return NULL;

	// Create IPicture from image file
	LPPICTURE gpPicture=NULL;
	hr = ::OleLoadPicture(pstm, img_size, FALSE, IID_IPicture, (LPVOID *)&gpPicture);
	if ( (!SUCCEEDED(hr)) || (gpPicture == NULL))
		return NULL;

	pstm->Release();

	// get width and height of picture
	long hmWidth;
	long hmHeight;
	gpPicture->get_Width(&hmWidth);
	gpPicture->get_Height(&hmHeight);

	HDC screendc = ::CreateIC("Display", NULL, NULL, NULL);

	// convert himetric to pixels
	int nWidth	= MulDiv(hmWidth, GetDeviceCaps(screendc, LOGPIXELSX), HIMETRIC_INCH);
	int nHeight	= MulDiv(hmHeight, GetDeviceCaps(screendc, LOGPIXELSY), HIMETRIC_INCH);

	::DeleteDC(screendc);

	bmp=CreateCompatibleBitmap(hdc,nWidth,nHeight);	
	
	HDC bdc=CreateCompatibleDC(hdc);
	SelectObject(bdc,bmp);

	RECT rc;
	rc.left = 0;
	rc.top = 0;
	rc.right = nWidth;
	rc.bottom = nHeight;

	// display picture using IPicture::Render
	gpPicture->Render(bdc, 0, 0, nWidth, nHeight, 0, hmHeight, hmWidth, -hmHeight, &rc);
	
	DeleteDC(bdc);

	if (gpPicture)
		gpPicture->Release();

	return bmp;
}

			