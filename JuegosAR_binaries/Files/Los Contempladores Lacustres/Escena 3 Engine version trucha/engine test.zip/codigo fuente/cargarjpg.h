#ifndef CARGARJPG
#define CARGARJPG

#include <windows.h>

//JPG LOADING
#include <ocidl.h>
#include <olectl.h>
#define HIMETRIC_INCH	2540


HBITMAP CargarJPG(HDC hdc,void* img_data_ptr,DWORD img_size);

#endif