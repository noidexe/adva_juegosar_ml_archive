/*----------------------------------------------------------------------
 FILE: CARGARPNG.CPP

 Desc: Wrapper para cargar PNGs c/libpng en juegos basada en:
       - documentaci�n de libpng
       - The Definitive PNG Guide v2.0
	   - CDXPng de cocoaspud (add-on para cargar PNGS c/CDX)

 Versi�n: 0.00 (buggy)
 
 Anarkimedes, LCL 2004
-----------------------------------------------------------------------*/

//libpng (testeado con 1.2.7) y consecuentemente zlib
//#pragma comment(lib, "libpng.lib")
//#pragma comment(lib, "zlib.lib")
#include <png.h> 


#include <stdio.h>
#include <stdlib.h>

#include "cargarpng.h"



//GLOBALS
//-----------------------------------------------------------------//
BYTE*	png_file;		//pointer al PNG en memoria
long	offset;			//offset en bytes le�dos


//FUNCIONES
//-----------------------------------------------------------------//



//-----------------------------------------------------------------//

void user_read_data(png_structp png_ptr,png_bytep data,	png_size_t length)
//-----------------------------------------------------------------//
{
	memcpy(data,&png_file[offset],length);
	offset+=length;
}
//-----------------------------------------------------------------//




//-----------------------------------------------------------------//

RAW_IMGv0* CargarPNG(void* mem_ptr,int flags)
//-----------------------------------------------------------------//
{
	/* PARTE I - Init */
    //******************

	// PNG structs 
	png_structp png_ptr;
	png_infop info_ptr, end_info;
	png_uint_32 height, width, rowbytes;
	png_bytep *row_pointers;
	png_bytep row;

	//setea el puntero
	offset=0;
	png_file=(BYTE*)mem_ptr;
	
	//testea si es un PNG v�lido
	if (png_sig_cmp ((png_bytep)png_file, 0, 8))
		return 0;
    

	// Crea las infostructs
	if(!(png_ptr = png_create_read_struct (PNG_LIBPNG_VER_STRING, NULL, NULL, NULL)))
		return 0;      
	if(!(info_ptr = png_create_info_struct (png_ptr)))
		return 0;      
	if(!(end_info = png_create_info_struct (png_ptr)))
		return 0;      
    
	//setea el modo de lectura (user)
	png_set_read_fn(png_ptr,(voidp)png_file, user_read_data);



	/* PARTE II - Lee el PNG */
    //*************************
	
	int bit_depth,color_type,x,y;

	//header info
	png_read_info (png_ptr, info_ptr);
	
	png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth,
	  		     &color_type, NULL, NULL, NULL);


	//bytes per row, rowbytes   
    rowbytes = png_get_rowbytes (png_ptr, info_ptr);


	//espacio temporal para leer la imagen
	row_pointers =(png_bytep*) calloc (height, sizeof (png_bytep));

	int rowbyte_width=rowbytes+1;
	for (y = 0; y < height; y++)
		row_pointers[y] = (png_bytep)calloc (1, rowbyte_width);
    
	//lee la imagen
	png_read_image (png_ptr, row_pointers);
  


	/* PARTE III - Arma el RAW */
    //***************************

	RAW_IMGv0* raw_imgp=(RAW_IMGv0*)calloc(1,sizeof(RAW_IMGv0));
	
	raw_imgp->img_width=width;
	raw_imgp->img_height=height;
	raw_imgp->alpha_channel_8=0;

	raw_imgp->img_size=raw_imgp->img_height*raw_imgp->img_width*sizeof(_RGB24);

	raw_imgp->rgb_24=(_RGB24*)calloc(width*height,sizeof(_RGB24));


	//alpha channel
	if((flags&FORZAR_ALPHACHANNEL)||(color_type&PNG_COLOR_TYPE_RGB_ALPHA))
		raw_imgp->alpha_channel_8=(BYTE*)calloc(width*height,1);

	
	if(color_type == PNG_COLOR_TYPE_PALETTE)
	{
	   // read the palette or fill the palette with an ascending shade of gray	  
	   png_colorp pal;
	   int num_palette;
	   png_get_PLTE(png_ptr, info_ptr, &pal, &num_palette);

	   _RGB24 palette[256];

	   switch (color_type) 
	   {
			case PNG_COLOR_TYPE_GRAY :
			{
				for (int count = 0; count < 256; count++)
				{					
						palette[count].r=count;
						palette[count].g=count;
						palette[count].b=count;
				}
			}break;

			case PNG_COLOR_TYPE_PALETTE :
				{
					for (int count = 0; count < info_ptr->num_palette; count++)
					{
						palette[count].g=pal->green;
						if(flags&INVERTIR_COLOR)
						{
							palette[count].b=pal->red;						
							palette[count].r=pal->blue;
						}
						else
						{
							palette[count].r=pal->red;						
							palette[count].b=pal->blue;
						}
						
						pal++;
					}
				}break;
		}//end switch

		for (y = 0; y < height; y++)
		{
			row = row_pointers[y];
			for (x = 0; x < rowbytes; x = x++)
			{
				raw_imgp->rgb_24[y*width+x]=palette[row[x]];
				if(flags&FORZAR_ALPHACHANNEL)
					raw_imgp->alpha_channel_8[y*width+x]=row[x];
			}
				
		}
	}
	else
	{
	  int inc=3;
	  //ver si hay alpha channel
	  if(color_type&PNG_COLOR_TYPE_RGB_ALPHA)
	  {
		  inc=4;		  
	  }
	  else
		  raw_imgp->alpha_channel_8=0;
	  
	  for (y = 0; y < height; y++)
	  {
		  row = row_pointers[y];
		  for (x = 0; x < rowbytes; x = x + inc)
				{
					if(flags&INVERTIR_COLOR)
					{						
						raw_imgp->rgb_24[y*width+x/inc].b=row[x];
						raw_imgp->rgb_24[y*width+x/inc].g=row[x+1];
						raw_imgp->rgb_24[y*width+x/inc].r=row[x+2];						
					}
					else
					{						
						raw_imgp->rgb_24[y*width+x/inc].r=row[x];
						raw_imgp->rgb_24[y*width+x/inc].g=row[x+1];
						raw_imgp->rgb_24[y*width+x/inc].b=row[x+2];				
					}					

					if(color_type&PNG_COLOR_TYPE_RGB_ALPHA)
						raw_imgp->alpha_channel_8[y*width+x/4]=row[x+3];								
				}
	  }
	  
	}

  	/* PARTE IV - Apaga todo */
    //********************************

	//le dice a libpng que ya no se lee m�s
	png_read_end (png_ptr, info_ptr);

	//destruye los structs
	png_destroy_info_struct (png_ptr, &info_ptr);
	png_destroy_info_struct (png_ptr, &end_info);
	png_destroy_read_struct (&png_ptr, NULL, NULL);

	//limpia los buffers
	/* Cleanup alloc'ed buffers. */
	for (y = 0; y < height; y++)
		free (row_pointers[y]);
    free (row_pointers);

	//limpia el temporal en memoria
	//delete png_file;

	//devuelve el raw
	return raw_imgp;
}
//-----------------------------------------------------------------//





