/*----------------------------------------------------------------------
 FILE: CARGARPNG.H

 Desc: Wrapper para cargar PNGs c/libpng en juegos basada en:
       - documentaci�n de libpng
       - The Definitive PNG Guide v2.0
	   - CDXPng de cocoaspud (add-on para cargar PNGS c/CDX)

 Versi�n: 0.00 (buggy)
 
 Anarkimedes, LCL 2004
-----------------------------------------------------------------------*/

#ifndef CARGARPNG
#define CARGARPNG

#include <windows.h>

//RAW gen�rico RGBA 8-8-8-8

typedef struct __RGB24{
	BYTE r;
	BYTE g;
	BYTE b;
} _RGB24;

typedef struct _RAW_IMGv0{
	int img_width;
	int img_height;
	long img_size;
	_RGB24 *rgb_24;
	BYTE *alpha_channel_8;	
} RAW_IMGv0;


//flags soportadas
#define INVERTIR_COLOR		0x0001
#define	FORZAR_ALPHACHANNEL	0x0002


//con esto se hace todo
RAW_IMGv0* CargarPNG(void* mem_ptr,int flags);

#endif


