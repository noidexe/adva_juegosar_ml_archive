#ifndef DEBUGTRUCHO
#define DEBUGTRUCHO

#include <stdlib.h>

//bloque DEBUG
//-------------------------------------------------------//
class DebugTrucho{
	FILE* debugfp;
public:
	void Open(char* filename){debugfp=fopen(filename,"w");}
	void Close(){fclose(debugfp);}
	void Out(char*txt){fprintf(debugfp,txt);}
	void HLine(){
		fprintf(debugfp,"--------------------------------------------\n");
	}
};

//-------------------------------------------------------//

#endif