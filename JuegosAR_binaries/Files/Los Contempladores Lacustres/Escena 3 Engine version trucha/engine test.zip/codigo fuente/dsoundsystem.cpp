//--------------------------------------------------------------------//
// FILE: DSoundSystem.CPP
// Desc: una clase para acceder a DirectSound (por el momento 
//       single-threaded pero buehhhh...)
//
// AnArKiMeDeS 2.004k
// "just coding a piece of future"
//--------------------------------------------------------------------//

#include "dsoundsystem.h"

//--------------------------------------------------------------------//

int CDSoundSystem::Init(HWND hwnd, int sample_rate,int latency)

//--------------------------------------------------------------------//
{

DirectSoundCreate(NULL,&lpDSnd,NULL);
lpDSnd->SetCooperativeLevel(hwnd,DSSCL_PRIORITY);
 
ZeroMemory(&dsbdesc, sizeof(DSBUFFERDESC));
dsbdesc.dwSize = sizeof(DSBUFFERDESC);
dsbdesc.dwFlags = DSBCAPS_PRIMARYBUFFER;
if FAILED(lpDSnd->CreateSoundBuffer(&dsbdesc, &lpdsbPrimary, NULL))
        return FALSE;

WAVEFORMATEX wfx;
memset(&wfx, 0, sizeof(WAVEFORMATEX)); 
wfx.wFormatTag = WAVE_FORMAT_PCM; 
wfx.nChannels = 1; 
wfx.nSamplesPerSec = sample_rate; 
wfx.wBitsPerSample = 16; 
wfx.nBlockAlign = wfx.wBitsPerSample / 8 * wfx.nChannels;
wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
     
lpdsbPrimary->SetFormat(&wfx); 

memset(&dsbdesc, 0, sizeof(DSBUFFERDESC)); 
dsbdesc.dwSize = sizeof(DSBUFFERDESC); 
dsbdesc.dwFlags = DSBCAPS_GETCURRENTPOSITION2   // Always a good idea
				| DSBCAPS_GLOBALFOCUS			// Allows background playing
				| DSBCAPS_CTRLPOSITIONNOTIFY;	// Needed for notification

float bufsize=latency/1000.0f;

dsbdesc.dwBufferBytes = wfx.nAvgBytesPerSec * bufsize;  

//bufSize lo piden los que necesitan streambuffer
bufSize=dsbdesc.dwBufferBytes;

dsbdesc.lpwfxFormat = &wfx; 

length=dsbdesc.dwBufferBytes/2;

if(FAILED(lpDSnd->CreateSoundBuffer(&dsbdesc,&lpdsbStreamBuffer,NULL)))
		return false;

//notifys
for (int i = 0; i < 2; i++)
    {
        rghEvent[i] = CreateEvent(NULL, FALSE, FALSE, NULL);
        if (NULL == rghEvent[i]) return FALSE;
    }

rgdsbpn[0].dwOffset = 0;
rgdsbpn[0].hEventNotify = rghEvent[0];
rgdsbpn[1].dwOffset = (dsbdesc.dwBufferBytes/2);
rgdsbpn[1].hEventNotify = rghEvent[1];


if FAILED(IDirectSoundBuffer_QueryInterface(lpdsbStreamBuffer, 
          IID_IDirectSoundNotify, (VOID **)&lpdsNotify))
        return FALSE; 
 
if FAILED(IDirectSoundNotify_SetNotificationPositions(
          lpdsNotify, 2, rgdsbpn))
    {
        IDirectSoundNotify_Release(lpdsNotify);
        return FALSE;
    }

	return 1; //todo ok.
}
//--------------------------------------------------------------------//


//--------------------------------------------------------------------//

bool CDSoundSystem::Play()

//--------------------------------------------------------------------//
{
	lpdsbStreamBuffer->Play(0, 0, DSBPLAY_LOOPING);
	
	return true;
}
//--------------------------------------------------------------------//



//--------------------------------------------------------------------//

bool CDSoundSystem::Stop()

//--------------------------------------------------------------------//
{
	lpdsbStreamBuffer->Stop();

	return false;			
}
//--------------------------------------------------------------------//



//--------------------------------------------------------------------//

int CDSoundSystem::OpenStreamBuffer(short** ptr,LONG* n_samples)

//--------------------------------------------------------------------//
{
    static DWORD    dwStopNextTime = 0xFFFF;
 
	if (dwPos == 0)
        dwStartOfs = rgdsbpn[2 - 1].dwOffset;
    else
        dwStartOfs = rgdsbpn[dwPos-1].dwOffset;

    lNumToWrite = (LONG) rgdsbpn[dwPos].dwOffset - dwStartOfs;
    if (lNumToWrite < 0) lNumToWrite += dsbdesc.dwBufferBytes;  

	if(FAILED(lpdsbStreamBuffer->Lock(dwStartOfs,lNumToWrite,
		                              &lpvPtr1,&dwBytes1,&lpvPtr2,
									  &dwBytes2,0))) 
	return 0;

	*ptr=(short*)lpvPtr1;
	*n_samples=lNumToWrite/2;	

	return 1;
}
//--------------------------------------------------------------------//



//--------------------------------------------------------------------//

void CDSoundSystem::CloseStreamBuffer()

//--------------------------------------------------------------------//
{
	lpdsbStreamBuffer->Unlock(lpvPtr1, dwBytes1, lpvPtr2, dwBytes2);
}
//--------------------------------------------------------------------//



//--------------------------------------------------------------------//

void CDSoundSystem::ShutDown()

//--------------------------------------------------------------------//
{
	lpdsbPrimary->Release();
	lpdsbStreamBuffer->Release();
	lpDSnd->Release();
}
//--------------------------------------------------------------------//



//--------------------------------------------------------------------//

void CDSoundSystem::GetEventHandles(HANDLE* rghEvents)

//NO, NO, NO!!!! Esto es cualquiera!!!!!!!!

//--------------------------------------------------------------------//
{
	rghEvents[0]=rghEvent[0];
	rghEvents[1]=rghEvent[1];
}
//--------------------------------------------------------------------//


    
