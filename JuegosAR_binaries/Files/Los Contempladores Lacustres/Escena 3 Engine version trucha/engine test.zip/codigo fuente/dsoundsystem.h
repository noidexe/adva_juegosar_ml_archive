#ifndef DSOUNDSYSTEM
#define DSOUNDSYSTEM

#include <windows.h>
#include <mmreg.h>
#include <dsound.h>


class CDSoundSystem{

LPDIRECTSOUND			lpDSnd;
LPDIRECTSOUNDBUFFER		lpdsbPrimary,lpdsbStreamBuffer;
LPDIRECTSOUNDNOTIFY		lpdsNotify;
DSBPOSITIONNOTIFY		rgdsbpn[2]; //event system (ya encontrar� una mejor soluci�n...)
DSBUFFERDESC			dsbdesc;
int						length;
HANDLE					rghEvent[2];

//stream buffering
LONG            lNumToWrite;
DWORD           dwStartOfs;
VOID            *lpvPtr1, *lpvPtr2;
DWORD           dwBytes1, dwBytes2;
UINT            cbBytesRead;
public:
	DWORD					bufSize;//para streambuffer
	DWORD					dwPos;
	int Init(HWND hwnd, int sample_rate,int latency);
	int CDSoundSystem::OpenStreamBuffer(short** ptr,LONG* n_samples);
	void CloseStreamBuffer();
	void ShutDown();
	void GetEventHandles(HANDLE* rghEvents); //ESTO SI QUE ES CUALQUIEEEEERA!!!! 
	bool Play();
	bool Stop();
};

#endif