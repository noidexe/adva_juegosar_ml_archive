#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "parsing.h"


#define MAXSIZE 256

void NextDelimiter(char* &p,char c)
{
	//avanza hasta el primer delimitador
	while(*p!=c)
		*p++;
	if(*p==c)p++; //p queda en el primer caracter

	return;
}

char* StringFromArg(char* &p,char c1,char c2)
{	
	char tmp[MAXSIZE];
	int k=0;
	char* return_string;

	NextDelimiter(p,c1);
	
	//copia
	while(*p!=c2)
		tmp[k++]=*p++;
	if(*p==c2)p++;//p queda despues del delimitador

			
	//ac� lo copia
	return_string=new char[k+1];
	memcpy(return_string,tmp,k);
	return_string[k]='\0';

	return return_string;
}

int GetNextNumberParam(char* &p)
{
	char tmp[16];
	int k=0;
	while((*p<0x30) || (*p>0x39))
		*p++;

	while((*p>0x2f) && (*p<0x3A))
		tmp[k++]=*p++;
	tmp[k]='\0';

	return(atoi(tmp));	
}


void SacarComentarios(char* buffer)
{
	int i=0,j;
	//primero elimina los comentarios
	while(buffer[i]!='\0')
	{
		if(buffer[i]!=';') 
			i++;
		else
		{
			j=0;
			buffer[i]=',';	
			i++;
			while(buffer[i]!='\n' && buffer[i]!='\0')
			{
				buffer[i]=' ';
				i++;
			}
		}
	}
}


bool NotDelimiter(char* &p,char* seps)
{
	int i=0;
	while(seps[i]!='\0')
	{
		if(*p==seps[i])
			return 0;
		else
			i++;
	}
	return 1;
}


char* GetNextToken(char* &p,char* seps)
{
	int i=0,len;	
	char* returntoken;
	char* token;

	//avanza hasta el token
	while(!NotDelimiter(p,seps))p++;

	token=p;
	//avanza hasta despues del token
	while(NotDelimiter(p,seps))p++;	

	len=p-token;

	returntoken=new char[len+1];
	memcpy(returntoken,token,len);
	returntoken[len]='\0';

	return returntoken;

}

