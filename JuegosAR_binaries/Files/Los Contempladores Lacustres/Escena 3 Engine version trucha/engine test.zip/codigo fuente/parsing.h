#ifndef PARSING
#define PARSING

char* StringFromArg(char*  &p,char c1,char c2);
void SacarComentarios(char* buffer);
int GetNextNumberParam(char* &p);
char* GetNextToken(char* &p,char* seps);
bool NotDelimiter(char* &p,char* seps);

#endif