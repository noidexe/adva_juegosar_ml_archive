#ifndef PATTERN_TYPES
#define PATTERN_TYPES



typedef struct _CHANNELFORMAT{
	int n_fields;
	int* data_type;
} CHANNELFORMAT;

typedef struct _PATTERNDATAFORMAT{
	CHANNELFORMAT general;
	int n_channels;
	CHANNELFORMAT channel;	
	int bytes_per_row;
} PATTERNDATAFORMAT;

typedef struct _TPATTERN{
	int	n_rows;
	unsigned char* data;
} TPATTERN;


/*
FORMATOS V�LIDOS PARA LOS FIELDS
-----------------------------------------------------------
 Type Id	|	Desc. 
-----------------------------------------------------------
      0     |  Nota-Octava. [...] Ej: A.3, C#5                             
	  1     |  Par�metro entero de 0-99                                              
	  2     |
*/
typedef struct _TYPEFORMAT{
	int type_chlength;
	int n_bytes;	
} TYPEFORMAT;

#endif