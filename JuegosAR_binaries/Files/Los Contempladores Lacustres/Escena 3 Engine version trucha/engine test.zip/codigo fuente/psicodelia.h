#ifndef PSICODELIA
#define PSICODELIA


class Psicodelia{
public:
	void Init(){}
	void Apagar(){}
};

//callbacks
void prueba(short* sndbuffer,long n_samples,int ticklength);

void SetPsicodeliaMachine(Psicodelia* psicodelia):

#endif