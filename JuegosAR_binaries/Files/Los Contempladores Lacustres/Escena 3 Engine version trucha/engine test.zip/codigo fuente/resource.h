//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define APP_ICON                        101
#define IDD_CONFIG                      102
#define IDC_FULLSCREEN                  1000
#define IDC_32BIT                       1001
#define IDC_16BIT                       1002
#define IDC_LOFI                        1003
#define IDC_RADIO4                      1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
