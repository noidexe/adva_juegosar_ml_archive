
//------------------------------------------------------------//
typedef struct _HOTSPOT{
	BYTE text_len;
	short n_vertices;
	BYTE def_action;
} HOTSPOT;

//versiones
//------------------------------------------------------------//
#define ROOMFILE_VERSION 050304 //�ltima versi�n

typedef struct _ROOMFILE{
	//version
	int version;
	//jpg
	DWORD	img_size;
	//hotspot info
	int		n_hotspots;
	int		img_width;
	int		img_height;
	
	//salidas
	char salidas[4];
	BYTE salida_txt_lens[4];

	//musica
	BYTE	music_code;
	BYTE    volumen;
} ROOMFILE;

//------------------------------------------------------------//