//--------------------------------------------------------------------//
//FILE: Softsynth.CPP
//
//--------------------------------------------------------------------//
#include <windows.h>
#include <math.h>

#include "patterntypes.h"
#include "softsynth.h"



//PROVISORIO!!!
#include "LFO.h"

//Defines y macros
//--------------------------------------------------------------------//

//formato de las notas

// |7|6|5|4|-|3|2|1|0|
// --------- ---------
//  octava     nota

#define OCTAVE(d) (d&0xF)
#define NOTE(d) ((d&0xF0)>>4)
#define PACKNOTE(octave,note) (octave<<4)+note;

//formato de los par�metros

// |7|-|6|5|4||3|2|1|0|
// --- ----------------
//  |          | 
//  |           \-> par�metro (0,...,2^7-1=127
//   \-> nulo: si/no

#define PACKPARAMETER(parameter) (0x80|parameter)
#define UNPACKPARAMETER(parameter) (parameter&0x7F)

const TYPEFORMAT tf[]={3,1,
					   2,1};


extern PLAYERDATA pd;

//--------------------------------------------------------------------//
// OSC, ADSRs
//********************************************************************//

// OSC
//--------------------------------------------------------------------//

OSC::OSC()
{
	//sin init
	cos=16384.0;//amplitud
	sin=0.0;

	//sawtooth
	a=-20000;
	counter=1;
	old_out=a;

	wave_type=1;
}

void OSC::SetWave(int p_wavetype)
{
	wave_type=p_wavetype;	
}

void OSC::SetSamplingFreq(int p_sampling_freq)
{
	sampling_freq=p_sampling_freq;
}

void OSC::SetFreq(float frq)
{
	//sin
	temp=2.0f*M_PI*frq/sampling_freq;

	//sawtooth	
	temp1=sampling_freq/frq;
	temp2=2.0*-a/temp1;	
	
}

short OSC::Tick()
{
	switch(wave_type)
	{
		//sin
		case 0:
			{
			sin+=temp*cos;
			cos-=temp*sin;
			return int(0.5+sin);
			}break;

		//sawtooth
		case 1:
			{
				short out=old_out+temp2+0.5;
				++counter;
				if (counter>int(0.5+temp1))                       //   !!! 
				{
					out=a;
					counter=0;
				}
				old_out=out;
				return out;    
			}break;
	}//end switch
}

// ADSR
//--------------------------------------------------------------------//

void ADSR::Release()
{
	counter=0;
	state=3;
}


int ADSR::GetState()
{
	return state;
}

ADSR::Trigger()
{
	counter=0;
	state=0;
}

void ADSR::SetTickLength(int p_ticklength)
{
	tick_length=p_ticklength;
	attack=attack_const*tick_length;
	decay=decay_const*tick_length;
	sustain=sustain_const*tick_length;
	release=release_const*tick_length;
}

float ADSR::Tick()
{
	counter++;
	switch (state)
	{
	//attack
	case 0:
		{
			if(counter<attack)
			{
				return float(counter/attack)*full_amp;
			}
			else
			{
				counter=0;			
				state++;
				return full_amp;
			}
		} break;
	//decay
	case 1:
		{
			if(counter<decay)
				return float(full_amp-(full_amp-sustain_amp)*(counter/decay));
			else
			{
				counter=0;
				state++;
				return sustain_amp;
			}
		} break;
	//sustain
	case 2:
		{
			if(counter<sustain)
				return sustain_amp;
			else
			{
				counter=0;
				state++;
				return sustain_amp;
			}
		} break;
	//release
	case 3:
		{
			if(counter<release)
				return float(sustain_amp-sustain_amp*(counter/release));
			else
			{
				counter=0;
				state=4;
				return 0;
			}
		} break;
	
	}//end switch

	return 0;
}
//--------------------------------------------------------------------//


//--------------------------------------------------------------------//
// Filtros
//********************************************************************//

float MoogVCF::run(float input)
{
  
  input -= out4 * fb;
  input *= 0.35013 * (f*f)*(f*f);
  out1 = input + 0.3 * in1 + (1 - f) * out1; // Pole 1
  in1  = input;
  out2 = out1 + 0.3 * in2 + (1 - f) * out2;  // Pole 2
  in2  = out1;
  out3 = out2 + 0.3 * in3 + (1 - f) * out3;  // Pole 3
  in3  = out2;
  out4 = out3 + 0.3 * in4 + (1 - f) * out4;  // Pole 4
  in4  = out3;
  return out4;
}

MoogVCF::MoogVCF()
{
	in1=in2=in3=in4=out1=out2=out3=out4=0;
	SetCutoff(1.0);
	SetResonance(0.1);
}

void MoogVCF::SetCutoff(float fc){f = fc * 1.16;}
void MoogVCF::SetResonance(float res){fb = res * (1.0 - 0.15 * f * f);}


//delay base
//--------------------------------------------------------------------//

FX_Delay::FX_Delay()
{	
	counter=0;
    for(int s=0;s<MAX_WG_DELAY;s++)
            buffer[s]=0;
	delay=0;
	feedback=0;
}

float FX_Delay::Run(float in)
{
	// calculate delay offset
        double back=(double)counter-delay;
        
        // clip lookback buffer-bound
        if(back<0.0)
            back=MAX_WG_DELAY+back;
        
        // compute interpolation left-floor
        int const index0=floor(back);
        
        // compute interpolation right-floor
        int index_1=index0-1;
        int index1=index0+1;
        int index2=index0+2;
        
        // clip interp. buffer-bound
        if(index_1<0)index_1=MAX_WG_DELAY-1;
        if(index1>=MAX_WG_DELAY)index1=0;
        if(index2>=MAX_WG_DELAY)index2=0;
        
        // get neighbourgh samples
        float const y_1= buffer [index_1];
        float const y0 = buffer [index0];
        float const y1 = buffer [index1];
        float const y2 = buffer [index2];
        
        // compute interpolation x
        float const x=(float)back-(float)index0;
        
        // calculate
        float const c0 = y0;
        float const c1 = 0.5f*(y1-y_1);
        float const c2 = y_1 - 2.5f*y0 + 2.0f*y1 - 0.5f*y2;
        float const c3 = 0.5f*(y2-y_1) + 1.5f*(y0-y1);
        
        float const output=((c3*x+c2)*x+c1)*x+c0;
        
        // add to delay buffer
        buffer[counter]=in+output*feedback;
        
        // increment delay counter
        counter++;
        
        // clip delay counter
        if(counter>=MAX_WG_DELAY)
            counter=0;
        
        // return output
        return output;
}


//ECHO

float Echo::Run(float in)
{	
	float output=in;	
	buffer[pos]=in;

	//LOWPASS
	//output(t) = output(t-1) + c*(input(t)-output(t-1)) 
	
	for(int i=1;i<8;i++)
	{
		int k=pos-delay*i;		
		if(k<0)k=DELAY_SIZE+k;		
		output+=(decay/i)*buffer[k];
	}
	
	pos++;
	if(pos>=DELAY_SIZE-1)pos=0;
	
	return output;
}

//--------------------------------------------------------------------//
// FX
//********************************************************************//


//REVERB
//--------------------------------------------------------------------//

Reverb::Reverb()
{
	rev_out=0.4;
	for(int i=0;i<COMB_FILTERS;i++)
	{
		CombFilters[i].SetFeedback(rev_out);
		CombFilters[i].SetDelay(MAX_WG_DELAY/COMB_FILTERS*i);
	}
}

float Reverb::Run(float in)
{	
	for(int i=0;i<COMB_FILTERS;i++)
			in+=CombFilters[i].Run(in);	
	return in;
}

void Reverb::SetRevOut(float p_rev_out)	
{
	for(int i=0;i<COMB_FILTERS;i++)
		CombFilters[i].SetFeedback(p_rev_out);
}


//FLANGER
//--------------------------------------------------------------------//

Flanger::Flanger()
{
	min=0;
	max=200;
	Combfilter.SetFeedback(0.5);
	osc.SetSamplingFreq(44100);
	osc.SetFreq(30);
	osc.SetWave(0);
	SetMaxDelay(max);
	SetMinDelay(min);
}

float Flanger::Run(float in)
{	
	Combfilter.SetDelay(center+osc.Tick());
	return Combfilter.Run(in);
}

void Flanger::SetMaxDelay(float p_max)
{
	max=p_max;
	osc.SetAmp((max-min)/2);
	center=(min+max)/2;
}

void Flanger::SetMinDelay(float p_min)
{
	min=p_min;
	osc.SetAmp((max-min)/2);
	center=(min+max)/2;
}


float Distortion::Run(float in)
{
	float output;
	int sign=-1;
	if (in>0)sign=1;
	
	if (abs(in)>threshold)
		output=dry*in+sign*distorted*level;
    else output=in*(dry + distorted);

	return output;        
}

Distortion::Distortion()
{
	float threshold=1000;
	float level=10000;
	float dry=1.0;
	float distorted=1.0;	
}


//--------------------------------------------------------------------//
// Synths de prueba
//********************************************************************//


//MONGOSYNTH v0.01
//--------------------------------------------------------------------//

CMongoSynth1::CMongoSynth1()
{
	//seteo del pattern data format
	pf.general.n_fields=8;
	pf.general.data_type=new int[8];
	int grl_data_types[8]={1,1,1,1,1,1,1,1};
	memcpy(pf.general.data_type,grl_data_types,8*sizeof(int));
	pf.channel.n_fields=4;
	pf.channel.data_type=new int[4];
	int chnl_data_types[4]={0,1,1,1};
	memcpy(pf.channel.data_type,chnl_data_types,4*sizeof(int));
	
	oscs=NULL;
	adsr=NULL;
	
	SetChannels(1);
}

void CMongoSynth1::SetChannels(int n_channels)
{	
	pf.n_channels=n_channels;

	//OSC
	if(oscs)delete[]oscs;
	if(adsr)delete[]adsr;
	oscs=new OSC[pf.n_channels];
	adsr=new ADSR[pf.n_channels];
	
	pf.bytes_per_row=CalcBytesPerRow(&pf);

	for(int i=0;i<pf.n_channels;i++)
	{
		oscs[i].SetWave(1);
		oscs[i].SetSamplingFreq(44100);		
				
		adsr[i].SetFullAmp(1.0f);
		adsr[i].SetSustainAmp(1.0f);

		adsr[i].SetAttack(0);
		adsr[i].SetDecay(0);
		adsr[i].SetSustain(1);
		adsr[i].SetRelease(0);			
	}	
}


float CMongoSynth1::Tick()
{
	float mix=0;
	float output=0;
	int i;
	for(i=0;i<pf.n_channels;i++)
	{		
		mix+=oscs[i].Tick()*adsr[i].Tick();		
	}	
	
	return moogfilter.run(mix);
}


void CMongoSynth1::PlayNote(int channel, BYTE note)
{
	int note_id=NOTE(note);
	int octave=OCTAVE(note);

	if(octave!=0)
	{
		float freq=440*pow(2,(note_id+10+(octave-6)*12)/12.0);
			
		oscs[channel].SetFreq(freq);
		adsr[channel].Trigger();				
	}
}


void CMongoSynth1::PlayRow(BYTE* row_data)
{

	//las notas
	int note_id;
	int octave;
	BYTE note;

	//par�metros ADSR
	int params[4];
	for(int i=0;i<4;i++)
		if(row_data[i])
			params[i]=UNPACKPARAMETER(row_data[i]);
		else 
			params[i]=-1;

	//par�metros MoogVCF
	if(row_data[4])
		moogfilter.SetCutoff((float)(UNPACKPARAMETER(row_data[4]))/99.0f);
	if(row_data[5])
		moogfilter.SetResonance((float)(UNPACKPARAMETER(row_data[5]))*4.0f/99.0f);
	
	row_data+=8;

	for(int channel=0;channel<pf.n_channels;channel++)
	{
		//par�metros

		if(params[0]!=-1)adsr[channel].SetAttack(params[0]);
		if(params[1]!=-1)adsr[channel].SetDecay(params[1]);
		if(params[2]!=-1)adsr[channel].SetSustain(params[2]);
		if(params[3]!=-1)adsr[channel].SetRelease(params[3]);		
		
		note=row_data[channel*4];
		note_id=NOTE(note);
		octave=OCTAVE(note);
	
		if(row_data[channel*4+1])adsr[channel].SetFullAmp(float(UNPACKPARAMETER(row_data[channel*4+1]))/99.0f);
		if(row_data[channel*4+2])adsr[channel].SetSustainAmp(float(UNPACKPARAMETER(row_data[channel*4+2]))/99.0f);
		
		if(octave)
		{
			float freq=440*pow(2,(note_id+10+(octave-6)*12)/12.0);
					
			oscs[channel].SetFreq(freq);
			adsr[channel].Trigger();			
			
		}
	}

}

void CMongoSynth1::UpdateConstants(PLAYERDATA *pd_ptr)
{
	for(int i=0;i<pf.n_channels;i++)
		adsr[i].SetTickLength(pd_ptr->ticklength);		
}

void CMongoSynth1::ReleaseNote(int channel){}
void CMongoSynth1::StopNote(int channel){}
//--------------------------------------------------------------------//


//CDrumz
//--------------------------------------------------------------------//

CDrumz::CDrumz()
{
	//seteo del pattern data format
	pf.general.n_fields=DRUMZ_CHN;
	pf.general.data_type=new int[DRUMZ_CHN];
	int grl_data_types[DRUMZ_CHN]={1,1,1};
	memcpy(pf.general.data_type,grl_data_types,DRUMZ_CHN*sizeof(int));
	pf.channel.n_fields=0;
	pf.channel.data_type=NULL;

	pf.bytes_per_row=CalcBytesPerRow(&pf);
	
	//genera las tablas de samples
	int i;
	//BASS DRUM
	//------------------------------------------//
	smp_length[0]=1024;
	smp_tables[0]=new short[1024];
	smp_pos[0]=1024;
	for(i=0;i<1024;i++)
	{
		smp_tables[0][i]=((12000+rand()%4000)*sin(M_PI*i/100)+(8000+rand()%8000*sin(12800*i*i/((pow(2,i)+1)))))/99;		
	}

	//CASTA�UELAS
	//------------------------------------------//
	smp_length[1]=1024;
	smp_tables[1]=new short[1024];
	smp_pos[1]=1024;
	moogfilter.SetCutoff(0.9);
	moogfilter.SetResonance(4.0);
	for(i=0;i<1024;i++)
	{
		smp_tables[1][i]=16000*sin(1000*i*i/((pow(2,i)+1)))/99;
	}

	//COSO
	//------------------------------------------//
	smp_length[2]=1024;
	smp_tables[2]=new short[1024];
	smp_pos[2]=1024;
	moogfilter.SetCutoff(0.6);
	moogfilter.SetResonance(4.0);
	for(i=0;i<1024;i++)
	{
		if(i<512)
			smp_tables[2][i]=8*rand()%(i+1);	
		else
			smp_tables[2][i]=8*rand()%(1024-i);	
	}





}


void CDrumz::PlayRow(BYTE* row_data)
{	
	for(int i=0;i<DRUMZ_CHN;i++)
	{
		if(row_data[i])
		{
			amp[i]=UNPACKPARAMETER(row_data[i]);
			smp_pos[i]=0;
		}	
	}
}

float CDrumz::Tick()
{
	float mix=0;

	for(int i=0;i<DRUMZ_CHN;i++)
	{
		if(smp_pos[i]<smp_length[i])
			mix+=amp[i]*smp_tables[i][smp_pos[i]++];
	}
	return mix;
}







//--------------------------------------------------------------------//

int CalcBytesPerRow(PATTERNDATAFORMAT *pdf)

//--------------------------------------------------------------------//
{
	int i;
	int bpr=0;

	for(i=0;i<pdf->channel.n_fields;i++)
		bpr+=tf[pdf->channel.data_type[i]].n_bytes;
	
	bpr*=pdf->n_channels;

	for(i=0;i<pdf->general.n_fields;i++)
		bpr+=tf[pdf->general.data_type[i]].n_bytes;
	
	return bpr;
}
//--------------------------------------------------------------------//
