#include "patterntypes.h"


// DEFINES
//--------------------------------------------------------------------//
#ifndef SOFTSYNTH
#define SOFTSYNTH

#ifndef BYTE
	#define BYTE unsigned char
#endif

#define M_PI 3.1415926

typedef struct _PLAYERDATA{
	int samplerate; //por lo general 44100 HZ
	int bpm;		
	int ticklength; //el tick length en samples: ticklength=samplerate*60/bpm/TPB (asumimos TPB=4)
} PLAYERDATA;


//--------------------------------------------------------------------//
// PROTOS, CLASES, etc.
//********************************************************************//

// OSC
//--------------------------------------------------------------------//

class OSC{
	int sampling_freq;
	int wave_type;
	
	//sin wave
	float temp;
	float cos;
	float sin;

	//sawtooth wave
	float temp1;
	float temp2;
	float a;
	int counter;
	short old_out;

public:
	OSC();
	void SetFreq(float freq);
	void SetSamplingFreq(int p_sampling_freq);
	void SetAmp(short amp){cos=amp;a=amp;}
	void SetWave(int p_wavetype);
	short Tick();
};

// ADSR
//--------------------------------------------------------------------//
class ADSR{
	int tick_length;

	int attack;
	int decay;
	int sustain;
	int release;

	int attack_const;
	int decay_const;
	int sustain_const;
	int release_const;

	float full_amp;
	float sustain_amp;

	int state;
	float counter;
	
public:
	int GetState();
	void Release();
	void ADSR::SetAttack(int p_attack){attack=p_attack*tick_length;attack_const=p_attack;}
	void ADSR::SetDecay(int p_decay){decay=p_decay*tick_length;decay_const=p_decay;}
	void ADSR::SetSustain(int p_sustain){sustain=p_sustain*tick_length;sustain_const=p_sustain;}
	void ADSR::SetRelease(int p_release){release=p_release*tick_length;release_const=p_release;}
	
	void ADSR::SetFullAmp(float p_full){full_amp=p_full;}
	void ADSR::SetSustainAmp(float p_sustain){sustain_amp=p_sustain;}
	
	void ADSR::SetTickLength(int p_ticklength);
	Trigger();
	float Tick();
};



// Moog Voltage Controlled Filter
//--------------------------------------------------------------------//
class MoogVCF{
	float in1,in2,in3,in4,
		  out1,out2,out3,out4;
	double f;
	double fb;
public:
	MoogVCF();
	float run(float input);
	void MoogVCF::SetCutoff(float fc);
	void MoogVCF::SetResonance(float res);
	
};


//FX
//--------------------------------------------------------------------//

//GENERIC DELAY CLASS

#define MAX_WG_DELAY 4096

class FX_Delay {
	float    buffer[MAX_WG_DELAY];
    int      counter;
	float delay;
	float feedback;
public:
	FX_Delay();
	void SetFeedback(float p_feedback){feedback=p_feedback;}
	void SetDelay(int p_delay){delay=p_delay;if(delay>MAX_WG_DELAY)delay=MAX_WG_DELAY-1;}
	float Run(float in);
};


//REVERB

#define COMB_FILTERS 4

class Reverb{
	FX_Delay CombFilters[COMB_FILTERS];
	float rev_out;
public:
	Reverb();
	void SetRevOut(float p_rev_out);	
	float Run(float in);
};

//FLANGER

class Flanger{
	OSC osc;
	FX_Delay Combfilter;
	int max;
	int min;
	int center;
public:
	Flanger();
	float Run(float in);
	void SetMinDelay(float p_mix);
	void SetMaxDelay(float p_max);
	void SetSpeed(float speed){osc.SetFreq(speed);}
	void SetFeedback(float feedback){Combfilter.SetFeedback(feedback);}
};


//FINALES
//--------------------------------------------------------------------//

//DISTORTION

class Distortion{
	short threshold;
	short level;
	float dry;
	float distorted;
public:
	Distortion();
	void SetThreshold(short value) {threshold=value;} //[0.0 - 32000.0]
	void SetLevel(short value) {level=value;} // [0..100?]
	void SetDry(float value) {dry=value;} //[0.0-1.0]
	void SetDistorted(float value) {distorted=value;} //[0.0-1.0]
	float Run(float in);
};


//ECHO
#define DELAY_SIZE 44100

class Echo{
	short buffer[DELAY_SIZE];
	int delay;
	float decay;
	int pos;
	float c;
public:
	Echo(){ZeroMemory(buffer,DELAY_SIZE*sizeof(short));pos=0;c=0.0f;}
	void SetDelay(int p_delay){delay=p_delay;}
	void SetCutoff(float p_cutoff){c=p_cutoff;}
	void SetDecay(float p_decay){decay=p_decay;}
	float Run(float in);
};



//--------------------------------------------------------------------//
// SYNTH GEN�RICO
//********************************************************************//

class CMachine{
protected:
	PLAYERDATA* pd_ptr;
	PATTERNDATAFORMAT pf;
public:
	int type; //0= Generador 1= FX
	PATTERNDATAFORMAT* GetPatternDataformat(){return &pf;}
	virtual void UpdateConstants(PLAYERDATA* pd_ptr)=0;	
	virtual float Tick()=0;

};

class CGenerator: public CMachine{
public:
	CGenerator(){type=0;}
	virtual void SetChannels(int n_channels)=0;
	virtual void PlayNote(int channel,BYTE note)=0;
	virtual void PlayRow(BYTE* row_data)=0;
	virtual void StopNote(int channel)=0;
	virtual void ReleaseNote(int channel)=0;
};

//para inicializar patterndataformat
int CalcBytesPerRow(PATTERNDATAFORMAT *pdf);


//--------------------------------------------------------------------//
// MONGOSYNTH v0.01
//********************************************************************//
//
// Specs: - poly OSCs -> ADSR
//        - Moog VCF
//--------------------------------------------------------------------//

#define NUM_DELAYS 4

class CMongoSynth1: public CGenerator{
	OSC* oscs;
	ADSR* adsr;
	MoogVCF moogfilter;	
	FX_Delay DelayFX[NUM_DELAYS];
public:
	CMongoSynth1();
	void SetChannels(int n_channels);
	void UpdateConstants(PLAYERDATA* pd_ptr);
	float Tick();
	void PlayNote(int channel,BYTE note);
	void PlayRow(BYTE* row_data);
	void StopNote(int channel);
	void ReleaseNote(int channel);
};

//--------------------------------------------------------------------//
// Drumz v0.00
//********************************************************************//
//
// Specs: N/A
//        
//--------------------------------------------------------------------//

#define DRUMZ_CHN 3

class CDrumz: public CGenerator{
	short* smp_tables[DRUMZ_CHN];
	short smp_length[DRUMZ_CHN];
	short smp_pos[DRUMZ_CHN];
	int amp[DRUMZ_CHN];
	MoogVCF moogfilter;
public:
	CDrumz();	
	void UpdateConstants(PLAYERDATA* pd_ptr){}
	float Tick();
	void SetChannels(int n_channels){}
	void PlayNote(int channel,BYTE note){}
	void PlayRow(BYTE* row_data);
	void StopNote(int channel){}
	void ReleaseNote(int channel){}	
};

#endif

