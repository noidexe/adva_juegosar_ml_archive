#include <math.h>

#include "synths_and_fx.h"

//--------------------------------------------------------------------//
// OSC, ADSRs
//********************************************************************//

// OSC
//--------------------------------------------------------------------//

OSC::OSC()
{
	//sin init
	cos=16384.0;//amplitud
	sin=0.0;

	//sawtooth
	a=-20000;
	counter=1;
	old_out=a;

	wave_type=1;
}

void OSC::SetWave(int p_wavetype)
{
	wave_type=p_wavetype;	
}

void OSC::SetSamplingFreq(int p_sampling_freq)
{
	sampling_freq=p_sampling_freq;
}

void OSC::SetFreq(float frq)
{
	//sin
	temp=2.0f*M_PI*frq/sampling_freq;

	//sawtooth	
	temp1=sampling_freq/frq;
	temp2=2.0*-a/temp1;	
	
}

short OSC::Tick()
{
	switch(wave_type)
	{
		//sin
		case 0:
			{
			sin+=temp*cos;
			cos-=temp*sin;
			return int(0.5+sin);
			}break;

		//sawtooth
		case 1:
			{
				short out=old_out+temp2+0.5;
				++counter;
				if (counter>int(0.5+temp1))                       //   !!! 
				{
					out=a;
					counter=0;
				}
				old_out=out;
				return out;    
			}break;
	}//end switch
}

// ADSR
//--------------------------------------------------------------------//

void ADSR::Release()
{
	counter=0;
	state=3;
}


int ADSR::GetState()
{
	return state;
}

void ADSR::Trigger()
{
	counter=0;
	state=0;
}

void ADSR::SetTickLength(int p_ticklength)
{
	tick_length=p_ticklength;
	attack=attack_const*tick_length;
	decay=decay_const*tick_length;
	sustain=sustain_const*tick_length;
	release=release_const*tick_length;
}

float ADSR::Tick()
{
	counter++;
	switch (state)
	{
	//attack
	case 0:
		{
			if(counter<attack)
			{
				return float(counter/attack)*full_amp;
			}
			else
			{
				counter=0;			
				state++;
				return full_amp;
			}
		} break;
	//decay
	case 1:
		{
			if(counter<decay)
				return float(full_amp-(full_amp-sustain_amp)*(counter/decay));
			else
			{
				counter=0;
				state++;
				return sustain_amp;
			}
		} break;
	//sustain
	case 2:
		{
			if(counter<sustain)
				return sustain_amp;
			else
			{
				counter=0;
				state++;
				return sustain_amp;
			}
		} break;
	//release
	case 3:
		{
			if(counter<release)
				return float(sustain_amp-sustain_amp*(counter/release));
			else
			{
				counter=0;
				state=4;
				return 0;
			}
		} break;
	
	}//end switch

	return 0;
}
//--------------------------------------------------------------------//


//--------------------------------------------------------------------//
// Filtros
//********************************************************************//

float MoogVCF::run(float input)
{
  
  input -= out4 * fb;
  input *= 0.35013 * (f*f)*(f*f);
  out1 = input + 0.3 * in1 + (1 - f) * out1; // Pole 1
  in1  = input;
  out2 = out1 + 0.3 * in2 + (1 - f) * out2;  // Pole 2
  in2  = out1;
  out3 = out2 + 0.3 * in3 + (1 - f) * out3;  // Pole 3
  in3  = out2;
  out4 = out3 + 0.3 * in4 + (1 - f) * out4;  // Pole 4
  in4  = out3;
  return out4;
}

MoogVCF::MoogVCF()
{
	in1=in2=in3=in4=out1=out2=out3=out4=0;
	SetCutoff(1.0);
	SetResonance(0.1);
}

void MoogVCF::SetCutoff(float fc){f = fc * 1.16;}
void MoogVCF::SetResonance(float res){fb = res * (1.0 - 0.15 * f * f);}


//delay base
//--------------------------------------------------------------------//

FX_Delay::FX_Delay()
{	
	counter=0;
    for(int s=0;s<MAX_WG_DELAY;s++)
            buffer[s]=0;
	delay=0;
	feedback=0;
}

float FX_Delay::Run(float in)
{
	// calculate delay offset
        double back=(double)counter-delay;
        
        // clip lookback buffer-bound
        if(back<0.0)
            back=MAX_WG_DELAY+back;
        
        // compute interpolation left-floor
        int const index0=floor(back);
        
        // compute interpolation right-floor
        int index_1=index0-1;
        int index1=index0+1;
        int index2=index0+2;
        
        // clip interp. buffer-bound
        if(index_1<0)index_1=MAX_WG_DELAY-1;
        if(index1>=MAX_WG_DELAY)index1=0;
        if(index2>=MAX_WG_DELAY)index2=0;
        
        // get neighbourgh samples
        float const y_1= buffer [index_1];
        float const y0 = buffer [index0];
        float const y1 = buffer [index1];
        float const y2 = buffer [index2];
        
        // compute interpolation x
        float const x=(float)back-(float)index0;
        
        // calculate
        float const c0 = y0;
        float const c1 = 0.5f*(y1-y_1);
        float const c2 = y_1 - 2.5f*y0 + 2.0f*y1 - 0.5f*y2;
        float const c3 = 0.5f*(y2-y_1) + 1.5f*(y0-y1);
        
        float const output=((c3*x+c2)*x+c1)*x+c0;
        
        // add to delay buffer
        buffer[counter]=in+output*feedback;
        
        // increment delay counter
        counter++;
        
        // clip delay counter
        if(counter>=MAX_WG_DELAY)
            counter=0;
        
        // return output
        return output;
}


//ECHO

float Echo::Run(float in)
{	
	float output=in;	
	buffer[pos]=in;

	//LOWPASS
	//output(t) = output(t-1) + c*(input(t)-output(t-1)) 
	
	for(int i=1;i<8;i++)
	{
		int k=pos-delay*i;		
		if(k<0)k=DELAY_SIZE+k;		
		output+=(decay/i)*buffer[k];
	}
	
	pos++;
	if(pos>=DELAY_SIZE-1)pos=0;
	
	return output;
}

//--------------------------------------------------------------------//
// FX
//********************************************************************//


//REVERB
//--------------------------------------------------------------------//

Reverb::Reverb()
{
	rev_out=0.4;
	for(int i=0;i<COMB_FILTERS;i++)
	{
		CombFilters[i].SetFeedback(rev_out);
		CombFilters[i].SetDelay(MAX_WG_DELAY/COMB_FILTERS*i);
	}
}

float Reverb::Run(float in)
{	
	for(int i=0;i<COMB_FILTERS;i++)
			in+=CombFilters[i].Run(in);	
	return in;
}

void Reverb::SetRevOut(float p_rev_out)	
{
	for(int i=0;i<COMB_FILTERS;i++)
		CombFilters[i].SetFeedback(p_rev_out);
}


//FLANGER
//--------------------------------------------------------------------//

Flanger::Flanger()
{
	min=0;
	max=200;
	Combfilter.SetFeedback(0.5);
	osc.SetSamplingFreq(44100);
	osc.SetFreq(30);
	osc.SetWave(0);
	SetMaxDelay(max);
	SetMinDelay(min);
}

float Flanger::Run(float in)
{	
	Combfilter.SetDelay(center+osc.Tick());
	return Combfilter.Run(in);
}

void Flanger::SetMaxDelay(float p_max)
{
	max=p_max;
	osc.SetAmp((max-min)/2);
	center=(min+max)/2;
}

void Flanger::SetMinDelay(float p_min)
{
	min=p_min;
	osc.SetAmp((max-min)/2);
	center=(min+max)/2;
}


float Distortion::Run(float in)
{
	float output;
	int sign=-1;
	if (in>0)sign=1;
	
	if (abs(in)>threshold)
		output=dry*in+sign*distorted*level;
    else output=in*(dry + distorted);

	return output;        
}

Distortion::Distortion()
{
	float threshold=1000;
	float level=10000;
	float dry=1.0;
	float distorted=1.0;	
}

