#include "utils.h"


DWORD filesize(FILE *fp)
{
 DWORD pos;
 DWORD pos_cur;
 pos_cur=ftell(fp);
 fseek(fp,0,SEEK_END);
 pos=ftell(fp);
 fseek(fp,pos_cur,SEEK_SET);
 return pos;
}

	
void* DumpFileToMem(char* filename,DWORD* size)
{	
	FILE* fp;
	
	if(!(fp=fopen(filename,"rb")))
		return 0;

	*size=filesize(fp);
	char* buffer=new char[*size];
	fread(buffer,1,*size,fp);
	fclose(fp);

	return buffer;
}

void mread(void* dest, char* &source,size_t itemsize,size_t n)
{
	memcpy(dest,source,itemsize*n);
	source+=itemsize*n;
}