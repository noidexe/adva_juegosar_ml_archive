#ifndef UTILS
#define UTILS

#include <windows.h>
#include <stdio.h>

void* DumpFileToMem(char* filename,DWORD* size);

void mread(void* dest, char* &source,size_t itemsize,size_t n);

#endif