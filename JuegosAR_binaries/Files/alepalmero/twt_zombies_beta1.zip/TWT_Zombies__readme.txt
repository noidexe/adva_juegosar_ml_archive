-==THIRD WORLD TECH - 11/14/2002 - Rafaela - ARGENTINA==--

                From the butt of the world,
             THIRD WORLD TECH proudly presents: 

   	           TWT_ZOMBIES BETA1


WHAT IS TWT_ZOMBIES?
--------------------
It's a mutator that adds hundreds of zombie characters wandering around the ordinary UT/infiltration maps.
Zombies only die from braintrauma (or several shots in the body). Using our exclusive TWT_Realcolision technology we are allowed to provide almost perfect head collisions in the unreal engine. So, aim to the head (try it with the Sniper rifle, because another guns like the default unreal Enforcer are unprecise).
The Ai and the 3d models are overly simplified to allow spawning 100+ zombies. In fact we tried with 200/300 zombies simultaneously without problems.
The number of zombies, as other options, can be changed modifying the TWT_ZOMBIES.INI file located in your unreal\system folder


WHERE DO I RUN THIS?
--------------------
I tried it in old Unreal Tournament (not UT2003) and Infiltration.



WHAT IS A MUTATOR / HOW DO I INSTALL IT?
----------------------------------------
A mutator is a little add-on to the unreal Engine based games. 
To install this you should unpack the files in the .zip archive and copy them to your UNREAL\SYSTEM  directory.
Then run unreal or infiltration / etc and find the 'mutator' button  (in unreal is in 'start practice session' window). Find TWT_ZOMBIES in the mutator list and add it with a double click. Start the game normally, you should see hundreds of zombies.



IS THERE ANY GAME MODE / GAME OBJECTIVE?
----------------------------------------
Not yet. I play in "practice session" with 0 bots and 0 in frag limit.


WHY ARE THE LIGHTS AFFECTED?
----------------------------
I wanted to dim the lighting and set all lights to the same color to get a more unified look. This, as other options, can be changed modifying the TWT_ZOMBIES.INI file located in your unreal\system folder



ABOUT TWT 
---------
Third World Tech is:

Mariano Trod: Idea, concepts, testing and 1 half painted texture!

Cristian Scandalo: Zombie in suit model, webcam mocap actor!

Ale Palmero: Coding, modeling and animation, webpage

--------------------------------------------------------------------------
11/14/2002 Ale Palmero  - apalmero@netactic.com
http://espacio.revoluziona.com/soyelchupacabra
